"""
==============================================================================
                    PRACTICE EXERCISES: SEABORN POINTPLOT
==============================================================================

Dataset:
Plotly Express tips dataset

Point plots serve as categorical line plots. They connect central tendency 
estimates (dots) across discrete levels with lines, making them excellent 
for visualizing relative changes, trends, and interactions.
"""

import matplotlib.pyplot as plt
import numpy as np
import plotly.express as px
import seaborn as sns

df = px.data.tips()


# ============================================================
# QUESTION 1: Basic Point Plot
# ============================================================
# Create a point plot showing 'day' on the x-axis and 'total_bill' 
# # on the y-axis without error bars (errorbar=None).
# sns.pointplot(data=df,x='day',y='total_bill')
# plt.show()



# ============================================================
# QUESTION 2: Adding Hue (Categorical Comparison)
# ============================================================
# Create a point plot of 'day' vs 'total_bill', but separate the lines by 'sex' using the `hue` parameter.
# sns.pointplot(data=df,x='day',y='total_bill',hue='sex')
# plt.show()



# ============================================================
# QUESTION 3: Customizing Estimators (Median vs Mean)
# ============================================================
# By default, pointplot calculates the average (mean).
# Create a point plot of 'day' vs 'total_bill' that calculates the 
# MEDIAN instead of the mean using the `estimator` parameter.
# Hint:
# estimator=np.median or estimator="median"
# sns.pointplot(data=df,x='day',y='total_bill',estimator='median')
# plt.show()





# ============================================================
# QUESTION 4: Line Styles and Markers
# ============================================================
# Create a point plot of 'day' vs 'total_bill' hue-mapped by 'smoker'.
# Customize the markers to 'o' and 'x', and use dashed lines for one of the groups.
#
# Hint:
# markers=['o', 'x'], linestyles=['-', '--']
# sns.pointplot(data=df,x='day',y='total_bill',hue='smoker',markers=['o', 'x'], linestyles=['-', '--'])
# plt.show()



# ============================================================
# QUESTION 5: Dodging Overlapping Points
# ============================================================
# When point lines overlap closely, points can hide behind each other.
# Create a point plot of 'day' vs 'total_bill' with `hue='time'` 
# and use `dodge=True` to offset the point positions horizontally.

# sns.pointplot(data=df,x='day',y='total_bill',hue='time',dodge=True)
# plt.show()




# ============================================================
# QUESTION 6: Order Control
# ============================================================
# Create a point plot of 'day' vs 'tip' ordered explicitly as:
order_day=['Thur', 'Fri', 'Sat', 'Sun']

sns.pointplot(data=df,x='day',y='tip',order=order_day)
plt.show()
#
# Hint:
# order=['Thur', 'Fri', 'Sat', 'Sun']


# ============================================================
# QUESTION 7: Point Plot vs Bar Plot (Conceptual)
# ============================================================
"""
Q7: When would you prefer a `sns.pointplot()` over a `sns.barplot()`?

Answer: 
"""


# ============================================================
# QUESTION 8: Confidence Intervals Customization
# ============================================================
# Modern Seaborn uses `errorbar` instead of `ci`.
# Create a point plot of 'day' vs 'total_bill' displaying 95% confidence 
# intervals, and another showing standard deviation error bars.
#
# Hint:
# errorbar=('ci', 95) vs errorbar='sd'
import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px

df = px.data.tips()

print(df)


# ============================================================
# 1. Compare the distribution of total_bill across all days.
# ============================================================
# Create a strip plot with:
# x = day
# y = total_bill
# Use jitter=True.
# sns.stripplot(data=df,x='day',y='total_bill')
# plt.show()
# Determine which day has the widest spread of bill amounts.
"""Saturday has the widest spread of bill amounts"""


# ============================================================
# 2. Compare total_bill between smokers and non-smokers.
# ============================================================
# Create a strip plot with:
# x = smoker
# y = total_bill
# hue = sex
# sns.stripplot(data=df,x='smoker',y='total_bill',hue='sex')
# plt.show()
# Use jitter=True.
# Determine which combination of smoker status and sex
# appears to have the highest bill values.
"""The combination of smoker status and Male appears to have the highest bill values."""


# ============================================================
# 3. Analyze tips across different days and meal times.
# ============================================================
# Create a strip plot with:
# x = day
# y = tip
# hue = time
# sns.stripplot(data=df,x='day',y='tip',hue='time')
# plt.show()
# Use jitter=True.
# Compare Lunch and Dinner tips for each day.
"""The Dinner tips are more higher in saturday and sunday whereas"""


# ============================================================
# 4. Investigate the relationship between party size
# and total_bill.
# ============================================================
# Create a strip plot with:
# x = size
# y = total_bill
#
# Use jitter=True.
# Determine whether larger party sizes generally have
# higher bill amounts.


# ============================================================
# 5. Compare tip distributions by day and smoker status.
# ============================================================
# Create a strip plot with:
# x = day
# y = tip
# hue = smoker
#
# Use jitter=True.
# Identify which day contains the highest individual tip
# and determine whether that observation belongs to a smoker
# or non-smoker.


# ============================================================
# 6. Analyze high-value customers.
# ============================================================
# Filter the dataset to include only customers whose
# total_bill is greater than 20.
#
# Create a strip plot with:
# x = day
# y = total_bill
# hue = sex
#
# Use jitter=True.
# Compare the distribution of high-value bills between
# males and females for each day.


# ============================================================
# 7. Compare tips for different party sizes and meal times.
# ============================================================
# Create a strip plot with:
# x = size
# y = tip
# hue = time
#
# Use jitter=True.
# Determine whether Dinner generally produces higher tips
# than Lunch for the same party size.


# ============================================================
# 8. Analyze the relationship between bill amount
# and smoker status within each day.
# ============================================================
# Create a strip plot with:
# x = day
# y = total_bill
# hue = smoker
#
# Use jitter=True and dodge=True.
#
# Compare smokers and non-smokers within each day.
# Identify which day shows the greatest difference
# in the distribution of bill amounts.


# ============================================================
# 9. Analyze extreme tip values.
# ============================================================
# Filter the dataset to include only customers whose
# tip is greater than 4.
#
# Create a strip plot with:
# x = day
# y = tip
# hue = time
#
# Use jitter=True.
# Determine which day contains the greatest concentration
# of high-tip observations.


# ============================================================
# 10. Advanced comparison using multiple categorical variables.
# ============================================================
# Create a strip plot with:
# x = day
# y = total_bill
# hue = smoker
sns.stripplot(data=df,x='day',y='total_bill',hue='smoker',jitter=True,dodge=True)
plt.show()
# Use:
# jitter=True
# dodge=True
#
# Analyze:
# 1. Which day has the highest bill values?
# 2. Which day has the widest distribution?
# 3. Are smokers or non-smokers more concentrated at
#    higher bill amounts?
# 4. Which category contains the most extreme observations?
# 5. Explain your conclusions based on the individual points.
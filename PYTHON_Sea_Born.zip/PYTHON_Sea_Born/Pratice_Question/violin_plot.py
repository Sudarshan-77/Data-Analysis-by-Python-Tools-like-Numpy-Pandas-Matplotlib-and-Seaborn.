# ============================================================
# SEABORN VIOLIN PLOT - ADVANCED PRACTICE QUESTIONS
# ============================================================

import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px

df = px.data.tips()

# ============================================================
# QUESTION 1 - Basic Violin Plot
# ============================================================
# Create a violin plot showing the distribution of "total_bill"
# for each "day".
#
# Requirements:
# - x = day
# - y = total_bill
# - Add a suitable title.
# sns.violinplot(data=df,x='day',y='total_bill')
# plt.title("Violin plot showing the distribution of 'total_bill' for each day")
# plt.grid()
# plt.show()
# - Analyze which day has the highest concentration of bills.
""""""

# ============================================================
# QUESTION 2 - Violin Plot with Hue
# ============================================================
# Create a violin plot showing "total_bill" by "day".
#
# Use:
# - hue = sex
#
# sns.violinplot(data=df,x='day',y='total_bill',hue='sex')
# plt.title("Violin plot showing the distribution of 'total_bill' for each day")
# plt.grid()
# plt.show()
# Analyze:
# - Compare Male and Female distributions.
"""The distributions of Male are generally higher than female on each of the observations"""


# - Which group has a higher median on each day?
"""Male has gnerally a higher median on each day"""

# - Which group appears to have greater spread?
"""Groups of males are generally appears to have greater spread"""


# ============================================================
# QUESTION 3 - Split Violin Plot
# ============================================================
# Create a split violin plot using:
#
# x = day
# y = total_bill
# hue = sex
# split = True

# sns.violinplot(data=df,x='day',y='total_bill',hue='sex',split='True')
# plt.show()

#
# Analyze why each violin is divided into two parts.
"""Each violin is divided into teo parts it is deu to hue parameter of the functions."""


# ============================================================
# QUESTION 4 - Inner Box
# ============================================================
# Create a violin plot of "total_bill" by "day".
#
# Use:
# inner = "box"

# ax,fig=plt.subplots(1,4,figsize=(1,4))
sns.violinplot(data=df,x='day',y='total_bill')
plt.show()
#
# Identify:
# - Q1
# - Median
# - Q3
#
# Explain how the box inside the violin helps in interpreting
# the distribution.



# ============================================================
# QUESTION 5 - Compare Inner Options
# ============================================================
# Create three separate violin plots for "total_bill" by "day".
#
# Plot 1:
# inner = "box"
#
# Plot 2:
# inner = "quart"
#
# Plot 3:
# inner = None
#
# Compare the information displayed by all three plots.


# ============================================================
# QUESTION 6 - KDE Bandwidth
# ============================================================
# Create two violin plots of "total_bill" by "day".
# Plot 1:
# bw_adjust = 0.3

sns.violinplot(data=df,x='day',y='total_bill',bw_adjust='0.3')
plt.show()
# Plot 2:
# bw_adjust = 2

sns.violinplot(data=df,x='day',y='total_bill',bw_adjust='2')
plt.show()
#
# Compare the smoothness of the two distributions.
#
# Explain:
# - Which plot is smoother?
"""bw_adjust=2 plot is smoother"""

# - Which plot shows more local details?
"""bw_adjust=0.3 plot shows more local details"""

# - Why does bw_adjust affect the violin shape?
"""bw_adjust affects the violin shape because """


# ============================================================
# QUESTION 7 - Cut Parameter
# ============================================================
# Create two violin plots of "total_bill" by "day".
#
# Plot 1:
# cut = 0

sns.violinplot(data=df,x='day',y='total_bill',cut=0)
plt.show()

# Plot 2:
# cut = 2
sns.violinplot(data=df,x='day',y='total_bill',cut=2)
plt.show()
#
# Analyze:
# - What happens to the ends of the violin?
# - Why can the violin extend beyond the actual minimum
#   and maximum values when cut is greater than 0?


# ============================================================
# QUESTION 8 - Density Normalization
# ============================================================
# Create three violin plots using:
#
# density_norm = "area"
# density_norm = "count"
# density_norm = "width"
#
# Use:
# x = day
# y = total_bill
#
plt.violinplot(data=df,x='day',y='total_bill',density_norm = "count")
plt.show()
# Explain how the width of the violins changes under
# each normalization method.


# ============================================================
# QUESTION 9 - Smoker Comparison
# ============================================================
# Create a violin plot using:
#
# x = smoker
# y = total_bill
# hue = sex
# split = True
#
# Analyze:
# - Which group has the higher median?
# - Which group has greater density around high total bills?
# - Compare smokers and non-smokers.


# ============================================================
# QUESTION 10 - Time-Based Distribution
# ============================================================
# Create a violin plot using:
#
# x = time
# y = total_bill
# hue = sex
#
# Compare Lunch and Dinner distributions.
#
# Analyze:
# - Median
# - Spread
# - Density
# - Skewness
#
# Determine which time period has greater variation.


# ============================================================
# QUESTION 11 - Violin Plot with Multiple Categories
# ============================================================
# Create a violin plot using:
#
# x = day
# y = tip
# hue = smoker
# split = True
#
# Analyze:
# - Which day has the highest tip distribution?
# - Which smoker group has higher tips?
# - Which day shows the greatest difference between
#   smokers and non-smokers?


# ============================================================
# QUESTION 12 - Violin Plot vs Box Plot
# ============================================================
# Create two plots for:
#
# x = day
# y = total_bill
#
# Plot 1 → Box plot
# Plot 2 → Violin plot
#
# Compare:
# - Median
# - Quartiles
# - IQR
# - Outliers
# - Distribution shape
# - Density
#
# Explain which plot provides more information about
# the distribution and why.


# ============================================================
# QUESTION 13 - Detect Distribution Shape
# ============================================================
# Create a violin plot using:
#
# x = day
# y = total_bill
# inner = "quart"
#
# Examine the shape of each violin.
#
# Determine:
# - Which distributions appear symmetric?
# - Which distributions appear positively skewed?
# - Which distributions have a large concentration of values
#   in a particular range?


# ============================================================
# QUESTION 14 - Advanced Violin Plot
# ============================================================
# Create a violin plot using:
#
# x = day
# y = total_bill
# hue = sex
# split = True
# inner = "box"
# bw_adjust = 0.5
# cut = 0
#
# Analyze the complete plot:
# - Median
# - Q1
# - Q3
# - IQR
# - Distribution shape
# - Density
# - Male vs Female differences
# - Day-to-day differences


# ============================================================
# QUESTION 15 - EXPERT CHALLENGE
# ============================================================
# Create a violin plot using:
#
# x = day
# y = total_bill
# hue = smoker
# split = True
# inner = "quart"
# bw_adjust = 0.5
# cut = 0
# density_norm = "count"
#
# Then provide a complete statistical interpretation.
#
# Your analysis must include:
#
# 1. Which day has the highest median total_bill?
# 2. Which day has the largest spread?
# 3. Which group has the highest density?
# 4. Which group appears more variable?
# 5. Identify possible skewness.
# 6. Compare smokers and non-smokers.
# 7. Explain the effect of bw_adjust.
# 8. Explain the effect of cut.
# 9. Explain the effect of density_norm.
# 10. Explain why a violin plot can reveal information
#     that a box plot cannot.
#
# DO NOT calculate the answers manually first.
# Use the violin plot to perform the analysis.
# ============================================================
# ============================================================
# PLOTLY HISTOGRAM - 10 ADVANCED PRACTICE QUESTIONS
# ============================================================
import seaborn as sns
import plotly.express as px
import matplotlib.pyplot as plt

df = px.data.gapminder()


# ============================================================
# QUESTION 1 - Basic Distribution
# ============================================================
# Create a histogram of the "lifeExp" column.

# sns.histplot(data=df,x='lifeExp',bins=30)
# plt.title("Life Expectancy of Different Countries")
# plt.show()
# Requirements:
# - Use 30 bins
# - Add a suitable title
# - Add proper x-axis and y-axis labels
#
# Analyze where most of the life expectancy values are
# concentrated.


# ============================================================
# QUESTION 2 - Histogram by Continent
# ============================================================
# Create a histogram of "lifeExp".
#
# # Use:
# - x = "lifeExp"
# # - color = "continent"
# sns.histplot(data=df,x='lifeExp',hue='continent')
# plt.title("Life Expectancy of Different Countries")
# plt.show()


# Compare the distribution of life expectancy among
# different continents.


# ============================================================
# QUESTION 3 - GDP Distribution
# ============================================================
# Create a histogram of "gdpPercap".
#
# Requirements:
# - Use 40 bins
# - Color the histogram according to "continent"
# - Add an appropriate title
#

# sns.histplot(data=df,x='gdpPercap',hue='continent',bins=40)
# plt.title("Gross Domestic Product of Different Countries")
# plt.show()

# Determine which continent contains the widest range
# of GDP per capita values.


# ============================================================
# QUESTION 4 - Normalized Histogram
# ============================================================
# Create a histogram of "lifeExp".
#
# Use:
# - histnorm="probability"
# - nbins=30

# stat- We can use stat to calculate the probability, percent,density, count  etc and any another numeric data like this

# sns.histplot(data=df,x='lifeExp',bins=30, stat='probability')
# plt.title("Gross Domestic Product of Different Countries")
# plt.show()
# #
# Instead of showing the raw number of observations,
# show the probability of observations falling into
# each bin.


# ============================================================
# QUESTION 5 - Density Histogram
# ============================================================
# Create a density histogram of "gdpPercap".
#
# Requirements:
# - Use histnorm="density"
# - Use 50 bins
# - Add a suitable title
#
# Explain the difference between:
#
# histnorm="density"
# and
# histnorm="probability"

# sns.histplot(data=df,x='gdpPercap',bins=50,stat='density')
# plt.show()

# ============================================================
# QUESTION 6 - Marginal Plot
# ============================================================
# Create a histogram of "lifeExp".
#
# Add a marginal box plot using:
#
# marginal="box"
#
# Use 30 bins.
#
# Analyze both:
# - The distribution shown by the histogram
# - The outliers shown by the box plot
# sns.histplot(data=df,x='lifeExp',bins=30,)
# plt.show()

# ============================================================
# QUESTION 7 - Histogram with Rug Plot
# ============================================================
# Create a histogram of "lifeExp".
#
# Requirements:
# - x = "lifeExp"
# - Use 30 bins
# - Add a rug plot using sns.rugplot()

# sns.rugplot(data=df,x='lifeExp')
# plt.show()
#
# Analyze:
# - What does each individual mark in the rug plot represent?
# - What does the rug plot tell you about the distribution?


# ============================================================
# QUESTION 8 - Histogram with Density
# ============================================================
# Create a histogram of "lifeExp".
#
# Requirements:
# - x = "lifeExp"
# - Use 30 bins
# - Normalize the histogram using:
#       stat="density"
#
# sns.histplot(data=df,bins=30,x="lifeExp")
# # sns.histplot(data=df,bins=30,x="lifeExp",stat='density')
# plt.show()


# Analyze:
# - What does the Y-axis represent now?
"""Y-axis represent the density now"""
# - How is this different from a normal count histogram?
""" This is different from a normal count histogram as it represents the density rather counts"""
# - Why can density be useful when analyzing distributions?
"""Density can be useful when analyzing distributions because it helps to show where the data is heavily distributed"""


# ============================================================
# QUESTION 9 - Histogram with KDE
# ============================================================
# Create a histogram of "lifeExp".

sns.displot(data=df,x="lifeExp",bins=30,kind='hist',kde=True)
plt.show()
# Requirements:
# - x = "lifeExp"
# - Use 30 bins
# - Add a KDE curve using:
#       kde=True
# - Use density normalization
#
# Analyze:
# - What does the KDE curve represent?
"""The KDE curve represent the distribution of the data using the curve same as the the histograms"""

# - Is the distribution symmetric or skewed?
""" The distribution is positively skewed"""

# - Where is the highest concentration of values?
"""The highest concentration of values near 70 and 71"""

# - Are there possible outliers?


# ============================================================
# QUESTION 10 - EXPERT LEVEL HISTOGRAM
# ============================================================
# Create a histogram of "gdpPercap".
#
# Requirements:
# - x = "gdpPercap"
# - Use 50 bins
# - Use:
#       hue="continent"
# - Normalize using:
#       stat="density"
# - Add KDE using:
#       kde=True
# - Add a rug plot
#
# Customize:
# - Title
# - X-axis label
# - Y-axis label
# - Figure size
#
# Analyze:
#
# 1. Which continent generally has higher GDP per capita?
#
# 2. Which continent has the widest distribution?
#
# 3. Are there visible outliers?
#
# 4. Is the distribution symmetric or skewed?
#
# 5. What does increasing the number of bins from 30 to 50
#    do to the histogram?
#
# 6. What information does the KDE curve provide?
#
# 7. What information does the rug plot provide?
#
# 8. Why is stat="density" useful when comparing distributions?
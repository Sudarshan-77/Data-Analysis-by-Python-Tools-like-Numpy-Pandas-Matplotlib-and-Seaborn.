# ============================================================
# ADVANCED BOX PLOT PRACTICE — 20 QUESTIONS
# ============================================================

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px

# Load dataset
df = px.data.tips()
# print(df)
# print(df.head())


# ============================================================
# Q1 — Basic Distribution
# ============================================================
# Create a box plot for total_bill.
# Identify the median, IQR, whiskers, and outliers.
# sns.boxplot(data=df,y="total_bill")
# plt.grid()
# plt.show()



# ============================================================
# Q2 — Category Comparison
# ============================================================
# Create a box plot of total_bill for each day.
# Determine which day has:
# - Highest median
# - Lowest median
# - Largest IQR

# sns.boxplot(data=df,x='day',y="total_bill")
# plt.grid()
# plt.show()


# ============================================================
# Q3 — Tip Distribution
# ============================================================
# Create a box plot of tip by day.
# Identify which day has the greatest variation in tips.
# sns.boxplot(data=df,x='day',y="tip")
# plt.grid()
# plt.show()


# ============================================================
# Q4 — Hue Comparison
# ============================================================
# Create a box plot of total_bill by day using smoker as hue.
# Compare smokers and non-smokers for each day.
# sns.boxplot(data=df,x='day',y="total_bill",hue='smoker')
# plt.grid()
# plt.show()

# ============================================================
# Q5 — Multiple Categories
# ============================================================
# Create a box plot of total_bill by day using sex as hue.
# Find which Day + Sex combination has the highest median.
# sns.boxplot(data=df,x='day',y="total_bill",hue='sex',estimator='median')
# plt.grid()
# plt.show()

# ============================================================
# Q6 — Calculate Quartiles
# ============================================================
# Calculate the following for total_bill:
# - Q1
# - Median
# - Q3
# - IQR

# Quartile_1=df['total_bill'].quantile(0.25)
# print(Quartile_1)

# Quartile_3=df['total_bill'].quantile(0.75)
# print(Quartile_3)


# Median=df['total_bill'].quantile(0.50)
# print(Median)

# Mean=df['total_bill'].mean()
# print(Mean)

# IQR=Quartile_3-Quartile_1
# Print all values.


# ============================================================
# Q7 — Detect Outliers Manually
# ============================================================
# Calculate:
#
# Lower_Bound = Quartile_1 - 1.5 * IQR
# Upper_Bound = Quartile_3 + 1.5 * IQR

# Identify all total_bill values outside these boundaries.


# ============================================================
# Q8 — Outliers by Category
# ============================================================
# Calculate the number of outliers in total_bill separately
# for each day.

# d=df[(df["total_bill"]> Lower_Bound )| (df["total_bill"]< Upper_Bound)]
# print(len(d))
# Display:
#
# Day | Number of Outliers


# ============================================================
# Q9 — Outlier Percentage
# ============================================================
# Calculate the percentage of total_bill observations that
# are classified as outliers using the 1.5 × IQR rule.
# Percentage=1.5 
# df=df.groupby("day")["total_bill"].median()
# print(df)
# df=df.sort_values().index
# print(df)

# ============================================================
# Q10 — Category Ordering
# ============================================================
# Find the median total_bill for every day.
# Sort the days according to their median.
# Create a box plot using this sorted order.
# df=df.groupby("day")["total_bill"].median()
# sns.boxplot(data=df,x='day',y='total_bill')
# plt.show()





# ============================================================
# Q11 — Filtered Box Plot
# ============================================================
# Filter the dataset to include only customers whose
# total_bill is greater than 20.
# df_filtered = df[df["total_bill"] > 20]
# print(df_filtered)
# Create a box plot of total_bill by day.

# sns.boxplot(data=df_filtered,x='day',y='total_bill')
# plt.show()
#
# Compare it with the original distribution.


# ============================================================
# Q12 — Dinner Analysis
# ============================================================
# Filter the dataset to include only dinner customers.
# df=df[df['time']=='Dinner']
# print(df)
#
# Create a box plot of total_bill by day.

# sns.boxplot(data=df,x='day',y='total_bill')
# plt.show()
# Determine which day has the highest median bill.
"""Saturday has the highest median bill """

# ============================================================
# Q13 — Sex + Time Analysis
# ============================================================
# Filter the dataset to include:
# - Female customers
# - Dinner customers

# df=df[(df["sex"]=='Female') & (df["time"]=='Dinner')]
# sns.boxplot(data=df,y='total_bill',x='day')
# plt.show()
# # #
# Create a box plot of total_bill by day.
# Analyze the distribution.


# ============================================================
# Q14 — Statistical Summary Table
# ============================================================
# For each day, calculate:
# - Q1
# df_1=df[df['day']=='Thur']
# # print(df_1)
# df_2=df[df['day']=='Fri']
# df_3=df[df['day']=='Sat']
# df_4=df[df['day']=='Sun']

# Quartile_for_df_1=df_1['total_bill'].quantile(0.25)
# # print(Quartile_for_df_1)

# Quartile_for_df_2=df_2['total_bill'].quantile(0.25)
# # print(Quartile_for_df_2)

# Quartile_for_df_3=df_3['total_bill'].quantile(0.25)
# # print(Quartile_for_df_3)

# Quartile_for_df_4=df_4['total_bill'].quantile(0.25)
# print(Quartile_for_df_4)

# - Median


# Median_for_df_1=df_1['total_bill'].quantile(0.50)
# print(Median_for_df_1)

# Median_for_df_2=df_2['total_bill'].quantile(0.50)
# print(Median_for_df_2)

# Median_for_df_3=df_3['total_bill'].quantile(0.50)
# print(Median_for_df_3)

# Median_for_df_4=df_4['total_bill'].quantile(0.50)
# print(Median_for_df_4)

# - Q3


# Quartile3_for_df_1=df_1['total_bill'].quantile(0.75)
# # print(Quartile3_for_df_1)

# Quartile3_for_df_2=df_2['total_bill'].quantile(0.75)
# # print(Quartile3_for_df_2)

# Quartile3_for_df_3=df_3['total_bill'].quantile(0.75)
# # print(Quartile3_for_df_3)

# Quartile3_for_df_4=df_4['total_bill'].quantile(0.75)
# # print(Quartile3_for_df_4)
# # - IQR
# #

# IQR_1=Quartile3_for_df_1-Quartile_for_df_1
# print("The interal quartile range for IQR_1",IQR_1)

# IQR_2=Quartile3_for_df_2-Quartile_for_df_2
# print("The interal quartile range for IQR_1",IQR_2)

# IQR_3=Quartile3_for_df_3-Quartile_for_df_3
# print("The interal quartile range for IQR_1",IQR_3)

# IQR_4=Quartile3_for_df_4-Quartile_for_df_4
# print("The interal quartile range for IQR_1",IQR_4)
# # Store the results in a DataFrame.


# ============================================================
# Q15 — Find the Most Variable Group
# ============================================================
# Using the IQR calculated in Q14, determine which day has
# the greatest variability in total_bill.
"""Friday has the greatest variability in total_bill"""



# ============================================================
# Q16 — Professional Box Plot
# ============================================================
# Create a professional box plot of total_bill by day.
#
# Include:
# # - Suitable figure size
# sns.boxplot(data=df,x='day',y='total_bill')
# plt.figure(figsize=(10,6))
# plt.show()

# - Title
# - X-axis label
# - Y-axis label
# - Grid
# - Clearly visible outliers


# ============================================================
# Q17 — Customize Box Plot Components
# ============================================================
# Create a box plot and customize:
#
# - Box properties
# - Median line
# - Whiskers
# - Caps
# - Outliers
sns.boxplot(data=df,x='day',y='total_bill',boxprops={'color':'blue'},medianprops={'color':'red'},capprops={'color':'green'},flierprops={'color':'purple'})
plt.show()
#
# Use:
# boxprops
# medianprops
# whiskerprops
# capprops
# flierprops


# ============================================================
# Q18 — Compare Total Bill and Tip
# ============================================================
# Create separate box plots for:
#
# 1. total_bill by day
# 2. tip by day
#
# Compare:
# - Median
# - IQR
# - Outliers
# - Overall spread


# ============================================================
# Q19 — Data Analyst Challenge
# ============================================================
# Imagine you are a restaurant data analyst.
#
# Management asks:
#
# "Which day shows the greatest variation in customer bills?"
#
# Use:
# - Box plot
# - Median
# - Q1
# - Q3
# - IQR
# - Outliers
#
# Give a final conclusion based on your analysis.


# ============================================================
# Q20 — EXPERT CHALLENGE
# ============================================================
# Perform a complete box plot analysis of total_bill by day.
#
# Your program must:
#
# 1. Display the box plot.
# 2. Calculate Q1.
# 3. Calculate median.
# 4. Calculate Q3.
# 5. Calculate IQR.
# 6. Calculate lower bound.
# 7. Calculate upper bound.
# 8. Identify outliers.
# 9. Count outliers.
# 10. Calculate outlier percentage.
# 11. Find the day with the highest median.
# 12. Find the day with the largest IQR.
# 13. Find the day with the most outliers.
#
# Finally, write 5 observations about the distribution
# in comments.
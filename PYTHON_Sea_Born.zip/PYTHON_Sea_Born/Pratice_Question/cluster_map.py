"""
CLUSTER MAP PRACTICE

Dataset:
Seaborn's iris dataset

A cluster map performs hierarchical clustering and rearranges
rows and columns so that similar observations are placed together.
"""

import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px

df = px.data.iris()

# print(df)

# df=df[["sepal_length","sepal_width","petal_length","petal_width"]]
# sns.clustermap(df)
# plt.show()
# Select only numerical measurement columns


# ============================================================
# QUESTION 1
# ============================================================
# Create a basic cluster map using all four numerical columns.
# Your output should show both row and column clustering.


# ============================================================
# QUESTION 2
# ============================================================
# Create a cluster map using ONLY:
# # sepal_length and sepal_width
# df=df[["sepal_length","sepal_width"]]
# sns.clustermap(df)
# plt.show()

# ============================================================
# QUESTION 3
# ============================================================
# Create a cluster map using ONLY:
# petal_length and petal_width
df=df[["petal_length","petal_width"]]
# sns.clustermap(df,cmap='coolwarm',standard_scale=1)
# plt.show()


# ============================================================
# QUESTION 4
# ============================================================
# Create a cluster map and use the "standard_scale" parameter
# to standardize the columns.
#
# Hint:
# sns.clustermap(data, standard_scale=1)


# ============================================================
# QUESTION 5
# ============================================================
# Create a cluster map using the correlation method.
#
# Hint:
# First calculate the correlation matrix using:
# data.corr()
df=df.corr()
print(df)
#
# Then create a cluster map from the correlation matrix.


# ============================================================
# QUESTION 6
# ============================================================
# Create a cluster map using Euclidean distance.
#
# Hint:
# metric="euclidean"


# ============================================================
# QUESTION 7
# ============================================================
# Create a cluster map using Manhattan distance.
#
# Hint:
# metric="cityblock"


# ============================================================
# QUESTION 8
# ============================================================
# Change the figure size of your cluster map.
#
# Make the figure approximately 10 x 8 inches.
#
# Hint:
# figsize=(10, 8)


# ============================================================
# QUESTION 9
# ============================================================
# Create a cluster map using only the first 20 rows
# of the iris dataset.
#
# Hint:
# data.iloc[:20]


# ============================================================
# QUESTION 10
# ============================================================
# Create a cluster map using the following columns:
#
# sepal_length
# petal_length
#
# Then observe:
#
# 1. Which rows are grouped together?
# 2. Which columns are grouped together?
# 3. What does the dendrogram tell you?
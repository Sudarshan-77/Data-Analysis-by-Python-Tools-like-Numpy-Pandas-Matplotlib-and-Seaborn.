# ============================================================
# COUNT PLOT - ADVANCED LEVEL PRACTICE
# Dataset: Seaborn/Plotly Tips Dataset
# ============================================================

import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px

df = px.data.tips()
print(df)
# print(df)
# ============================================================
# Question 1
# ============================================================
# Create a count plot showing the number of customers for
# each day, separated by sex using hue.
#
# Requirements:
# - x = day
# - hue = sex
# sns.countplot(data=df,x='day',hue='sex')
# plt.title("The number of coustomers for each day")
# plt.figure(figsize=(10,6))
# plt.show()
# - Add a suitable title.
# - Add x-axis and y-axis labels.
# - Set figure size to 10 x 6.


# ============================================================
# Question 2
# ============================================================
# Create a count plot showing the number of customers for
# each day, separated by smoker status.
#
# Requirements:
# - x = day
# - hue = smoker
# - Arrange the days in this order:
#   Thur, Fri, Sat, Sun
# df=df[df['day'].isin(['Thur','Fri','Sat','Sun'])]
# sns.countplot(data=df,x='day',hue='smoker')
# plt.show()

# - Add a suitable title.


# ============================================================
# Question 3
# ============================================================
# Filter the dataset so that only customers with
# total_bill greater than 20 are included.
#

df=df['total_bill'].quantile(0.25)
print(df)
# sns.countplot(data=df,x='day',hue='sex')
# plt.show()
# Then create a count plot showing:
# - x = day
# - hue = sex
#
# Determine which day has the highest number of customers
# after filtering.


# ============================================================
# Question 4
# ============================================================
# Filter the dataset to include only:
# - smoker == 'Yes'
# - time == 'Dinner'
# Create a count plot showing the number of customers
# for each day.

# df=df[df['smoker'].isin(['Yes'])]
# df=df[df['time'].isin(['Dinner'])]
# sns.countplot(data=df,x='day')
# plt.show()
# Add:
# - title
# - x-axis label
# - y-axis label
# - figure size of 10 x 6


# ============================================================
# Question 5
# ============================================================
# Create a count plot showing party size distribution.
#
# Requirements:
# - x = size
# - hue = sex
#
# sns.countplot(data=df,x='size',hue='sex')
# plt.show()
# Determine:
# - Which party size is most common for males?
"""Party size 2 is the most common for males"""

# - Which party size is most common for females?
"""Party size 2 is the most common for females"""


# ============================================================
# Question 6
# ============================================================
# Filter the dataset where:
# df=df[df['total_bill']>25]
# df=df[df['tip']>4]
# total_bill > 25
# tip > 4
#
# Then create a count plot with:
#
# x = day
# hue = smoker
# sns.countplot(data=df,x='day',hue='smoker')
# plt.show()
# #
# Determine which day has the highest number of smokers
# after applying both conditions.


# ============================================================
# Question 7
# ============================================================
# Create a count plot using:
#
# x = time
# hue = sex

# sns.countplot(data=df,x='time',hue='sex')
# plt.show()
# Then determine:
#
# 1. Which gender has more customers during Lunch?
"""Females Gender has more customers during Lunch"""

# 2. Which gender has more customers during Dinner?
"""Male Gender has more customers during Dinner"""

# 3. Which time period has more total customers?
"""Dinner has generally more total customers in total"""


# ============================================================
# Question 8
# ============================================================
# Create a count plot using:
#
# x = day
# hue = time
# order_day=['Thur','Fri','Sat','Sun']
# sns.countplot(data=df,x='day',hue='time',order=order_day)
# plt.show()
# Arrange the days as:
#
# Thur, Fri, Sat, Sun
#
# Then determine:
#
# - Which day has the highest number of Lunch customers?
"""Thrusday has the highest number of Lunch customers"""

# - Which day has the highest number of Dinner customers?
"""Saturday has the highest number of Dinner customers"""

# - Which day has the largest difference between Lunch
"""Saturday has the larges difference between Lunch and Dinner"""

#   and Dinner customers?


# ============================================================
# Question 9
# ============================================================
# Create a count plot showing:
#
# x = day
# hue = smoker
#
# But first filter the dataset so that:
#
# sex == 'Female'
# total_bill > 20
df=df[df['sex']=='Female']
df=df[df['total_bill']>20]
order_day=['Thur','Fri','Sat','Sun']
sns.countplot(data=df,x='day',hue='smoker',order=order_day)
# Requirements:
# - Add a suitable title.
# - Set figure size to 10 x 6.
# - Order the days as Thur, Fri, Sat, Sun.
# - Add count labels above each bar.
#
# Finally determine which day has the highest number of
# female smokers.


# ============================================================
# Question 10 - EXPERT CHALLENGE
# ============================================================
# Perform the following analysis:
#
# Step 1:
# Filter the dataset where:
#
# sex == 'Male'
# total_bill > 20
# tip > 3
# df=df[df['sex']=='Male']
# df=df[df['total_bill']>20]
# df=df[df['tip']>3]
# # Step 2:
# # Create a count plot with:
# #
# # x = day
# # hue = smoker
# sns.countplot(data=df,x='day',hue='smoker')
# plt.show()
# Step 3:
# Arrange the days:
#
# Thur, Fri, Sat, Sun
#
# Step 4:
# Set figure size to 12 x 6.
#
# Step 5:
# Add:
# - title
# - x-axis label
# - y-axis label
# - count labels above every bar
#
# Step 6:
# Determine:
#
# - Which day has the highest number of male smokers?
# - Which day has the highest number of male non-smokers?
# - Which day has the highest total number of customers?
# - What is the difference between smokers and non-smokers
#   on each day?
#
# Use pandas operations such as value_counts() or groupby()
# to verify your conclusions from the graph.
# ============================================================
# SEABORN LINE PLOT — COMPLETE PRACTICE QUESTIONS
# ============================================================

import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px

df = px.data.gapminder()
# print(df)

# ============================================================
# LEVEL 1 — BASIC LINE PLOT
# ============================================================

# Q1.
# Create a line plot showing the life expectancy of Nepal
# from 1952 to 2007.
# new=df[df["country"].isin(['Nepal'])]
"""sns.lineplot(data=new,x='year',y='lifeExp',hue="country")
plt.xlim(1952,2007)
plt.show() """
# X-axis  → year
# Y-axis  → lifeExp
#
# Use sns.lineplot().
# Add a title, X-axis label and Y-axis label.


# Q2.
# Create a line plot showing Nepal's GDP per capita
# over the years.
#
# X-axis → year
# Y-axis → gdpPercap
# sns.lineplot(data=new,x='year',y='gdpPercap')
# plt.ylabel("GDP Per Capita in Rs")




# Q3.
# Create a line plot showing Nepal's population
# over the years.
#
# X-axis → year
# Y-axis → pop
# sns.lineplot(data=new,x='year',y='pop')
# plt.ticklabel_format(style="plain",axis="y")
# plt.show()



# Q4.
# Compare the life expectancy of:

# also=df[df['country'].isin(["Nepal","Brazil","Australia"])]
# Nepal
# Brazil
# Australia
# sns.lineplot(data=also,x='year',y='lifeExp',hue='country')

# Use hue="country" so that every country has
# a different line.


# ============================================================
# LEVEL 2 — HUE
# ============================================================

# Q5.
# Compare the life expectancy of:
#
# Nepal
# India
# China
# Japan
# Australia
#
# Use hue="country".
# also=df[df['country'].isin(["Nepal","India","China","Japan","Australia"])]
# sns.lineplot(data=also,x='year',y='lifeExp',hue='country')
# plt.show()


# Q6.
# Compare GDP per capita over time for:
#
# Nepal
# India
# China
# Japan
#
# Use hue="country".
# also=df[df['country'].isin(["Nepal","India","China","Japan","Australia"])]
# sns.lineplot(data=also,x='year',y='lifeExp',hue='country')
# plt.show()


# Q7.
# Create a line plot showing the average life expectancy
# of each continent over time.
#
# X-axis → year
# Y-axis → lifeExp
# hue → continent
# import numpy as np
# average=np.average()

# sns.lineplot(data=df,x='year',y='lifeExp',hue='continent')
# plt.show()

"""Estimator is one of the very important functions for Numerical Calucation such as mean, median, std"""
#
# Do NOT manually calculate the averages.


# Q8.
# Create a line plot showing the average population
# of each continent over time.
#
# X-axis → year
# Y-axis → pop
# hue → continent

# sns.lineplot(data=df,x='year',y='lifeExp',hue='continent',estimator='mean',errorbar=None)
# plt.show()



# ===========================================================--
# LEVEL 3 — STYLE
# ============================================================


# Q9.
# Compare the life expectancy of:


# Nepal
# Brazil
# Australia
#
# Use:
# hue="country"
# style="country"
# my_country=df[df["country"].isin(["Nepal","Brazil","Australia"])]
# sns.lineplot(data=my_country,x='year',y='lifeExp',hue="country",style="country")
# plt.show()

#
# Each country should have a different color
# and a different line style.


# Q10.
# Create a line plot comparing Nepal, Brazil and Australia.
#
# Requirements:
# - Different color for each country
# - Add markers to every data point
# - Use circular markers
#
# sns.lineplot(data=my_country,x='year',y='lifeExp',hue='country',style='country',marker='o')
# plt.show()
# Hint:
# markers=True


# Q11.
# Compare the life expectancy of:
#
# Nepal
# India
# China
# Japan
my_country=df[df["country"].isin(["Nepal","India","China","Japan"])]
# Requirements:
# - Different colors
# - Different markers
# - Different line styles
#
# Use:
# hue
# style
# markers
# dashes
sns.lineplot(data=my_country,x='year',y='lifeExp',hue='country',style='country',marker='s')
# plt.grid(linestyle=':')
plt.show()


# ============================================================
# LEVEL 4 — SIZE
# ============================================================

# Q12.
# Create a line plot comparing the average life expectancy
# of each continent over time.
#
# Use:
# hue="continent"
# size="continent"
#
# The line thickness should vary between continents.


# Q13.
# Compare the life expectancy of:
#
# Nepal
# India
# China
# Japan
# Australia
#
# Use:
# hue="country"
# size="country"


# Q14.
# Compare Nepal, Brazil and Australia.
#
# Use all three semantic mappings:
#
# hue   → country
# style → country
# size  → country
#
# Also add markers.


# ============================================================
# LEVEL 5 — ESTIMATOR
# ============================================================

# Q15.
# Create a line plot showing the average life expectancy
# of all countries for every year.
#
# Use:
# estimator="mean"


# Q16.
# Create a line plot showing the maximum life expectancy
# for every year.
# Use:
# estimator="max"


# Q17.
# Create a line plot showing the minimum life expectancy
# for every year.
#
# Use:
# estimator="min"


# Q18.
# Create a line plot showing the average GDP per capita
# for every year.
#
# Use:
# estimator="mean"


# ============================================================
# LEVEL 6 — ERRORBAR
# ============================================================

# Q19.
# Create a line plot showing average life expectancy
# for every year.
#
# Display the confidence interval around the line.
#
# Use:
# errorbar="ci"
sns.lineplot(data=my_country,x='year',y='lifeExp',hue='country',style='country',marker='s',errorbar='ci')
# plt.grid(linestyle=':')
plt.show()


# Q20.
# Create a line plot showing average life expectancy
# for every year.
#
# Display standard deviation as the error range.
# sns


# Q21.
# Create the average life expectancy line plot again,
# but completely remove the error bars.
#
# Hint:
# errorbar=None


# ============================================================
# LEVEL 7 — RELPLOT
# ============================================================

# Q22.
# Using sns.relplot(), create a line plot comparing
# the life expectancy of:
#
# Nepal
# Brazil
# Australia
#
# Use:
# kind="line"
# hue="country"


# Q23.
# Using sns.relplot(), compare:
#
# Nepal
# India
# China
# Japan
#
# Use:
# kind="line"
# hue="country"
# style="country"
# markers=True


# Q24.
# Using sns.relplot(), compare the GDP per capita
# of Nepal, India, China and Japan.
#
# Use:
# kind="line"
# hue="country"
# size="country"


# ============================================================
# LEVEL 8 — COL AND ROW
# ============================================================

# Q25.
# Using sns.relplot(), create separate line plots
# for every continent.
#
# Use:
# col="continent"
#
# Show average life expectancy over time.


# Q26.
# Using sns.relplot(), create separate plots for
# each continent.
#
# Requirements:
# - X → year
# - Y → lifeExp
# - col → continent
# - Add markers
# - Add a suitable title


# Q27.
# Use both row and col in sns.relplot().
#
# Create a visualization that separates the data
# into multiple panels.
#
# Choose appropriate variables for row and col.
#
# Compare life expectancy over time.


# ============================================================
# LEVEL 9 — FILTERING DATA
# ============================================================

# Q28.
# Create a new DataFrame containing only:
#
# Nepal
# India
# Pakistan
# Bangladesh
# Sri Lanka
#
# Plot their life expectancy over time.
#
# Use hue="country".


# Q29.
# Create a new DataFrame containing:
#
# Nepal
# India
# China
# Japan
# Australia
#
# Compare their life expectancy over time.
#
# Use:
# hue="country"
# style="country"
# markers=True


# Q30.
# Filter the dataset to include only countries
# where GDP per capita is greater than 20,000.
#
# Create a line plot showing GDP per capita over time.
#
# Use country as hue.


# ============================================================
# LEVEL 10 — CUSTOMIZATION
# ============================================================

# Q31.
# Create a Seaborn line plot comparing Nepal,
# India and China.
#
# Requirements:
# - figsize
# - title
# - X-axis label
# - Y-axis label
# - grid
# - legend
# - markers
# - hue="country"


# Q32.
# Create a line plot comparing Nepal, India,
# China and Japan.
#
# Customize:
# - Figure size
# - Line thickness
# - Markers
# - Marker size
# - Line style
# - Title
# - X-axis label
# - Y-axis label
# - Grid
# - Legend


# ============================================================
# LEVEL 11 — HARD
# ============================================================

# Q33.
# Create a line plot comparing:
#
# Nepal
# India
# China
# Japan
# Australia
#
# Requirements:
#
# X-axis       → year
# Y-axis       → lifeExp
# hue          → country
# style        → country
# size         → country
# markers      → True
# dashes       → True
#
# Add:
# - Title
# - X-axis label
# - Y-axis label
# - Grid
# - Legend
# - Appropriate figure size


# Q34.
# Create a line plot showing the average life expectancy
# of every continent over time.
#
# Requirements:
# - hue="continent"
# - estimator="mean"
# - markers=True
# - errorbar=None
# - title
# - X-axis label
# - Y-axis label
# - grid


# ============================================================
# FINAL CHALLENGE — EXPERT
# ============================================================

# Q35.
# Using the Gapminder dataset, create a Seaborn
# relational line plot comparing:
#
# Nepal
# India
# China
# Japan
# Australia
#
# Requirements:
#
# 1. Use sns.relplot().
#
# 2. kind must be "line".
#
# 3. X-axis → year
#
# 4. Y-axis → lifeExp
#
# 5. Use hue="country".
#
# 6. Use style="country".
#
# 7. Use size="country".
#
# 8. Add markers.
#
# 9. Use different line styles.
#
# 10. Use an appropriate estimator.
#
# 11. Configure errorbar appropriately.
#
# 12. Add a meaningful title.
#
# 13. Add X-axis and Y-axis labels.
#
# 14. Add a grid.
#
# 15. Configure the figure size.
#
# 16. Configure the legend.
#
# 17. Do NOT manually calculate the averages.
#
# 18. Do NOT use plt.plot().
#
# 19. Use only Seaborn for creating the line plot.
#
# 20. Make the final visualization clean and readable.
# ============================================================
# SEABORN REGPLOT() - ADVANCED PRACTICE
# Dataset: Tips Dataset
# ============================================================

import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px

# Load dataset
df = px.data.tips()

print(df)


# ============================================================
# QUESTION 1
# ============================================================
# Create a regression plot showing the relationship between
# total_bill and tip.
#
# Requirements:
#   x = total_bill
#   y = tip
#   Add a regression line.
#   Display the confidence interval.

# sns.regplot(data=df,x='total_bill',y='tip',ci=True)
# plt.grid()
# plt.show()
#
# Analyze whether the relationship is positive or negative.


# ============================================================
# QUESTION 2
# ============================================================
# Filter the dataset to include only customers who are smokers.
#
# Create a regression plot between:
#   x = total_bill
#   y = tip
# df=df[df['smoker'].isin(["Yes"])]
# sns.regplot(data=df,x='total_bill',y='tip')
# plt.grid()
# plt.show()
#
# Determine whether smokers show a strong or weak relationship
# between total_bill and tip.


# ============================================================
# QUESTION 3
# ============================================================
# Create TWO separate regression plots:
#
# 1. Male customers
# 2. Female customers

# df=df[df['sex'].isin(["Female"])]
# sns.regplot(data=df,x='total_bill',y='tip')
# plt.grid()
# plt.show()
#
# For both plots:
#   x = total_bill
#   y = tip
#
# Compare the regression lines.
#
# Determine which group has the steeper regression relationship.


# ============================================================
# QUESTION 4
# ============================================================
# Create a regression plot between total_bill and tip.
#
# Remove the confidence interval using:
#   ci=None
#
# Create another regression plot with the default confidence
# interval.
#
# Compare the two plots and explain what the confidence
# interval represents.
# sns.regplot(data=df,x='total_bill',y='tip',ci=None)
# plt.grid()
# plt.show()

# sns.regplot(data=df,x='total_bill',y='tip',ci=True)
# plt.grid()
# plt.show()
#

# ============================================================
# QUESTION 5
# ============================================================
# Create a regression plot using:
#   x = total_bill
#   y = tip
#
# Use:
#   order=2
#
# This should create a second-degree polynomial regression.
#
# Compare the polynomial regression with a normal linear
# regression and explain the difference.


# ============================================================
# QUESTION 6
# ============================================================
# Filter the dataset into:
#
#   Lunch
#   Dinner
#
# Create separate regression plots for both groups.
#
# Variables:
#   x = total_bill
#   y = tip
#
# Compare the regression slopes and determine whether the
# total_bill-to-tip relationship changes between lunch and dinner.


# ============================================================
# QUESTION 7
# ============================================================
# Create four separate regression plots for:
# df_1=df[df['day'].isin(['Sun'])]
# df_2=df[df['day'].isin(['Sat'])]
# df_3=df[df['day'].isin(['Fri'])]
# df_4=df[df['day'].isin(['Thur'])]
# sns.regplot(data=df,x='total_bill',y='tip',hue='day')
# plt.show()
#   Thur
#   Fri
#   Sat
#   Sun
#
# For each plot:
#   x = total_bill
#   y = tip
#
# Compare the regression lines and identify which day appears
# to have the strongest positive relationship.


# ============================================================
# QUESTION 8
# ============================================================
# Create a regression plot between:
#
#   x = size
#   y = tip
#
# Use the tips dataset.
#
# Determine whether the number of people at a table has a
# positive relationship with the tip amount.
#
# Explain why this relationship may be weaker or stronger
# than the total_bill-to-tip relationship.


# ============================================================
# QUESTION 9
# ============================================================
# Create a regression plot between:

# df=df[df['total_bill']>20]
# sns.regplot(data=df,x='total_bill',y='tip')
# plt.show()
#   x = total_bill
#   y = tip
#
# Then create another regression plot after filtering:
#
#   total_bill > 20
#
# Compare both regression lines.
#
# Determine how removing smaller bills affects the regression
# relationship.


# ============================================================
# QUESTION 10 - ADVANCED CHALLENGE
# ============================================================
# Perform a complete regression analysis using regplot().
#
# Step 1:
# Create a regression plot for the complete dataset:
#   x = total_bill
#   y = tip

sns.regplot(data=df,x='total_bill',y='tip',order=2,ci=None)
plt.show()
#
# Step 2:
# Create a second-degree polynomial regression using:
#   order=2
#
# Step 3:
# Remove the confidence interval using:
#   ci=None
#
# Step 4:
# Filter the data to:
#   smoker == "Yes"
#
# Create another regression plot.
#
# Step 5:
# Compare all three regression relationships.
#
# Explain:
#   1. Which relationship is strongest?
#   2. Is the relationship positive or negative?
#   3. Does polynomial regression fit the data differently?
#   4. What happens when the confidence interval is removed?
#   5. Does smoking status appear to change the relationship?
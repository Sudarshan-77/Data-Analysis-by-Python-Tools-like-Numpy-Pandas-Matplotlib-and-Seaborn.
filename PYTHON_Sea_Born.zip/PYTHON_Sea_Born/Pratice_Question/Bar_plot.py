# ============================================================
# ADVANCED SEABORN BAR PLOT PRACTICE — 10 QUESTIONS
# Dataset: Plotly Tips Dataset
# ============================================================

import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px
import numpy as np

df = px.data.tips()
print(df)

# ============================================================
# QUESTION 1
# ============================================================
# Find the MEDIAN total_bill for each day.
# Create a bar plot where:
# x = day
# y = total_bill
# estimator = median

# sns.barplot(data=df,x='day',y='total_bill',estimator='median',ci=None)
# plt.show()
# Do not display the confidence interval.


# ============================================================
# QUESTION 2
# ============================================================
# Compare the MEDIAN total_bill between smokers and non-smokers
# for each day.
#
# Create a bar plot where:
# x = day
# y = total_bill
# hue = smoker
# estimator = median
#

# sns.barplot(data=df,x='day',y='total_bill',hue='smoker',estimator='median',ci=None)
# plt.show()
# Which day shows the largest difference between smokers
# and non-smokers?


# ============================================================
# QUESTION 3
# ============================================================
# Compare the AVERAGE tip amount between Male and Female
# customers for each day.
#
# Create a bar plot where:
# x = day
# y = tip
# hue = sex
# estimator = mean
# sns.barplot(data=df,x='day',y='tip',hue='sex',estimator='mean',ci=None)
# plt.show()


# Which gender gives the higher average tip on most days?


# ============================================================
# QUESTION 4
# ============================================================
# Compare the MEDIAN tip amount during Lunch and Dinner
# for each day.
#
# Create a bar plot where:
# x = day
# y = tip
# hue = time
# estimator = median
# df=df[df['time'].isin(['Dinner'])]
# sns.barplot(data=df,x='day',y='tip',hue='time',estimator='median',ci=None)
# plt.show()


# df=df[df['time'].isin(['Lunch'])]
# sns.barplot(data=df,x='day',y='tip',hue='time',estimator='median',ci=None)
# plt.show()
# Identify the day where the difference between Lunch
# and Dinner median tips is the greatest.


# ============================================================
# QUESTION 5
# ============================================================
# Find the AVERAGE total_bill for each combination of:
#   Day + Smoker
#
# Create a bar plot using:
# x = day
# y = total_bill
# hue = smoker
# estimator = mean
# sns.barplot(data=df,x='day',y='total_bill',hue='smoker',estimator='mean')
# plt.show()

# Determine whether smokers or non-smokers generally
# have higher average bills.


# ============================================================
# QUESTION 6
# ============================================================
# Compare MEAN and MEDIAN total_bill by day.
#
# Create TWO separate bar plots:
#
# Plot 1 → estimator = mean
# Plot 2 → estimator = median
#
# sns.barplot(data=df,x='day',y='total_bill',estimator='mean')
# plt.show()

# sns.barplot(data=df,x='day',y='total_bill',estimator='median')
# plt.show()
# Compare the two plots.
#
# For which day is the difference between mean and median
# total_bill the largest?

"""At sunday, the difference between mean and median total_bill is the highest"""
#
# What might this difference tell you about the distribution?
"""The difference tell you that the average sale of sunday is generally more and generally there is no such outlier is in data who can make further chnage """


# ============================================================
# QUESTION 7
# ============================================================
# Compare the MAXIMUM total_bill for Male and Female
# customers across each day.
#
# Create a bar plot where:
# x = day
# y = total_bill
# hue = sex
# estimator = np.max

# sns.barplot(data=df,x='day',y='total_bill',hue='sex',estimator=np.max)
# plt.show()
# Identify:
# 1. The day with the highest maximum bill.
"""Saturday has the highest maximum bill"""

# 2. Whether the maximum bill belongs to Male or Female.
"""The maximum bill belong to Male"""


# ============================================================
# QUESTION 8
# ============================================================
# Compare the AVERAGE total_bill for Lunch and Dinner
# separately for smokers and non-smokers.
#
# Create a bar plot using:
# x = time
# y = total_bill
# hue = smoker
# estimator = np.mean
# df= df[~df['smoker'].isin(['No'])]
# sns.barplot(data=df,x='time',y='total_bill',hue='smoker',estimator=np.mean)
# plt.show()


# Answer:
# 1. Which time has the higher average bill?
"""At Dinner time has the higher average bill"""

# 2. Within each time, which smoker group has the higher average?
"""At Dinner time, the smoker group has the higher average"""



# ============================================================
# QUESTION 9
# ============================================================
# Investigate whether larger parties generate larger bills.
#
# Group customers according to the "size" column.
#
# Create a bar plot where:
# x = size
# y = total_bill
# estimator = np.mean
# sns.barplot(data=df,x='size',y='total_bill',estimator=np.mean)
# plt.show()
#
# Analyze:
# 1. Which party size has the highest average bill?
"""Part size 6 has the highest average bill"""

# 2. Does the average bill generally increase as party size increases?
"""yess"""

# 3. Are there any unusual increases or decreases?
"""No, There is not any unusual incereases or decreases"""


# ============================================================
# QUESTION 10 — FINAL CHALLENGE
# ============================================================
# Create a bar plot showing the MEDIAN total_bill for each day,
# separated by BOTH:
#   smoker
#   AND
#   sex
# sns.catplot(data=df,x='day',y='total_bill',hue='smoker',col='sex',estimator=np.median,kind='bar')
# plt.show()

# sns.barplot(data=df,x='day',y='total_bill',hue='smoker',col='sex',estimator=np.median)
# plt.show()
# You should use an appropriate Seaborn approach to display
# the two categorical variables.
#
# Your analysis should determine:
#
# 1. Which day has the highest median bill?
"""Saturday has the highest median bill"""

# 2. Which smoker group has the highest median?
""" Male smoker has the highest median as all"""


# 3. Which gender has the highest median?
""" Male gender has the highest median"""

# 4. Which combination of day + smoker + gender has the
#    highest median total_bill?
"""Male+smoker+Sundat has the highest median total_bill"""

# 5. Explain what the height of each bar represents.
"""The height of each bar represents the averga value of the data set"""
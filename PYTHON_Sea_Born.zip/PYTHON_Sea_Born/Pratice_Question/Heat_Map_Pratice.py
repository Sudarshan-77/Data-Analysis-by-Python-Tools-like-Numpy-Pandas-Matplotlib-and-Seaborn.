# ============================================================
# SEABORN HEATMAP / MATRIX PLOT
# PRACTICE QUESTIONS
# ============================================================

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt


# ============================================================
# QUESTION 1 - BASIC HEATMAP
# ============================================================

# Create this matrix:
#
#             Math    Science    English
# Ram          80       75         90
# Shyam        90       85         70
# Hari         70       95         80
# Sita         85       90         95
#
# Tasks:
# matrix={
#     "Name":[
#         "Ram","Ram","Ram",
#         "Shyam","Shyam","Shyam",
#         "Hari","Hari","Hari",
#         "Sita","Sita","Sita"
#     ],

#     "Subjects":[
#         "Math","Science","English",
#         "Math","Science","English",
#         "Math","Science","English",
#         "Math","Science","English",
#     ],

#     "Marks":[
#         80     ,  75        , 90,
#         90  ,     85    ,     70,
#         70    ,   95     ,    80,
#         85  ,     90       ,  95

#     ]




# }



# matrix=pd.DataFrame(matrix)
# 1. Create the matrix.
# matrix=matrix.pivot(index="Name",columns="Subjects",values="Marks")
# sns.heatmap(matrix,annot=True)
# plt.title("Marks representation of Students in different subjects using heat map")
# plt.show()
# 2. Create a heatmap using sns.heatmap().
# 3. Display the numbers inside the cells.
# 4. Add a title.
# 5. Display the graph.


# ============================================================
# QUESTION 2 - DATAFRAME + PIVOT + HEATMAP
# ============================================================

# Create this DataFrame:
#
# Student   Subject    Marks
# Ram       Math       80
# Ram       Science    75
# Ram       English    90
# Shyam     Math       90
# Shyam     Science    85
# Shyam     English    70
# Hari      Math       70
# Hari      Science    95
# Hari      English    80
#
# Tasks:
#
# 1. Create the DataFrame.
# 2. Use pivot() to convert it into matrix form.
# 3. Print the matrix.
# 4. Create a heatmap.
# 5. Use annot=True.


# ============================================================
# QUESTION 3 - UNDERSTAND PIVOT()
# ============================================================

# Using Question 2:
#
# Create the matrix using:
#
# index = Student
# columns = Subject
# values = Marks
#
# Answer:
#
# 1. What does index mean?
"""The index means the columns which are generally represent as rows in the dataset"""

# 2. What does columns mean?
"""The columns generally represent the columns in the dataset"""

# 3. What does values mean?
"""The values mean The actual value of the columns in the dataset"""

# 4. Why do we use pivot() before heatmap()?
"""We use pivot() before heatmap() because it arrange the dataset in wide format which is generally use to plot in heatmap"""


# ============================================================
# QUESTION 4 - SALES HEATMAP
# ============================================================

# Create this data:
#
# City       Month       Sales
# Kathmandu  January     500
# Kathmandu  February    700
# Kathmandu  March       800
# Pokhara    January     400
# Pokhara    February    600
# Pokhara    March       900
# Birgunj    January     300
# Birgunj    February    500
# Birgunj    March       700
# Tasks:

# matrix={
#     "City":["Kathmandu","Kathmandu","Kathmandu",
#             "Pokhara","Pokhara","Pokhara",
#             "Birgunj","Birgunj","Birgunj"],
#     "Month":["January","february","March",
#              "January","february","March",
#              "January","february","March"],
#     "Sales":[500,764,800,
#              400,670,900,
#              300,509,700]
# }
# matrix=pd.DataFrame(matrix)
# matrix=matrix.pivot(index="City",columns="Month",values="Sales")
# sns.heatmap(matrix,annot=True)
# plt.show()

# 1. Create the DataFrame.
# 2. Use pivot().
# 3. Create a heatmap.
# 4. Use annot=True.
# 5. Find the city with the highest sales.
"""Kathmandu City has the highest sales"""

# 6. Find the month with the highest sales.
"""Month march has the highest sales"""


# ============================================================
# QUESTION 5 - CHANGE THE COLOR MAP
# ============================================================

# Using Question 4:
#
# Create a heatmap using:
#
# cmap="coolwarm"
#
# Tasks:
#
# 1. Use annot=True.
# 2. Use cmap="coolwarm".
# 3. Add a title.
#

# matrix=pd.DataFrame(matrix)
# matrix=matrix.pivot(index="City",columns="Month",values="Sales")
# sns.heatmap(matrix,annot=True)

# Answer:
#
# What does cmap control?
"""The cmap control the color leveling of the heat map 
blue color generally represents the low value
red color generally represents the high value
another colors like lightblue ,yellow,orange falls on the interval between these two colors """


# ============================================================
# QUESTION 6 - ANNOTATION
# ============================================================

# Create two heatmaps from Question 4.
#
# Heatmap 1:
# annot=False

# sns.heatmap(matrix,annot=True)
# plt.show()
# Heatmap 2:
# annot=True

# sns.heatmap(matrix,annot=False)
# plt.show()
# Answer:
#
# 1. What is the difference?
"""The difference between them is the annot=True shows the actual number of theheat map, whereas the annot=False is unable to show the actual number of the heat map"""
# 2. Which one displays the actual numbers?
"""annot= True shows the actual number of the heat map"""
# 3. Why can annot=True become difficult to read
#    when there are hundreds of cells?

"""annot= True become difficult to read when there are hundreds of cells because 100 data may represents very large amount of the data set which have very different color
Also manually reading of each data become time consuming and messy """


# ============================================================
# QUESTION 7 - CORRELATION HEATMAP
# ============================================================
# Create this DataFrame:
#
# Age    Salary    Experience    Working_Hours
# 22     30000     1             8
# 25     40000     2             8
# 28     50000     4             9
# 32     65000     6             9
# 35     70000     8             10
# 40     85000     12            10
#

# matrix={
#     "Age":[22,25,28,32,35,40],
#     "Salary":[30000,40000,50000,65000,70000,850000],
#     "Experience":[1,2,4,6,8,12],
#     "Working_Hours":[8,8,9,9,10,10]
# }

# Tasks:
#
# matrix=pd.DataFrame(matrix)
# print(matrix)
# 1. Create the DataFrame.
# 2. Calculate the correlation matrix.
# matrix=matrix.corr()
# print(matrix)
# sns.heatmap(matrix,annot=True,cmap="coolwarm")
# plt.show()

# 3. Print the correlation matrix.
# 4. Create a heatmap.
# 5. Use annot=True.
# 6. Use cmap="coolwarm".
# 7. Use center=0.


# ============================================================
# QUESTION 8 - UNDERSTAND CORRELATION HEATMAP
# ============================================================

# Using Question 7:
#
# Answer:
#
# 1. What does 1.00 mean?
# 2. What does a value close to +1 mean?
# 3. What does a value close to -1 mean?
# 4. What does a value close to 0 mean?
# 5. Which variables have the strongest relationship?
# 6. Which variables have the weakest relationship?


# ============================================================
# QUESTION 9 - NEGATIVE CORRELATION
# ============================================================

# Create this DataFrame:
#
# Stress    Sleep_Hours
# 2         8
# 3         7
# 4         7
# 6         6
# 7         5
# 9         4
#
# Tasks:
#
# 1. Calculate the correlation.
# 2. Create a correlation heatmap.
# 3. Explain the correlation.
# 4. Is the correlation positive or negative?
# 5. Is correlation the same as causation?


# ============================================================
# QUESTION 10 - PIVOT_TABLE()
# ============================================================

# Create this data:
#
# Product    Region    Sales
# Laptop     East      1000
# Laptop     East      1200
# Laptop     West      900
# Phone      East      800
# Phone      West      1100
# Phone      West      1300
# Tablet     East      600
# Tablet     West      700
#
# Tasks:
#
# # 1. Create the DataFrame.
# matrx={
#     "Product":["Laptop","Laptop","Laptop",
#                "Phone","Phone","Phone",
#                "Tablet","Tablet"],
#     "Region":["East","East","West","East","West","West","East","West"],
#     "Sales":[1000,1200,900,800,1100,1300,600,700]
# }

# matrix=pd.DataFrame(matrx)



# # 2. Use pivot_table().
# matrix=matrix.pivot_table(index="Product",columns="Region",values="Sales",aggfunc="mean")
# sns.heatmap(matrix)
# plt.show()
# 3. Calculate the average sales.
# 4. Create a heatmap.
# 5. Use annot=True.
#
# Question:
#
# Why is pivot_table() useful when duplicate combinations
# exist?


# ============================================================
# QUESTION 11 - PIVOT VS PIVOT_TABLE
# ============================================================

# Explain the difference between:
#
# df.pivot()
#
# and
#
# df.pivot_table()
#
# Use Question 10 as an example.


# ============================================================
# QUESTION 12 - LARGE HEATMAP
# ============================================================

# Create data for:
#
# 10 products
# 12 months
#
# Generate random sales values between 100 and 1000.
#
# Tasks:
#
# 1. Create the DataFrame.
# 2. Convert it into matrix format.
# 3. Create a heatmap.
# 4. Use annot=False.
# 5. Add a title.
#
# Question:
#
# Why is annot=False better for a large matrix?


# ============================================================
# QUESTION 13 - WEBSITE TRAFFIC HEATMAP
# ============================================================

# Create website traffic data for:
#
# Days:
# Monday
# Tuesday
# Wednesday
# Thursday
# Friday
# Saturday
# Sunday
#
# Times:
# 8 AM
# 10 AM
# 12 PM
# 2 PM
# 4 PM
# 6 PM
# 8 PM
#
# # Tasks:
matrix={
    "Days":["Monday","Tuesday","Wednesday","Thrusday","Friday","Saturday","Sunday"],
    "Times":["8AM","10AM","12AM","2PM","4PM","6PM","8PM"],
    "Traffic":[200,400,500,300,100,600,350]
}


matrix=pd.DataFrame(matrix)
# matrix=matrix[matrix["Days"].isin(["Monday","Tuesday","Wednesday","Thrusday","Friday"])]
# matrix=matrix.pivot(index="Days",columns="Times",values="Traffic")
# sns.heatmap(matrix)
# plt.show()

# matrix=matrix[matrix["Days"].isin(["Saturday","Sunday"])]
matrix=matrix.pivot(index="Days",columns="Times",values="Traffic")
sns.clustermap(matrix)
plt.show()


#
# 1. Create the data.
# 2. Convert it into matrix format.
# 3. Create a heatmap.
# 4. Identify the busiest day.
"""Saturday is the busiest day"""

# 5. Identify the busiest time.
"""6 AM is the busiest time"""

# 6. Compare weekday and weekend traffic."""



# ============================================================
# QUESTION 14 - HEATMAP WITH MASK
# ============================================================

# Create a correlation matrix.
#
# Then create a mask using:
#
# mask = np.triu(np.ones_like(corr, dtype=bool))
#
# Tasks:
#
# 1. Create the correlation matrix.
# 2. Create the mask.
# 3. Use the mask inside sns.heatmap().
# 4. Display only one triangle of the correlation matrix.
# 5. Use annot=True.


# ============================================================
# QUESTION 15 - ADVANCED CORRELATION HEATMAP
# ============================================================

# Create an advanced correlation heatmap using:
#
# annot=True
# cmap="coolwarm"
# center=0
# square=True
# linewidths=0.5
#
# Also hide one triangle of the matrix.
#
# Answer:
#
# Explain the purpose of each parameter.


# ============================================================
# QUESTION 16 - INTERPRET A CORRELATION MATRIX
# ============================================================

# Suppose you have:
#
#              A       B       C       D
# A           1.00    0.92    0.15   -0.70
# B           0.92    1.00    0.20   -0.65
# C           0.15    0.20    1.00   -0.10
# D          -0.70   -0.65   -0.10    1.00
#
# Answer:
#
# 1. Which pair has the strongest positive correlation?
# 2. Which pair has the strongest negative correlation?
# 3. Which pair has the weakest correlation?
# 4. What does 0.92 mean?
# 5. What does -0.70 mean?
# 6. What does 0.15 mean?
# 7. Does 0.92 prove that A causes B?


# ============================================================
# QUESTION 17 - HEATMAP VS BAR CHART
# ============================================================

# You have sales data for:
#
# 10 products
# 12 months
#
# Answer:
#
# 1. Would you choose a heatmap or bar chart?
"""I would choose heat map in this condition"""
# 2. Why?
"""Heat map is generally used to compare large data"""

# 3. When is a bar chart better?
"""Bar chart is considered when there is generally less amount of the data in our dataset, two dimesnional data,"""

# 4. When is a heatmap better?
"""Heatmap is better when there is generally more amount of the data in our dataset, three dimensional data"""



# ============================================================
# QUESTION 18 - HEATMAP VS KDE
# ============================================================

# You have salary data for:
#
# IT
# Finance
# Marketing
# HR
#
# Answer:
#
# 1. Would you use a heatmap or KDE plot?
# 2. Why?
# 3. What does a heatmap show?
# 4. What does KDE show?


# ============================================================
# QUESTION 19 - FIND HIGHEST AND LOWEST VALUES
# ============================================================

# Create this matrix:
#
#              Jan    Feb    Mar    Apr
# Product A    500    700    600    800
# Product B    900    600    750    850
# Product C    400    800    950    700
# Product D    600    500    650    900
#
# Tasks:

# df={
#     "Category":["Product A","Product A","Product A","Product A","Product B","Product B","Product B","Product B","Product C","Product C","Product C","Product C","Product D","Product D","Product D","Product D"],
#     "Months":["Jan","Jan","Jan","Jan",
#               "Feb","Feb","Feb","Feb",
#               "Mar","Mar","Mar","Mar",
#               "Apr","Apr","Apr","Apr"],
#     "Sales":[500,900,400,600,
#              700,600,800,500,
#              600,750,950,650,
#              800,850,700,900]
# }
# df=pd.DataFrame(df)
# df=df.pivot(index="Category",columns="Months",values="Sales")
# sns.clustermap(df)
# plt.show()
# 1. Create the heatmap.
# 2. Find the highest value.
# 3. Find the lowest value.
# 4. Find the highest March sales.
# 5. Find the month with the highest overall sales.


# ============================================================
# QUESTION 20 - FINAL ADVANCED CHALLENGE
# ============================================================

# Create a DataFrame containing at least 5 numerical columns.
#
# Tasks:
#
# 1. Calculate the correlation matrix.
# 2. Create a heatmap.
# 3. Use annot=True.
# 4. Use cmap="coolwarm".
# 5. Use center=0.
# 6. Use square=True.
# 7. Use linewidths=0.5.
# 8. Create a mask.
# 9. Hide one triangle.
# 10. Find the strongest positive correlation.
# 11. Find the strongest negative correlation.
# 12. Find the weakest correlation.
# 13. Explain why the diagonal contains 1.00.
# 14. Explain why the correlation matrix is symmetrical.
# 15. Explain why correlation does not mean causation.
# 16. Write 3 conclusions based on your heatmap.


# ============================================================
# IMPORTANT MEMORY
# ============================================================

# pivot()
#     -> Rearranges data into matrix format
#
# pivot_table()
#     -> Creates a summarized matrix
#
# corr()
#     -> Creates a correlation matrix
#
# sns.heatmap()
#     -> Visualizes a matrix using colors
#
# annot=True
#     -> Displays values inside cells
#
# cmap
#     -> Controls the color scheme
#
# center=0
#     -> Makes 0 the center of the color scale
#
# mask
#     -> Hides selected cells
#
# ============================================================
# END OF PRACTICE QUESTIONS
# ============================================================
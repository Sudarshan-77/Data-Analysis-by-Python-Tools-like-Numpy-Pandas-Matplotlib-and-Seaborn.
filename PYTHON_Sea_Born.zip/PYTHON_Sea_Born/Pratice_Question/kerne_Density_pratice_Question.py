# ============================================================
# ADVANCED SEABORN KDE (KERNEL DENSITY ESTIMATE) QUESTIONS
# ============================================================

import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px

df = px.data.gapminder()
# print(df)
# df=df[df['year'].isin([1952,1957,1962])]
# print(df)


# ============================================================
# QUESTION 1 - Basic KDE
# ============================================================
# Create a KDE plot of "lifeExp".
#
# Requirements:
# - x = "lifeExp"
# - Add an appropriate title
# - Add X-axis and Y-axis labels


# sns.displot(data=df,x="lifeExp",label='KDE plot of "lifeExp"',kind='kde')
# plt.grid()
# plt.show()
# Analyze:
# - Where is the highest concentration of observations?
"""The highest concentration of observations is near 71"""

# - Is the distribution symmetric or skewed?
"""The distibution is positively skewed"""



### bw_adjust helps to adjust the bandwidth of the kde plot

# ============================================================
# QUESTION 2 - KDE with Bandwidth
# ============================================================
# Create a KDE plot of "lifeExp".
#
# Requirements:
# - x = "lifeExp"
# - Experiment with different bandwidth values using:
#       bw_adjust=0.5
#       bw_adjust=1
#       bw_adjust=2
# sns.displot(data=df,x='lifeExp',bw_adjust=0.5,kind='kde')
# sns.displot(data=df,x='lifeExp',bw_adjust=2,kind='kde')
# plt.show()

# Analyze:
# - What happens when bw_adjust is decreased?
""" bw_adjust is decreased then the plot focus on lower change but the smoothness of the graph decreases"""

# - What happens when bw_adjust is increased?
""" bw_adjust is increased then the plot don't focus on lower change but the smoothness of the graph increases"""

# - Which setting produces the smoothest curve?
""" higher the bw value, the setting produces the smothest curve"""



# ============================================================
# QUESTION 3 - KDE by Continent
# ============================================================
# Create KDE curves of "lifeExp".
#
# Requirements:
# - x = "lifeExp"
# - hue = "continent"
# sns.kdeplot(data=df,x='lifeExp',hue='continent')
# plt.show()


# Analyze:
# - Which continent has the highest concentration of
#   life expectancy?
"""Europe continent has the highest concentration of life expectancy"""

# - Which continent has the widest distribution?
""" Asia has the widest distribution"""

# - Which distributions overlap?
"""The distributions of the Asia and Americas overlap"""


# ============================================================
# QUESTION 4 - Filled KDE
# ============================================================
# Create a filled KDE plot of "lifeExp".
#
# Requirements:
# - x = "lifeExp"
# - hue = "continent"
# - Use:
#       fill=True
# sns.kdeplot(data=df,x = "lifeExp",hue = "continent",fill=True)
# plt.show()

#
# Analyze:
# - Which distributions have the largest area of overlap?

""" America and Asia have the largest area of overlap"""



# - Which continent appears most separated from the others?
""" Africa and Europe are appears most separated from each other"""


# ============================================================
# QUESTION 5 - KDE with Multiple Groups
# ============================================================
# Create KDE plots of "gdpPercap".
#
# Requirements:
# - x = "gdpPercap"
# - hue = "continent"
# - Use:
#       common_norm=False


# sns.kdeplot(data=df,x='gdpPercap',hue='continent',common_norm=False)
# plt.show()
# - Which continent has the widest distribution?


# ============================================================
# QUESTION 6 - KDE with Cut Parameter
# ============================================================
# Create a KDE plot of "lifeExp".
#
# Requirements:
# - x = "lifeExp"
# - Use:
#       cut=0


# Compare it with the default KDE.

# sns.kdeplot(data=df,x='lifeExp',cut=0)
# plt.show()
# Analyze:
# - What does the cut parameter control?\
"""Cut parameter helps to control the anormous minimum and maximum distribution of kde plot"""

# - Why might cut=0 be useful?
"""Cut=0 might be useful because it helps to deduce the kde plot to its actual length"""

# - How does the boundary of the KDE change?
"""The boundary of the KDE change accoring to the value of cut function 
Lower the value of cut the distribution of the boundary will be less
Higher the value of of the cut function the distribution of the bounday will be more"""



# ============================================================
# QUESTION 7 - KDE with Multiple Years
# ============================================================
# Create KDE plots of "lifeExp".

# Requirements:
# - Select at least 3 different years.
# sns.kdeplot(data=df,x='lifeExp',hue='year')
# plt.show()


# - Use "year" as the grouping variable.
# - Compare the KDE curves for the selected years.
"""As the year passed the life Expectancy of the countries become better generally from the past years"""
# Analyze:
# - How does the distribution of life expectancy shift over time?
"""The distribution of the life expectancy generally shift from left to right """

# - Does the peak move toward higher life expectancy?
"""The peak generally decrease toward the higher life expectancy"""

# - Does the spread change over time?


# ============================================================
# QUESTION 8 - KDE + Histogram
# ============================================================
# Create a histogram and KDE curve for "lifeExp".
#
# Requirements:
# - Use 30 bins.
# - Add KDE using:
#       kde=True
# - Normalize the histogram appropriately.
# sns.histplot(data=df,bin=30,kde=True)
# plt.show()


# Analyze:
# - How does the KDE curve relate to the histogram?
# - Why can the KDE curve be easier to interpret than the bars?
# - Does the KDE accurately represent the shape of the histogram?


# ============================================================
# QUESTION 9 - KDE Comparison Using Bandwidth
# ============================================================
# Create three KDE plots of "gdpPercap".
#
# Requirements:
# - Use:
#       bw_adjust=0.2
#       bw_adjust=1
#       bw_adjust=3
#
# Analyze:
# - Which curve is most sensitive to small variations?
# - Which curve is oversmoothed?
# - Which curve best represents the overall distribution?
# - What problem can occur when bandwidth is too small?
# - What problem can occur when bandwidth is too large?


# ============================================================
# QUESTION 10 - EXPERT LEVEL KDE
# ============================================================
# Analyze the distribution of "gdpPercap" using KDE.
#
# Requirements:
# - x = "gdpPercap"
# - hue = "continent"
# - fill=True
# - common_norm=False
# - Use an appropriate bandwidth adjustment.
# - Customize the title, axis labels, and figure size.

sns.kdeplot(data=df,x='gdpPercap',hue='continent')
plt.show()
#
# Analyze:
#
# 1. Which continent has the highest concentration of
#    GDP per capita?
"""Afria continetn has the highest concentration of GDP per capita """


# 2. Which continent has the widest distribution?
"""Europe continent has the widest distribution"""

# 3. Which distributions overlap heavily?
"""Africa and Asia distributions overlap heavily"""


# 4. Which distributions appear strongly skewed?
"""Asia distributons appear strongly skewed"""

#
# 5. Are there multiple peaks?
""" No, There is only multiple speaks"""

# 6. What could multiple peaks indicate?


# 7. What happens when bw_adjust is too small?
"""If bw_adjust is too small then, the graph will show the detail information but the graph is rough."""

# 8. What happens when bw_adjust is too large?
#
# 9. Why is KDE useful for comparing distributions?
"""A KDE plot is useful for comparing distributions because it lets you easily see how the values are spread for different groups."""

# 10. What are the limitations of using KDE for this dataset?
"""The limitations of using KDE for this dataset are it is hard to understand for beginners"""
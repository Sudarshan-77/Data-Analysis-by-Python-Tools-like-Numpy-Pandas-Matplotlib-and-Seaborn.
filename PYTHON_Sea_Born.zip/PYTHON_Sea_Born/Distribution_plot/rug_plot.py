# A KDE plot is used to show the distribution of numerical data. It is similar to a histogram, but instead of bars, it draws a smooth density curve.


import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px

df=px.data.tips()
# print(df)

sns.kdeplot(data=df,x='total_bill',hue='sex')
sns.rugplot(data=df,x='total_bill',hue='sex')
print(plt.show())
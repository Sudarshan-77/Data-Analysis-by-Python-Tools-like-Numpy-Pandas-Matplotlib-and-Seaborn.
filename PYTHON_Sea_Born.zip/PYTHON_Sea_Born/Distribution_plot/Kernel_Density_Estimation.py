"""A KDE plot is used to show the distribution of numerical data. It is similar to a histogram, but instead of bars, it draws a smooth density curve."""

import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px

df=px.data.tips()
print(df)


#--------------------------------------------------------------
#bw_adjust
""" bw_adjust helps to adjust the bandwidth of the kde plot

1. Lower bw_adjust value it means it focus on smaller changes on the distribution plot--- higher information and lower smoothness
2. Higher bw_adjust value it means it generally doesnot focus on smaller changes on the distribution plot--- higher smoothness and but lower information
"""

## Plotting Across Excess
# sns.kdeplot(data=df,x='total_bill')
# print(plt.show())




## Plotting Across Figure
# sns.displot(data=df,x='total_bill',kind='kde',hue='sex')
# print(plt.show())



## Batrick plot in kde
"""Bivariate Plot means Two dimensional plots 
here we pass two values . one of x and another of y"""

sns.displot(data=df,x='total_bill',y='tip',kind='kde',hue='sex')
print(plt.show())

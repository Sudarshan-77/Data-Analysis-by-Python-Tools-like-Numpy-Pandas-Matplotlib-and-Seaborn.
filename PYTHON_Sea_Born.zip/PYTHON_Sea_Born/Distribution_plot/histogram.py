"""A histogram is a graph used to show the distribution of numerical data.

It groups numerical values into ranges (called bins) and shows how many observations fall within each range."""
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px

# # Loads tips dataset locally from Plotly (no internet required)
df = px.data.tips()

# sns.displot(data=df,x='total_bill',kind='hist',hue='sex')
# print(plt.show())

"""--------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------"""
# common_norm=True
# → Treat both classes as one overall population when normalizing.

# common_norm=False
# → Analyze Class A separately and Class B separately.

# ============================================================
# HISTOGRAM PRACTICE QUESTIONS
# ============================================================

import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px

# Load dataset
df = px.data.iris()

print(df)


# ============================================================
# BASIC HISTOGRAM
# ============================================================

# Q1. Create a histogram of the "sepal_length" column.
# sns.displot(data=df,x='sepal_length',kind='hist')

# Q2. Create a histogram of the "sepal_width" column.
# sns.displot(data=df,x='sepal_width',kind='hist')

# Q3. Create a histogram of the "petal_length" column.
# sns.displot(data=df,x='petal_length',kind='hist')

# Q4. Create a histogram of the "petal_width" column.
# sns.displot(data=df,x='petal_width',kind='hist')

# Q5. Create a histogram using sns.histplot().


# ============================================================
# BINS
# ============================================================

# Q6. Create a histogram of sepal_length with 5 bins.
# sns.displot(data=df,x='sepal_length',kind='hist',bins=5)


# Q7. Create a histogram of sepal_length with 10 bins.
# sns.displot(data=df,x='sepal_length',kind='hist',bins=10)


# Q8. Create a histogram of sepal_length with 20 bins.
# sns.displot(data=df,x='sepal_lenth',bins=20)


# Q9. Compare the histograms with 5, 10, and 20 bins.
# What difference do you observe?


# ============================================================
# HUE
# ============================================================

# Q10. Create a histogram of sepal_length
# using species as hue.

# sns.displot(data=df,x='sepal_length',kind='hist',bins=10,hue='species')

# Q11. Create a histogram of petal_length
# using species as hue.




# Q12. Create a histogram of petal_width
# using species as hue.


# ============================================================
# KDE
# ============================================================

# Q13. Create a histogram of sepal_length
# and add a KDE curve.

# sns.histplot(data=df,x='sepal_length',kde=True,hue='species')
sns.displot(data=df,x='sepal_length',kind='hist',kde=True)
# Q14. Create a histogram of petal_length
# and add a KDE curve.


# Q15. Create a histogram with:
# kde=True
# bins=15


# ============================================================
# MULTIPLE HISTOGRAMS
# ============================================================

# Q16. Create histograms for sepal_length
# and sepal_width.


# Q17. Create histograms for petal_length
# and petal_width.


# Q18. Create separate histograms for each species.


# ============================================================
# DATA ANALYSIS
# ============================================================

# Q19. From the histogram of sepal_length,
# identify the approximate range where most values occur.


# Q20. From the histogram of petal_length,
# identify whether the data appears normally distributed
# or skewed.


# Q21. Create a histogram of sepal_length
# and determine which range contains the highest frequency.


# Q22. Create a histogram of petal_width
# and identify the range with the fewest observations.


# Q23. Create a histogram of sepal_length
# with 10 bins and KDE.
# Describe the distribution.


# ============================================================
# TIPS DATASET
# ============================================================

# Load tips dataset
tips = px.data.tips()


# Q24. Create a histogram of total_bill.


# Q25. Create a histogram of tip.


# Q26. Create a histogram of size.


# Q27. Create a histogram of total_bill
# using bins=20.


# Q28. Create a histogram of total_bill
# with KDE.


# Q29. Create a histogram of total_bill
# using smoker as hue.


# Q30. Create a histogram of total_bill
# using sex as hue.


# ============================================================
# CONCEPTUAL QUESTIONS
# ============================================================

# Q31. What is a histogram?


# Q32. What is the difference between a histogram
# and a bar chart?


# Q33. What does the X-axis represent in a histogram?


# Q34. What does the Y-axis represent in a histogram?


# Q35. What are bins in a histogram?


# Q36. What happens when you increase the number of bins?


# Q37. What happens when you decrease the number of bins?


# Q38. What is frequency in a histogram?


# Q39. What is density in a histogram?


# Q40. What is KDE?


# Q41. What does kde=True do in sns.histplot()?


# Q42. Can a histogram be used for categorical data?
# Explain why or why not.


# Q43. Is a histogram mainly used for numerical
# or categorical data?


# Q44. What is the difference between
# frequency and density?


# Q45. What type of distribution can a histogram help you identify?


# ============================================================
# CHALLENGE QUESTIONS
# ============================================================

# Q46. Create a histogram of total_bill with 15 bins
# and KDE.


# Q47. Create a histogram of total_bill
# grouped by smoker.


# Q48. Create a histogram of tip
# grouped by sex.


# Q49. Create a histogram of petal_length
# grouped by species.


# Q50. Create a histogram and determine
# whether the data contains any possible outliers.


# ============================================================
# IMPORTANT FUNCTION
# ============================================================

# sns.histplot(
#     data=df,
#     x="sepal_length",
#     bins=10,
#     kde=True
# )


# IMPORTANT PARAMETERS
#
# data  -> Dataset/DataFrame
# x     -> Numerical variable
# bins  -> Number of intervals
# kde   -> Adds KDE curve
# hue   -> Groups data by category
# stat  -> Controls what the Y-axis represents
#
# ============================================================



## Batrick plot in Histograms
"""Bivariate Plot means Two dimensional plots 
here we pass two values . one of x and another of y"""

# sns.displot(data=df,x='total_bill',y='tip',kind='hist')
print(plt.show())


# ============================================================
# SEABORN SCATTER PLOT - HARD PRACTICE QUESTIONS
# DATASET: PLOTLY GAPMINDER
# ============================================================

import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
import plotly.express as px


# ------------------------------------------------------------
# DATASET
# ------------------------------------------------------------

df = px.data.gapminder()
print(df)


# sns.scatterplot(data=df,x='continent',y='country')
# plt.show()
# print(df.head())
# print(df.info())
# print(df.describe())


# ============================================================
# LEVEL 1 - BASIC
# ============================================================

# Q1. Create a scatter plot showing the relationship between
#     GDP per capita (gdpPercap) and life expectancy (lifeExp).



# Q2. Put gdpPercap on the x-axis and population (pop)
#     on the y-axis.
# plt.xlabel("gdpPercap")
# plt.ylabel("population")

# Q3. Add a title:
#     "GDP per Capita vs Life Expectancy"
# plt.title("GDP per Capita vs Life Expectancy")


# Q4. Change the x-axis label to:
#     "GDP per Capita"

#
#     Change the y-axis label to:
#     "Life Expectancy"


# Q5. Add a grid to your scatter plot.


# ============================================================
# LEVEL 2 - HUE
# ============================================================

# Q6. Create a scatter plot showing:
#
#     x = gdpPercap
#     y = lifeExp
#
#     Use "continent" as hue.
#
#     Question:
#     Can you visually distinguish the continents?


# Q7. Create a scatter plot of:
#
#     x = pop
#     y = lifeExp
#
#     Use:
#     hue = continent


# Q8. Create a scatter plot of:
#
#     x = gdpPercap
#     y = lifeExp
#
#     Use:
#     hue = year
#
#     Question:
#     Does the relationship appear different across years?


# ============================================================
# LEVEL 3 - STYLE AND SIZE
# ============================================================

# Q9. Create a scatter plot using:
#
#     x = gdpPercap
#     y = lifeExp
#     hue = continent
#     style = continent


# Q10. Create a scatter plot using:
#
#     x = gdpPercap
#     y = lifeExp
#     hue = continent
#     size = pop
#
#     Question:
#     What does the size of each point represent?


# Q11. Create a scatter plot using:
#
#     x = pop
#     y = lifeExp
#     hue = continent
#     style = continent
#
#     Question:
#     Is this visualization easy to understand?
#     If not, explain why.


# ============================================================
# LEVEL 4 - FILTERING
# ============================================================

# Q12. Find the number of missing values in every column.


# Q13. Create a scatter plot of:
#
#     gdpPercap vs lifeExp
#
#     Without manually removing missing values.
#
#     Observe what happens.


# Q14. Create a new DataFrame containing only rows where:
#
#     gdpPercap
#     lifeExp
#
#     are not missing.
#
#     Then create the scatter plot again.


# ============================================================
# LEVEL 5 - FILTERING BY CATEGORY
# ============================================================

# Q15. Create a scatter plot using ONLY countries
#     from the Asia continent.
#
#     x = gdpPercap
# #     y = lifeExp
# df=df[df['continent'].isin(['Asia'])]
# sns.scatterplot(data=df,x='gdpPercap',y='lifeExp',hue='country')


# Q16. Create a scatter plot using ONLY countries
#     from Europe.
#
#     x = gdpPercaps
#     y = lifeExp


# Q17. Create a scatter plot using ONLY countries whose
#     population is greater than 100,000,000.

# df=df[df['pop']>100000000]
# sns.scatterplot(data=df,x='gdpPercap',y='lifeExp',hue='country')

# Q18. Create a scatter plot using ONLY countries from:
#
#     continent = Africa
#
#     x = gdpPercap
#     y = lifeExp
#
#     Use year as hue.

# df=df[df['continent'].isin(['Africa'])]
# sns.regplot(data=df,x='country',y='lifeExp')



# ============================================================
# LEVEL 6 - RELATIONSHIP ANALYSIS
# ============================================================

# Q19. Create a scatter plot of:
#
#     gdpPercap vs lifeExp
#
#     Use continent as hue.
#
#     Answer:
#     Is there a positive relationship between GDP per capita
#     and life expectancy?


# Q20. Create a scatter plot of:
#
#     pop vs lifeExp
#
#     Use continent as hue.
#
#     Answer:
#     Does the relationship appear strong or weak?


# Q21. Create three separate scatter plots for:
#
#     Africa
#     Asia
#     Europe
#
#     Compare:
#
#     gdpPercap vs lifeExp
#
#     Question:
#     Which continent appears to have the strongest
#     relationship?


# ============================================================
# LEVEL 7 - REGRESSION
# ============================================================

# Q22. Use sns.regplot() to visualize the relationship between:
#
#     gdpPercap
#     lifeExp
#
#     Add a regression line.


# Q23. Compare the following:
#
#     sns.scatterplot()
#     sns.regplot()
#
#     Question:
#     What additional information does regplot provide?


# Q24. Create a regression plot for ONLY Asian countries.
#
#     x = gdpPercap
#     y = lifeExp


# ============================================================
# LEVEL 8 - FACETING
# ============================================================

# Q25. Use sns.relplot() to create scatter plots of:
#
#     x = gdpPercap
#     y = lifeExp
#
#     Create separate plots for each continent.


# Q26. Create a faceted scatter plot where:
#
#     x = gdpPercap
#     y = lifeExp
#     hue = continent
#     col = continent
#
#     Question:
#     What differences can you observe between continents?


# Q27. Create a faceted scatter plot where:
#
#     x = gdpPercap
#     y = lifeExp
#     hue = continent
#     col = year
#
#     Question:
#     How does the relationship change over time?


# ============================================================
# LEVEL 9 - ADVANCED
# ============================================================

# Q28. Create a scatter plot where:
#
#     x = gdpPercap
#     y = lifeExp
#     hue = continent
#     size = pop
#     style = continent
#
#     Make the plot easy to understand with:
#
#     - title
#     - x-label
#     - y-label
#     - legend


# Q29. Find the correlation between:
#
#     lifeExp
#     gdpPercap
#     pop
#     year
#
#     Then choose the TWO variables with the strongest
#     relationship and create a scatter plot for them.


# Q30. Create a scatter plot of the two variables you selected
#     in Q29.
#
#     Use continent as hue.
#
#     Then explain:
#
#     1. Direction of relationship
#     2. Strength of relationship
#     3. Possible outliers
#     4. Differences between continents


# ============================================================
# LEVEL 10 - FINAL BOSS 💀
# ============================================================

# Q31. Perform a complete scatter-plot analysis of the
#     Gapminder dataset.
#
#     Your analysis must:
#
#     1. Find missing values.
#
#     2. Remove rows necessary for your analysis.
#
#     3. Calculate correlations between numerical variables.
#
#     4. Identify the strongest positive relationship.
#
#     5. Identify the strongest negative relationship.
#
#     6. Create a scatter plot for the strongest positive
#        relationship.
#
#     7. Use continent as hue.
#
#     8. Use continent as style.
#
#     9. Use population as size.
#
#     10. Create a regression plot for the overall dataset.
#
#     11. Create separate regression plots for each continent.
#
#     12. Explain whether the relationship is consistent
#         across continents.
#
#     13. Identify possible outliers from the visualization.
#
#     14. Write a final conclusion based on your analysis.


# ============================================================
# BONUS CHALLENGE 🔥
# ============================================================

# Without looking at documentation:
#
# Create ONE scatter plot that simultaneously represents:
#
#     X-axis       → gdpPercap
#     Y-axis       → lifeExp
#     Color        → continent
#     Shape        → continent
#     Size         → pop
#
# Then answer:
#
# "Can you understand the relationship between GDP per capita
# and life expectancy while simultaneously comparing
# continents and population?"
#
# If the visualization becomes too complicated, redesign it
# using fewer visual variables and explain your decision.

# plt.show()



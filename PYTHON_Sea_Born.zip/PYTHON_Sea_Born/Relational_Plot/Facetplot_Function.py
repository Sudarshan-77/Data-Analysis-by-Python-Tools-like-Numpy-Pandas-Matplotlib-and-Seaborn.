"""A facet plot is a technique in Plotly that divides one dataset into multiple smaller plots based on a categorical column.

Instead of putting everything into one graph, you get several graphs side by side or one below another."""



"""It will only work with the figure level function. It means it will only work with relplot function whetehr it doesnot work with axes level functions"""

import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px


df=px.data.tips()
print(df)


#Use of Column Wrap Function
"""Column Wrap Function helps us to wrap the no of figures in a respective column then it pass the next coolumns in the another rows"""
sns.relplot(data=df,x='total_bill',y='tip',col='day',col_wrap=2)
print(plt.show())
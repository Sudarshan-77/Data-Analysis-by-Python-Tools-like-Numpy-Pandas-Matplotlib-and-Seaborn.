import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px

df=px.data.gapminder()
asian_giants=df[df['country'].isin(["Nepal","Brazil","Australia"])]

# print(df)


sns.relplot(data=asian_giants,x="year",y="lifeExp",kind='line',marker="o",hue='country',size='continent')
plt.grid()
print(plt.show())



# sns.relplot(data=asian_giants,x='year',y='lifeExp',kind='line')


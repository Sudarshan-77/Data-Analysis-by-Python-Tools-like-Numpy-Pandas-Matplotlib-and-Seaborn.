"""A cluster map is similar to a heatmap, but it also performs hierarchical clustering.
It rearranges the rows and columns so that similar observations are placed close together. """

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px
# df = px.data.iris()

df={
    "Name":["Sudarshan Chaudhary","Ram Dev Shah Lahera","Rahul Gupta"],
    "Subject":[100,50,60],
    "Marks":[60,70,90]
}
# print(df)
df=pd.DataFrame(df)

data=df[["Marks","Subject"]]
sns.clustermap(data,standard_scale=1,cmap="coolwarm")
plt.show()

# Heat_map
"""A heatmap is a data visualization that represents values using different colors.
It is especially useful for finding patterns, relationships, and high/low values in a dataset."""

# It is only used with axes level function

# # It is generally  used with wide data format but we can also used it with long data format but which can produce messy data

# Correlaition matrix
""" Correlation matrix contains the matrix that have mutiple numerical values"""

import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px

df=px.data.tips()
df=px.data.gapminder()

# print(df)
# pivoted_value=df.pivot(index='country',columns='year',values='lifeExp')
# print(plt.figure(figsize=(10,5)))
sns.heatmap(index='country',columns='year',values='lifeExp')
plt.show()


# # print(plt.show())

# new=df[df["continent"]=="Europe"]


# new=new.pivot(index='country',columns='year',values='lifeExp')
# print(plt.figure(figsize=(15,15)))




# """vvI"""
# ## annot Function generally helps us to show  in whcih country and in which year the life expectancy is how much 
# sns.heatmap(new,annot=True,linewidths=0.9,cmap='plasma')
# print(plt.show())



#cmap
# C-map generally represents the color of the map Greens display greenish color,Blues display the blueish color
""""viridis"
"plasma"
"inferno"
"magma"
"cividis"
"Blues"
"Greens"
"Reds"
"Oranges"
"Purples"
"YlOrRd"
"YlGnBu"""


# If we have plot only of the asian countries then


# import seaborn as sns
# import matplotlib.pyplot as plt

# data = [
#     [80, 75, 90],
#     [70, 85, 80],
#     [95, 90, 88]
# ]

# sns.heatmap(data, annot=True)

# plt.show()
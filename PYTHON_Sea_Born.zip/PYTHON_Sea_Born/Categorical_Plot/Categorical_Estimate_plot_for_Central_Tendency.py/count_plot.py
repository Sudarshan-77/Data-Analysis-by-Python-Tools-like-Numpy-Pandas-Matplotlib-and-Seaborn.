## Count Plot

"""Count Plot function is used for categorical data Such"""


import matplotlib.pyplot as plt
import seaborn as sns
import plotly as px

df=px.data.tips()
# print(df)
sns.countplot(data=df,x='day',hue='sex')
plt.show()
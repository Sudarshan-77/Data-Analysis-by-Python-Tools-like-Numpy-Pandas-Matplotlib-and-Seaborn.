# Bar Plot
"""Bar Plot simply known as bar diagram is the type of Categorical_Estimate_plot helps to compares values between two categories"""


import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px

df=px.data.tips()
# print(df)


## Plotting it in a bar diagram. Here, we go 

# sns.barplot(data=df,x='day',y='total_bill',ci=None)
# plt.show()




## We can work with different types of function in bar plot by calling numpy.
import numpy as np
# # Median 

# highest=df["total_bill"].max()
# print(highest)
# df=df['total_bill'].count() * ["Blue"]

sns.barplot(data=df,x='day',y='total_bill',estimator=np.median,ci=None)
plt.show()


# # Mean 
# sns.barplot(data=df,x='day',y='total_bill',estimator=np.mean,ci=None)


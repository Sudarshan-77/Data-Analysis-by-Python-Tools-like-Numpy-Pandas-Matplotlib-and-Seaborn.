## point Plot


import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px


df=px.data.tips()
# sns.barplot(data=df,x='day',y='total_bill',ci=None)
sns.pointplot(data=df,x='day',y='total_bill',ci=None)
plt.show()
# print(df)
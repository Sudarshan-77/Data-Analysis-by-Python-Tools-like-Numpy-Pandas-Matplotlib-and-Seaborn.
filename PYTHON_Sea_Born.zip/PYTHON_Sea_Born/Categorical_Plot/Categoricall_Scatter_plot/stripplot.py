import matplotlib.pyplot as plt
import plotly.express as px
import seaborn as sns

df=px.data.tips()
print(df)

 #Plotting strip plot 
"""A strip plot is a categorical scatter plot used to show individual numerical data points across different categories."""
# sns.swarmplot(data=df,x='total_bill',y='tip',jitter=0.2)

"""dodge Function helps to separate the each category. Supppose for sex, it separates Male and Female"""

"""jitter Function helps to distribute or scatter the data more separately"""

sns.catplot(data=df,x='total_bill',y='tip',hue='sex',col='day')
plt.show()
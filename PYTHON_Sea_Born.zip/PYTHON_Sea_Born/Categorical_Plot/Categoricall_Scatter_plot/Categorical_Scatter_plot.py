# Categorical Scatter Plot

"""A categorical scatter plot is used to show the relationship between a categorical variable and a numerical variable. It displays individual observations as points for each category """

# ==========================================
# CATEGORICAL SCATTER PLOT
# ==========================================

# Categorical scatter plots show individual
# numerical observations across categories.

# Main types:
# 1. Strip Plot
# 2. Swarm Plot


# ==========================================
# 1. STRIP PLOT
# ==========================================

# stripplot() displays individual observations
# for each category.
import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px
df = px.data.iris()
print(df)
sns.swarmplot(
    data=df,
    x="species",
    y="sepal_length"
)

plt.show()


# ==========================================
# STRIP PLOT WITH JITTER
# ==========================================

# jitter=True spreads overlapping points
# so individual observations are easier to see.

# sns.stripplot(
#     data=df,
#     x="species",
#     y="sepal_length",
#     jitter=True
# )

# plt.show()


# ==========================================
# 2. SWARM PLOT
# ==========================================

# swarmplot() displays individual observations
# and automatically arranges points to reduce overlap.

# sns.swarmplot(
#     data=df,
#     x="species",
#     y="sepal_length"
# )

# plt.show()


# ==========================================
# USING HUE
# ==========================================

# hue adds another categorical variable
# to the plot.

# sns.stripplot(
#     data=df,
#     x="species",
#     y="sepal_length",
#     hue="species"
# )

# plt.show()


# ==========================================
# HORIZONTAL CATEGORICAL SCATTER PLOT
# # ==========================================

# sns.stripplot(
#     data=df,
#     x="sepal_length",
#     y="species"
# )

# plt.show()


# ==========================================
# BOX PLOT + STRIP PLOT
# ==========================================

# Box plot shows statistical distribution.
# Strip plot shows individual observations.

# sns.boxplot(
#     data=df,
#     x="species",
#     y="sepal_length"
# )

# sns.stripplot(
#     data=df,
#     x="species",
#     y="sepal_length"
# )

# plt.show()


# ==========================================
# VIOLIN PLOT + SWARM PLOT
# ==========================================

# Violin plot shows distribution.
# Swarm plot shows individual observations.

# sns.violinplot(
#     data=df,
#     x="species",
#     y="sepal_length"
# )

# sns.swarmplot(
#     data=df,
#     x="species",
#     y="sepal_length"
# )

# plt.show()


# ==========================================
# IMPORTANT PARAMETERS
# ==========================================

# data    -> DataFrame
# x       -> X-axis variable
# y       -> Y-axis variable
# hue     -> Additional categorical variable
# jitter  -> Spreads overlapping points
# size    -> Controls point size
# alpha   -> Controls transparency


# ==========================================
# STRIP PLOT VS SWARM PLOT
# ==========================================

# Strip Plot:
# sns.stripplot()
# Shows individual points.
# jitter can be used to reduce overlap.

# Swarm Plot:
# sns.swarmplot()
# Automatically positions points to reduce overlap.


# ==========================================
# BASIC EXAMPLE
# ==========================================

# import seaborn as sns
# import matplotlib.pyplot as plt
# import plotly.express as px



# sns.stripplot(
#     data=df,
#     x="species",
#     y="sepal_length",
#     jitter=True
# )

plt.show()


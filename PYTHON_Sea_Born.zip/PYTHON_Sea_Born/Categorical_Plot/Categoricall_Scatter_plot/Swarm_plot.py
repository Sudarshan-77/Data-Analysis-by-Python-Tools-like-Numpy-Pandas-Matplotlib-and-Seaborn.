##Swarm Plot 

"""A swarm plot is a categorical distribution plot in Seaborn. It is used to display individual observations/data points for different categories.

Unlike a bar plot, which usually shows an average, a swarm plot shows each individual data point.

It is particularly useful when you want to see:

Individual observations
Distribution of data
Where data points are concentrated
Differences between categories
Possible outliers """

import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px


df=px.data.tips()
print(df)


sns.swarmplot(data=df,x='total_bill',y='tip')
plt.show()
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px


# Voilin Plot
# Voilin is the mixture of the KDE Plot and Box plot.
"""A violin plot is a categorical distribution plot in seaborn that shows the distribution and density of numeerical data acropss different categories"""


df=px.data.tips()

sns.violinplot(data=df,x='day',y='total_bill',hue='sex')
plt.show()
# print(df)
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px


#Introduction about Box plot

"""A box plot is a categorical distribution plot in Seaborn that is used to show the distribution of numerical data across one or more categories.

It helps you understand:

The median of the data
The spread/variation of the data
The quartiles
The minimum and maximum values
Outliers
Differences between categories

For example, if you want to compare restaurant bills across different days, a box plot is very useful."""

df=px.data.tips()
print(df)
# sns.boxplot(data=df,x='sex',y='total_bill',hue='smoker')



## Single Box Plot
""" We can plot single box plot by passing the parameter y while x must not be call here """

sns.boxplot(data=df,hue='sex',y='total_bill',x='day')
plt.show()
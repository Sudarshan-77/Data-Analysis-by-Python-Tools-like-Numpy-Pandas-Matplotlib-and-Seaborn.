# lm_plot
"""lm plot is simplly the regression plot but it is the figure level function so ##hue paramater is the a=main adavantage of it"""
"""It is much more advance than the reg_plot"""

import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px 

df=px.data.tips()
# print(df)

sns.lmplot(data=df,x='total_bill',y='tip',hue='sex')
plt.grid()
plt.show()
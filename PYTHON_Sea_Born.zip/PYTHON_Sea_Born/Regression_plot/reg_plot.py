# Reg plot is simply known as regression plot which allows to show relationship between two variables using a regressin line
# It is an axes level function

import matplotlib.pyplot as plt
import plotly.express as px
import seaborn as sns


df=px.data.tips()
# print(df)

sns.regplot(data=df,x='total_bill',y='tip')
plt.grid()
plt.show()
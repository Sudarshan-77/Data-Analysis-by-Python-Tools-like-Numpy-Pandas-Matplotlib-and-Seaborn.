import seaborn as sns
import plotly.express as px
Resturant=px.data.tips()
Flower=px.data.iris()
print(Resturant)
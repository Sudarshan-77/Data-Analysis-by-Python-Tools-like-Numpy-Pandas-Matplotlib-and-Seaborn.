# import seaborn as sns
# import matplotlib.pyplot as plt
# import plotly.express as px

# df=px.data.tips()
# df=df.head(10)



# sns.relplot(data=df,x='total_bill',y='tip',hue='sex',kind='line')
# print(plt.show())

# ============================================================
# PLOTLY ELECTION DATASET - PRACTICE QUESTIONS
# ============================================================
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px

# Load the dataset
df = px.data.election()


# ============================================================
# PART 1: BASIC DATA ANALYSIS
# ============================================================

# Q1. Print the complete dataset.

print(df)


# Q2. Display the first 5 rows of the dataset.
print(df.head(5))


# Q3. Display the last 5 rows of the dataset.

print(df.tail(5))


# Q4. Find the number of rows and columns in the dataset.
print(df.shape)

# Q5. Display all column names.

print(df.head(0))


# Q6. Display the data types of all columns.

print(df.info())


# Q7. Check whether the dataset contains missing values.

print(df.isnull().sum())


# Q8. Display basic statistical information about the dataset.
print(df.describe())


# ============================================================
# PART 2: PANDAS PRACTICE
# ============================================================

# Q9. Find the unique values in the 'district' column.
# df=pd.DataFrame(df)
unique=df.drop_duplicates("district")
print(unique)


# Q10. Count how many candidates are present in each district.
# print(unique.sum("Bergeron"))


# Q11. Sort the dataset by the 'total' column from highest to lowest
import numpy as np
a=np.sum(unique["total"])
top_5=unique.sort_values(["total"])

# Q12. Display the top 5 candidates based on total votes.

print(top_5.head(5))


# Q13. Display the candidate who received the highest total votes.
highest = unique.loc[unique["total"].idxmax(),"winner"]
print(f"the person with the highest vote is {highest}")


# Q14. Display the candidate who received the lowest total votes.
lowest= unique.loc[unique["total"].idxmin(),"winner"]
print(f"the person with the lowest vote is {lowest}")
# print(lowest)


# Q15. Find the average number of votes received by candidates.
print(f"the avergae vote of Coderre is {np.average(unique['Coderre'])}")
print(np.average(unique['Bergeron']))




# Q16. Find the maximum value in the 'percent' column.


# Q17. Find the minimum value in the 'percent' column.


# Q18. Display candidates whose vote percentage is greater than 10%.


# ============================================================
# PART 3: FILTERING
# ============================================================

# Q19. Create a new DataFrame containing only candidates
#      from one district.


# Q20. Create a new DataFrame containing candidates
#      who received more than 100,000 votes.


# Q21. Create a new DataFrame containing candidates
#      whose vote percentage is greater than 20%.


# Q22. Display the top 10 candidates according to total votes.


# ============================================================
# PART 4: SEABORN SCATTER PLOT
# ============================================================

# Q23. Create a scatter plot with:
#      x = total
#      y = percent


# Q24. Create the same scatter plot and use 'district'
#      as the hue.


# Q25. Add a suitable title to the scatter plot.


# ============================================================
# PART 5: SEABORN BAR PLOT
# ============================================================

# Q26. Create a bar plot showing candidates and their
#      total votes.


# Q27. Create a horizontal bar plot showing the top 10
#      candidates according to total votes.


# Q28. Use 'district' as the hue in a bar plot.


# ============================================================
# PART 6: SEABORN RELPLOT
# ============================================================

# Q29. Create a relational scatter plot using:
#      x = total
#      y = percent


# Q30. Create a relational plot using:
#      x = total
#      y = percent
#      hue = district


# Q31. Create a relational plot using:
#      x = total
#      y = percent
#      hue = district
#      kind = scatter


# ============================================================
# PART 7: MATPLOTLIB PRACTICE
# ============================================================

# Q32. Create a figure with size (12, 6).


# Q33. Add a title to your chart.


# Q34. Add labels to the x-axis and y-axis.


# Q35. Add a grid to your chart.


# Q36. Rotate the x-axis labels by 45 degrees.


# ============================================================
# PART 8: CHALLENGE QUESTIONS
# ============================================================

# Q37. Find the top 5 candidates by total votes and
#      visualize them using a Seaborn bar plot.


# Q38. Create a scatter plot showing the relationship
#      between total votes and vote percentage.


# Q39. Use 'district' as the hue and determine whether
#      different districts have different vote patterns.


# Q40. Create a complete visualization using:
#
#      sns.relplot()
#      x = total
#      y = percent
#      hue = district
#      kind = scatter
#
#      Add an appropriate title and grid.


# ============================================================
# BONUS CHALLENGE
# ============================================================

# Q41. Create a visualization that compares candidates'
#      total votes and percentage of votes.
#
#      Requirements:
#      - Use Seaborn
#      - Use hue
#      - Use a suitable figure size
#      - Add title
#      - Add x-axis label
#      - Add y-axis label
#      - Add grid
#      - Display the chart
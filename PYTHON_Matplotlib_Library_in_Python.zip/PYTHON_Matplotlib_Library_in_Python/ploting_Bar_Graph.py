# PLotting Bar chart Vertically. In this way, we can plot the bar chart vertically as shown below:-

# plt.bar(x,height,color="pink",width=0.5,label="Populatio of Metropolitans")
# plt.title("Total Sales of the city of the nepal")
# plt.xlabel("Cities")
# plt.ylabel("Population")
# print(plt.show())



# Plotiing Bar Chart Horizontally. We don't need to do anything wee can simply place barh() to dipslay the bar chart horizontally
# plt.barh(x,height,color="pink")

# ============================================================
# EXTREME CHALLENGE — enumerate() + plt.text()
# ============================================================

import matplotlib.pyplot as plt

products = [
    "Laptop", "Phone", "Tablet", "Monitor",
    "Printer", "Camera", "Server", "Router"
]

sales = [
    85000, 145000, 65000, 95000,
    32000, 110000, 175000, 55000
]

# TASK:
#
# Create a vertical bar chart using the data above.
#
# 1. Use plt.bar() to create the bar chart.
#
# 2. Use enumerate(sales) to get BOTH:
#       - the index of each bar
#       - the sales value of each bar

for i,value in enumerate(sales):
    plt.text(i,value,str(value),ha='left',va='bottom')
plt.bar(products,sales)
#
# 3. Inside the enumerate loop, use plt.text() to display
#    the exact sales value above EVERY bar.
#
# 4. The sales value must be:
#       - horizontally centered
#       - positioned just above the bar
#
# 5. If the sales value is greater than 100000,
#    display the word "HIGH" above the sales value.
#
# 6. If the sales value is less than 50000,
#    display the word "LOW" above the sales value.
#
# 7. For sales between 50000 and 100000, display ONLY
#    the sales value.
#
# 8. You MUST use i and value from enumerate().
#
# 9. You MUST use plt.text() inside the loop.
#
# 10. Do NOT manually write any sales values.
#
# 11. Do NOT manually specify the position of any bar.
#
# 12. Add a suitable title and axis labels.
#
# ============================================================
#
# Expected concept:
#
# for i, value in enumerate(sales):
#     plt.text(...)
#
# But YOU must complete the code.
# ============================================================







print(plt.show())



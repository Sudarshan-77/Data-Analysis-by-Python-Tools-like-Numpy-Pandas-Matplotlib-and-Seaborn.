# ============================================================
# HARDCORE MATPLOTLIB SUBPLOT CHALLENGE
# ============================================================

import matplotlib.pyplot as plt

# Dataset
months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun"]
sales = [45000, 52000, 48000, 75000, 68000, 85000]
expenses = [30000, 32000, 35000, 42000, 40000, 48000]
customers = [450, 520, 480, 700, 650, 820]

products = ["Laptop", "Mobile", "Tablet", "Monitor"]
product_sales = [350000, 280000, 150000, 120000]


# ============================================================
# TASK
# ============================================================

# Create a single figure containing 4 different plots
# arranged in a 2 × 2 layout using ONLY plt.subplot().

plt.subplot(1,4,1)
# ------------------------------------------------------------
# SUBPLOT 1 — SALES VS EXPENSES
# ------------------------------------------------------------
#
# Create a line chart.
#
# X-axis  → Months
# Y-axis  → Amount in NPR

plt.plot(months,sales,label='Amount of Sales',color='purple')
plt.plot(months,expenses,label='Amount of expenses',color='pink')
plt.title("Monthly Sales vs Expenses")
plt.xlabel("Months")
plt.ylabel("Amount in NPR")
plt.grid()
plt.legend()
# plt.show()
# Plot BOTH:
#   1. Sales
#   2. Expenses
#
# Requirements:
# - Different markers for Sales and Expenses
# - Add legend
# - Add grid
# - Add suitable title
# - Label both axes

# plt.title("Total expenses Per Month")
# plt.xlabel("Months")
# plt.ylabel("Expenses")
# plt.grid()
# plt.legend()
# plt.show()
# #

# ---------------------------------------------------------------------------
# SUBPLOT 2 — MONTHLY PROFIT
# ---------------------------------------------------------------------------
import numpy as np

plt.subplot(1,4,2)
# Calculate:
sales=np.array(sales)
# print(sales)
expenses=np.array(expenses)
profit=sales-expenses
print(profit)
plt.bar(months,profit,edgecolor='black')
plt.grid(axis='y')
plt.xlabel("Months")
plt.ylabel("Profits")
plt.show()
# Create a bar chart showing monthly profit.
#
# Requirements:
# - Display profit values above every bar
# - Add black border around each bar
# - Add suitable title
# - Label axes
# - Add grid only on the Y-axis
#
#
# ------------------------------------------------------------
# SUBPLOT 3 — CUSTOMERS VS SALES
# ------------------------------------------------------------


plt.subplot(1,4,3)
plt.scatter(customers,sales,markersize=100,edgecolor='red')
# Create a scatter plot.
#
# X-axis → Number of Customers
# Y-axis → Sales
#
# Requirements:
# - Use customers as X values
# - Use sales as Y values
# - Marker size = 100
# - Add edge/border to markers
# - Add suitable title
# - Label both axes
# - Add grid
#
#
# ------------------------------------------------------------
# SUBPLOT 4 — PRODUCT SALES DISTRIBUTION
# ------------------------------------------------------------
#
# Create a pie chart using:
#
# products
# product_sales
#
# Requirements:
# - Display percentage values
# - Display product names
# - Separate the product with the HIGHEST sales
#   from the pie using explode
# - Add a suitable title
# - Display the legend
#
#
# ============================================================
# FINAL REQUIREMENTS
# ============================================================
#
# 1. Use plt.subplot(2, 2, position) for ALL four plots.
#
# 2. Do NOT create four separate figures.
#
# 3. Use only ONE plt.show() at the end.
#
# 4. Use plt.tight_layout() before plt.show().
#
# 5. The final output must look like a professional
#    2 × 2 data-analysis dashboard.
#
# ============================================================
import matplotlib.pyplot as plt

# ============================================================
# HARD MATPLOTLIB CHALLENGE
# ============================================================

# A company recorded the weekly sales of three products.

days=["Monday", "Tuesday", "Wednesday", "Thursday",
        "Friday", "Saturday", "Sunday"]

product_A=[45000, 52000, 48000, 70000, 85000, 92000, 78000]
product_B=[30000, 42000, 55000, 50000, 68000, 75000, 90000]
product_C=[60000, 58000, 62000, 65000, 70000, 68000, 72000]


# ============================================================
# TASK 1
# ============================================================
# Create ONE line graph containing all three products.
#
# Product A:
#   color = red
#   marker = circle
#   linestyle = solid
#
plt.plot(days,product_A,color='red',marker='o',linestyle='-',label='Product_A')


# Product B:
#   color = blue
#   marker = square
#   linestyle = dashed
#

plt.plot(days,product_B,color='blue',marker='s',linestyle='-',label='Product_B')

# Product C:
#   color = green
#   marker = triangle
#   linestyle = dotted



plt.plot(days,product_C,color='green',marker='^',linestyle='-',label="Product_C",linewidth=2)
#
# Each line must have an appropriate label.


# ============================================================
# TASK 2
# ============================================================
# Add the following:
#
# Title:
# "Weekly Sales Performance"
plt.title("Weekly Sales Performance")

# X-axis:
# "Days of the Week"
plt.xlabel("Days of the Week")

#
# Y-axis:
# "Sales (NPR)"
plt.ylabel("Sales (NPR)")


# ============================================================
# TASK 3
# ============================================================
# Change the X-axis labels:
#
# Monday    -> Mon
# Tuesday   -> Tue
# Wednesday -> Wed
# Thursday  -> Thu
# Friday    -> Fri
# Saturday  -> Sat
# Sunday    -> Sun
plt.xticks(["Monday", "Tuesday", "Wednesday", "Thursday",
        "Friday", "Saturday", "Sunday"],["Mon","Tue","Wed","Thu","Fri","Sat","Sun"])


# ============================================================
# TASK 4
# ============================================================
# Change the Y-axis labels.
plt.yticks([45000, 52000, 48000, 70000, 85000, 92000, 78000],["45K","52K","48K","70K","85K","92k","78k"])

# The actual values should remain unchanged.
#
# Display:
#
# 20000 -> 20K
# 40000 -> 40K
# 60000 -> 60K
# 80000 -> 80K
# 100000 -> 100K
#
# Hint:
# Use yticks().


# ============================================================
# TASK 5
# ============================================================
# Set the Y-axis limit:

# Minimum = 20000
# Maximum = 100000
#
# Use ylim().

plt.ylim(20000,100000)

# ============================================================
# TASK 6
# ============================================================
# Add grid lines.
#
# The grid should:
# - use dotted lines
# - have linewidth = 0.8
#
# Do not make the grid too strong.

plt.grid(linestyle=":",linewidth=0.8)


# ============================================================
# TASK 7
# ============================================================
# Add a legend.
#
# Position the legend in the upper left corner.
#
# Make the legend font size = 10.

plt.legend(fontsize=10)


# ============================================================
# TASK 8
# ============================================================
# Make the graph easy to read.
#
# Each line should have:
# linewidth = 2
#
# Each marker should have an appropriate size.



# ============================================================
# TASK 9 — ANALYSIS
# ============================================================
# Without calculating manually, look at your graph and answer:
#
# 1. Which product had the highest sales on Saturday?
"""Product A has the highest sales on Saturday"""

# 2. Which product had the lowest sales on Tuesday?
"""Product B has the lowest sales on Tuesday"""

# 3. Which product showed the strongest overall growth?
"""Product B has the strongest overall growth"""

# 4. On which day did Product A and Product B have
#    approximately the same sales?
"""Product A and Product B had approximately the same sales on friday"""

# 5. Which product was the most stable throughout the week?
"""Product C was the most stable throughout the week"""


# ============================================================
# TASK 10 — ADVANCED
# ============================================================
# Modify the graph so that ONLY the following days appear
# on the X-axis:
#
# Mon, Wed, Fri, Sun
#
# Do NOT remove any data.
plt.xticks(["Monday","Wednesday","Friday","Sunday"],["Mon","Wed","Fri","Sun"])
#
# You must only modify the displayed X-axis ticks.


# ============================================================
# TASK 11 — VERY HARD
# ============================================================
# Suppose the company wants the Y-axis to display sales
# in thousands instead of actual NPR values.
#
# For example:
#
# 20000 -> 20
# 40000 -> 40
# 60000 -> 60
# 80000 -> 80
# 100000 -> 100

# plt.yticks(

#     [20000, 40000, 60000, 80000, 100000],

#     [20, 40, 60, 80, 100]

# )
# IMPORTANT:
# Do NOT modify product_A, product_B, or product_C.
#
# Modify ONLY the Y-axis display.


# ============================================================
# TASK 12 — EXTREME
# ============================================================
# Create a second version of the graph where:
#
# - Product A is visible
# - Product B is visible
# - Product C is visible
# - The X-axis contains only:
#       Mon, Tue, Wed, Thu, Fri, Sat, Sun
# - Y-axis ranges from 0 to 100000
plt.ylim(0,100000)
# - Grid is visible only for the Y-axis

plt.grid(axis="y",linewidth=2)
plt.legend(loc="lower right")
# - Legend is at lower right
# - All lines have linewidth = 2
# - Title is:
#       "Company Product Sales Comparison"
plt.title("Company Product Sales Comparison")
#
# Hint:
# Carefully think about the parameters of grid().
#


# ============================================================
# FINAL TASK — MASTER LEVEL
# ============================================================
# Create the final graph satisfying ALL requirements below:
#
# 1. Three lines must be plotted.
#
# 2. Each line must have:
#       - different color
#       - different marker
#       - different linestyle
#
# 3. Add title:
#       "Weekly Product Sales Analysis"
plt.title("Weekly Product Sales Analysis")
#
# 4. X-axis label:
#       "Day"
plt.xlabel("Day")
#
# 5. Y-axis label:
#       "Sales in NPR"

plt.ylabel("Sales in NPR")
#
# 6. X-axis should display:
#       Mon Tue Wed Thu Fri Sat Sun
plt.xticks(["Monday", "Tuesday", "Wednesday", "Thursday",
        "Friday", "Saturday", "Sunday"],["Mon","Tue","Wed","Thu","Fri","Sat","Sun"])
#
# 7. Y-axis should range:
#       20000 to 100000
#
# 8. Y-axis should display:
#       20K, 40K, 60K, 80K, 100K
#
# 9. Add a grid only to the Y-axis.
#
# 10. Grid must be dotted.
#
# 11. Add a legend at upper left.
#
# 12. Legend font size = 10.
#
# 13. All lines must have linewidth = 2.
#
# 14. Markers must be clearly visible.
#
# 15. Display the graph using show().
#
# 16. DO NOT change the original data.
#
# 17. DO NOT use Pandas.
#
# 18. DO NOT use Seaborn.
#
# 19. DO NOT use Plotly.
#
# 20. Use only Matplotlib.
plt.show()


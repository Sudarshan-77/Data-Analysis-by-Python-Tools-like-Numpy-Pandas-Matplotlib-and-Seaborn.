import matplotlib.pyplot as plt


# ============================================================
# HARD TASK — MATPLOTLIB SUBPLOTS USING fig, ax
# ============================================================

import matplotlib.pyplot as plt

months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun"]

sales = [45000, 52000, 48000, 65000, 72000, 80000]

expenses = [30000, 34000, 32000, 40000, 45000, 50000]

profit = [15000, 18000, 16000, 25000, 27000, 30000]

customers = [120, 150, 140, 180, 210, 250]


# REQUIREMENTS:
#
# 1. Create a figure containing 4 subplots using:
#
fig, ax = plt.subplots(2,2,figsize=(10,5))
#
# 2. Arrange the subplots in a 2 × 2 layout.
#
# 3. SUBPLOT 1:
#       Create a line chart of Sales and Expenses.
#       X-axis → Months
#       Y-axis → Amount in NPR
#       Include a legend.
ax[0,0].plot(months,sales,label="Sales Amount in NPR")
ax[0,0].plot(months,expenses,label="Expenses Amount in NPR")
ax[0,0].set_title("Monthly Sales vs Monthly Expenses")
ax[0,0].set_xlabel("Months")
ax[0,0].set_ylabel("Amount in NPR")
ax[0,0].legend()

# 4. SUBPLOT 2:
#       Create a bar chart of Profit.
#       X-axis → Months
#       Y-axis → Profit

ax[0,1].plot(months,profit,label="Sales Amount per Month")
ax[0,1].set_title("Monthly Profit")
ax[0,1].set_xlabel("Total Months")
ax[0,1].set_ylabel("Total Profits")
ax[0,1].legend()

# 5. SUBPLOT 3:
#       Create a scatter plot of Customers.
#       X-axis → Months
#       Y-axis → Number of Customers
ax[1,0].scatter(months,customers,label="cusomers per month")
ax[1,0].set_title("Total Customers visited our store per months")
ax[1,0].set_xlabel("Months")
ax[1,0].set_ylabel("Numbers of Customers")
plt.show()

# 6. SUBPLOT 4:
#       Create a line chart of Profit.
#       Add markers to the line.
ax[1,1].plot()

# 7. Give every subplot its own title.
#
# 8. Give the entire figure a main title using:
#
#       fig.suptitle()
#
# 9. Use ONLY the axes object for plotting:
#
#       ax[0,0].plot(...)
#       ax[0,1].bar(...)
#       ax[1,0].scatter(...)
#       ax[1,1].plot(...)
#
# 10. DO NOT use:
#
#       plt.subplot()
#       plt.plot()
#       plt.bar()
#       plt.scatter()
#
#     for creating the individual graphs.
#
# 11. Make sure the subplot titles and the main figure title
#     do not overlap.
#
# 12. Display the final figure.
#
# ============================================================
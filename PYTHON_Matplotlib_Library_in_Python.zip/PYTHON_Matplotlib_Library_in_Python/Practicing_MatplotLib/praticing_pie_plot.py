import matplotlib.pyplot as plt

# ============================================================
# PIE CHART — HARD CHALLENGE
# ============================================================

# A company recorded its annual expenses in different departments.

departments=[
    "Marketing",
    "Human Resources",
    "Technology",
    "Operations",
    "Research",
    "Administration"]

expenses=[
    180000,
    120000,
    300000,
    250000,
    100000,
    50000]


Highest= max(expenses)
explode=[0]*len(expenses)
explode[expenses.index(Highest)]=0.1

# ============================================================
# TASK 1 — BASIC PIE CHART
# ============================================================
# Create a pie chart using:
#
# departments → labels
# expenses    → values
#
# Use plt.pie().

# Highest=max(expenses)
# explode=[0]*len(expenses)
# explode[expenses.index(Highest)]=0.1

# plt.pie(expenses,labels=departments,autopct="%1.1f%%",startangle=90,explode=explode)

# ============================================================
# TASK 2 — TITLE
# ============================================================
# Add the title:
#
# "Annual Departmental Expenses"

plt.title("Annual Departmental Expenses")


# ============================================================
# TASK 3 — PERCENTAGES
# ============================================================
# Display the percentage of total expenses
# inside each slice.
# Hint:
# Use autopct.




# ============================================================
# TASK 4 — STARTING ANGLE
# ============================================================
# Rotate the pie chart so that the first slice starts
# at 90 degrees.
#
# Hint:
# Use startangle.




# ============================================================
# TASK 5 — EXPLODE
# ============================================================
# Highlight the department with the HIGHEST expense
# by separating its slice from the pie.
#
# Hint:
# Use explode.




# ============================================================
# TASK 6 — SHADOW
# ============================================================
# Add a shadow effect to the pie chart.
plt.pie(expenses,labels=departments,autopct="%1.1f%%",startangle=90,explode=explode,shadow=True)

# ============================================================
# TASK 7 — EQUAL ASPECT RATIO
# ============================================================
# Make sure the pie chart appears as a perfect circle,
# not an oval.


plt.axis("equal")
# Hint:
# Use axis("equal").


# ============================================================
# TASK 8 — LEGEND
# ============================================================
# Add a legend showing the department names.
#
# Position the legend on the right side.


# ============================================================
# TASK 9 — ANALYSIS
# ============================================================
# Look at your pie chart and answer:
#
# 1. Which department has the highest expense?
"""Technology department has the highest expense"""

# 2. Which department has the lowest expense?
"""Adminstration Department has the lowest expense"""

# 3. Which department consumes approximately 30% of
#    the total expenses?
"""Technology Department comsumes approximately 30% of the total expenses"""
#
# 4. What percentage of total expenses is spent on
#    Technology and Operations combined?
"""55% of total expenses is spent on Technology and Operations Combined"""

# 5. Which two departments have the smallest expenses?
"""Research and Adminstrations are two departments have the smallest expenses"""


# ============================================================
# TASK 10 — MASTER LEVEL
# ============================================================

# Create the FINAL pie chart satisfying ALL requirements:
# 1. Display all six departments.

# 2. Display percentage values inside each slice.
#
# 3. Percentage should show ONE decimal place.
#
# 4. Starting angle = 90 degrees.
#
# 5. Explode ONLY the largest expense slice.
#
# 6. Add a shadow.
#
# 7. Make the pie a perfect circle.
#
# 8. Add the title:
#    "Company Expense Distribution"
#
# 9. Add a legend on the right side.
#
# 10. Do NOT modify the original data.
#
# 11. Do NOT use Pandas.
#
# 12. Do NOT use Seaborn.
#
# 13. Do NOT use Plotly.
#
# 14. Use ONLY Matplotlib.
#
# 15. Display the graph using show().
#
# ============================================================

plt.show()
import matplotlib.pyplot as plt

# ============================================================
# HISTOGRAM — MASTER LEVEL CHALLENGE
# ============================================================

# A company recorded the monthly salaries of 100 employees.
# Salary values are in NPR.

salaries = [
    18000, 22000, 25000, 27000, 30000, 32000, 35000, 36000, 38000, 40000,
    42000, 43000, 45000, 47000, 48000, 50000, 52000, 53000, 55000, 56000,
    58000, 60000, 62000, 63000, 65000, 67000, 68000, 70000, 72000, 73000,
    75000, 76000, 78000, 80000, 82000, 83000, 85000, 87000, 88000, 90000,
    92000, 94000, 95000, 97000, 98000, 100000, 102000, 105000, 108000, 110000,
    20000, 24000, 28000, 31000, 34000, 37000, 39000, 41000, 44000, 46000,
    49000, 51000, 54000, 57000, 59000, 61000, 64000, 66000, 69000, 71000,
    74000, 77000, 79000, 81000, 84000, 86000, 89000, 91000, 93000, 96000,
    99000, 101000, 103000, 106000, 109000, 112000, 115000, 118000, 120000,
    23000, 33000, 43000, 53000, 63000, 73000, 83000, 93000, 103000, 123000
]


# ============================================================
# TASK 1 — BASIC HISTOGRAM
# ============================================================
# Create a histogram of the salary distribution.


plt.hist(salaries,bins=10,edgecolor='black',color='purple')
# Requirements:
# - bins = 10
# - edgecolor = black
# - color = purple
#
# Use hist().


# ============================================================
# TASK 2 — LABELS
# ============================================================
# Add the following:
#
# Title:
# "Employee Salary Distribution"

plt.title("Employee Salary Distribution")
# X-axis:
# "Salary (NPR)"
#
plt.xlabel("Salary (NPR)")
# Y-axis:
# "Number of Employees"
plt.ylabel("Number of Employees")

# ============================================================
# TASK 3 — AXIS LIMIT
# ============================================================
# Set the X-axis range:
#
# Minimum = 10000
# Maximum = 130000

#
# Use xlim().
plt.xlim(10000,130000)
#
# DO NOT modify the salaries list.


# ============================================================
# TASK 4 — CUSTOM X-AXIS
# ============================================================
# The X-axis must display:


#
# 20K, 40K, 60K, 80K, 100K, 120K
#

# plt.xticks(['20k','40k','60k','80k','100k','120k'])

# The actual salary values must remain unchanged.
#
# Hint:
# Use xticks().




# ============================================================
# TASK 5 — Y-AXIS
# ============================================================
# Set the Y-axis ticks so that they increase by 5.
#
# Example:
# 0, 5, 10, 15, 20, 25...

plt.yticks([0,5,10,15,20,25,30,35,40,45,50,55,60,65,70,75,80,85,90,95,100])
#
# Do not change the histogram data.


# ============================================================
# TASK 6 — GRID
# ============================================================
# Add grid lines ONLY along the Y-axis.
#
# Requirements:
# - dotted lines
# - linewidth = 0.8
#
# Hint:
# Carefully use the axis parameter of grid().
plt.grid(linewidth=0.8,linestyle=':',axis="both")




# ============================================================
# TASK 7 — HISTOGRAM STYLE
# ============================================================
# Modify the histogram so that:
#
# - transparency (alpha) = 0.7
# - edgecolor = black
#
# Keep the histogram readable.
plt.hist(salaries,edgecolor='black',alpha=0.7)




# ============================================================
# TASK 8 — ANALYSIS
# ============================================================
# Look at your histogram and answer:
#
# 1. Which salary range contains the largest number
#    of employees?
# 40000-50000, 60000-70000, 80000-90000

# 2. Is the distribution approximately symmetric,
#    left-skewed, or right-skewed?
#- It is left-skewed

# 3. Are there any possible high-salary outliers?
#
# 4. Approximately how many employees earn more than
#    NPR 100,000?
#- About 13 Employee approximately earn more than NPR 100,000


# 5. Which salary region appears most concentrated?
# 40000 to 100000 Salary region appears most concentrated.


# ============================================================
# TASK 9 — HARD
# ============================================================
# Create a second histogram using:
# bins = 5
# Keep the same:
# - data
# - title
# - axis labels
#
# Compare this histogram with the first one.
plt.hist(salaries,bins=5,edgecolor='black',color='purple')
# DO NOT delete the first histogram.


# ============================================================
# TASK 10 — VERY HARD
# ============================================================
# Create the histogram using EXACTLY these bin boundaries:

# 10000
# 30000
# 50000
# 70000
# 90000
# 110000
# 130000

# Hint:
# bins can also accept a list of boundaries.

# Do NOT manually count the employees.


# ============================================================
# TASK 11 — EXTREME
# ============================================================
# Suppose the company wants salary displayed in THOUSANDS.
#
# Therefore:
#
# 20000  -> 20K
# 40000  -> 40K
# 60000  -> 60K
# 80000  -> 80K
# 100000 -> 100K
# 120000 -> 120K
#
# IMPORTANT:
# - Do NOT modify salaries.
# - Do NOT divide the salary values.
# - Modify ONLY the X-axis display.
#
# Hint:
# Use xticks().

plt.xticks([20000,40000,60000,80000,100000,120000],['20k','40k','60k','80k','100k','120k'])


# ============================================================
# TASK 12 — MASTER LEVEL
# ============================================================
# Create the FINAL histogram satisfying ALL requirements:
#
# 1. Use the original salaries list.
#
# 2. bins = 10
#
# 3. Histogram color = purple
#
# 4. Edge color = black
#
# 5. Alpha = 0.7
#
# 6. Title:
#    "Employee Salary Distribution Analysis"
#
# 7. X-axis label:
#    "Salary (NPR Thousands)"
#
# 8. Y-axis label:
#    "Number of Employees"
#
# 9. X-axis range:
#    10000 to 130000
#
# 10. X-axis ticks:
#     20K, 40K, 60K, 80K, 100K, 120K
#
# 11. Grid ONLY on Y-axis.
#
# 12. Grid style = dotted.
#
# 13. Grid linewidth = 0.8.
#
# 14. Do NOT modify the original salaries.
#
# 15. Do NOT use Pandas.
#
# 16. Do NOT use Seaborn.
#
# 17. Do NOT use Plotly.
#
# 18. Use ONLY Matplotlib.
#
# 19. Display the final graph using show().
#
# ============================================================

plt.show()
# # ============================================================
# # BAR CHART — HARD QUESTION
# # ============================================================
import matplotlib.pyplot as plt
# # A company recorded the following quarterly sales (in NPR)
# # for 5 different products.

# products = ["Laptop", "Phone", "Tablet", "Monitor", "Printer"]
# sales = [85000, 120000, 65000, 95000, 45000]

# # TASK:
# # Create a vertical bar chart that:
# #

# # 1. Displays the products on the X-axis.


# # 2. Displays sales on the Y-axis.


# # 3. Gives every bar a visible border.
# plt.grid()

# # 4. Displays the exact sales value above each bar.

# for i,value in enumerate(sales):
#     plt.text(i,value,str(value),ha='center',va='bottom')
# plt.bar(products,sales)

# for i, value in enumerate(sales):
#     plt.text(i, value, str(value), ha="center", va="bottom")


# # 5. Highlights the product with the HIGHEST sales.
# # highest = max(sales)
# # colors = ["skyblue"] * len(sales)
# # colors[sales.index(highest)] = "red"
# # plt.bar(products, sales, color=colors)






# lowest = min(sales)

# colors = ["skyblue"] * len(sales)

# colors[sales.index(lowest)] = "purple"
# plt.bar(products,sales,color=colors)


























# # lot=min(sales) 
# colors=len(sales)*["pink"]
# colors[sales.index(lowest)]='purple'


# colors=len(sales)*["blue"]


# # los=min(sales)
# # colors=len(sales)
# plt.bar(products,sales,color=colors)
# # 6. Adds an appropriate title, X-axis label, and Y-axis label.
# # 7. Rotates the product names by 20 degrees.
# # 8. Displays a grid only along the Y-axis.

# plt.xticks(rotation=90)
# # Use only Matplotlib.
# # ============================================================

# plt.show()




# ============================================================
# BAR CHART PRACTICE — COLORS, MIN(), MAX(), LEN(), INDEX()
# ============================================================


# ============================================================
# QUESTION 1 — LOWEST SALES
# ============================================================

import matplotlib.pyplot as plt

sales = [45000, 78000, 32000, 95000, 56000]
products = ["Laptop", "Phone", "Tablet", "Monitor", "Printer"]





Highest=max(sales)
colors=["green"]*len(sales)
colors[sales.index(Highest)]="purple"
for i, value in enumerate(sales):
    plt.text(i,value,str(value),ha="center",va="bottom")
plt.bar(products,sales,color=colors)


# TASK:
# 1. Find the lowest sales using min().
# lowest=max(sales)
# colors=["purple"]*len(sales)
# colors[sales.index(lowest)]='green'


# 2. Create a colors list using len().
# 3. Make all bars "pink".
# 4. Find the index of the lowest sales using index().
# 5. Change only the lowest-sales bar to "purple".
# 6. Create the bar chart using the colors list.
# 7. Display the chart.



# ============================================================
# QUESTION 2 — HIGHEST SALES
# ============================================================

# sales = [65000, 120000, 85000, 45000, 150000, 90000]
# products = ["A", "B", "C", "D", "E", "F"]

# # TASK:
# Highest=max(sales)
# colors=len(sales)*["skyblue"]
# colors[sales.index(Highest)]="red"
# plt.bar(products,sales,color=colors)
# 1. Find the highest sales using max().
# 2. Create the colors list dynamically using len().
# 3. Make all bars "skyblue".
# 4. Find the index of the highest sales.
# 5. Change only the highest-sales bar to "red".
# 6. Create the bar chart.
# 7. Display the chart.



# ============================================================
# QUESTION 3 — HIGHEST AND LOWEST
# ============================================================

# sales = [85000, 45000, 120000, 65000, 30000, 95000]
# products = ["Laptop", "Phone", "Tablet", "Monitor", "Printer", "Camera"]

# TASK:
# 1. Find the highest sales using max().
# 2. Find the lowest sales using min().
# 3. Create a colors list using len().
# 4. Make all bars "blue".
# 5. Find the index of the highest sales.
# 6. Find the index of the lowest sales.
# 7. Change the highest-sales bar to "red".
# 8. Change the lowest-sales bar to "purple".
# 9. Create the bar chart.
# 10. Display the chart.



# ============================================================
# QUESTION 4 — DYNAMIC COLORS
# ============================================================

# sales = [45000, 78000, 125000, 56000, 99000, 35000, 145000, 67000]

# products = [
#     "Laptop", "Phone", "Tablet", "Monitor",
#     "Printer", "Camera", "Server", "Router"
# ]

# TASK:
# 1. Find the highest sales using max().
# 2. Find the lowest sales using min().
# 3. Create the colors list using len().
# 4. Make every bar "lightblue".
# 5. Find the index of the highest sales.
# 6. Find the index of the lowest sales.
# 7. Change the highest-sales bar to "red".
# 8. Change the lowest-sales bar to "purple".
# 9. Create the bar chart.
#
# IMPORTANT:
# Do NOT manually write the colors.
#
# Example of what NOT to do:
#
# colors = ["lightblue", "lightblue", "lightblue", ...]
#
# Use len() instead.



# ============================================================
# QUESTION 5 — FINAL CHALLENGE
# ============================================================

# sales = [85000, 45000, 125000, 67000, 32000, 98000, 145000, 55000]

# products = [
#     "Laptop", "Phone", "Tablet", "Monitor",
#     "Printer", "Camera", "Server", "Router"
# ]

# TASK:
#
# 1. Find the highest sales using max().
# 2. Find the lowest sales using min().
# 3. Create a colors list dynamically using len().
# 4. Make all bars "pink".
# 5. Find the index of the highest sales.
# 6. Find the index of the lowest sales.
# 7. Change the highest-sales bar to "green".
# 8. Change the lowest-sales bar to "purple".
# 9. Display the product with the highest sales.
# 10. Display the product with the lowest sales.
# 11. Display the exact sales value above EVERY bar.
# 12. Rotate the product names by 20 degrees.
# 13. Add a suitable title.
# 14. Add an X-axis label.
# 15. Add a Y-axis label.
# 16. Add a Y-axis grid.
# 17. Display the final bar chart.
#
# IMPORTANT:
# Do NOT manually assign colors to individual bars.
#
# You MUST use:
# max()
# min()
# len()
# index()
# ============================================================

plt.show()
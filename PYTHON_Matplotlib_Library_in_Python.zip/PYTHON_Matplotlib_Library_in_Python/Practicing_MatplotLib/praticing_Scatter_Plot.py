import matplotlib.pyplot as plt

# ============================================================
# SCATTER PLOT — HARD CHALLENGE
# ============================================================

# Two students recorded their study hours and marks.

aman_hours  = [1, 2, 3, 4, 5, 6, 7]
aman_marks  = [45, 52, 60, 68, 75, 82, 90]

manoj_hours = [1, 2, 3, 4, 5, 6, 7]
manoj_marks = [40, 48, 55, 65, 72, 80, 88]


# ============================================================
# TASK 1
# ============================================================
# Create ONE scatter plot containing both students.
#
# Aman:
#   color = blue
#   marker = circle

plt.scatter([1, 2, 3, 4, 5, 6, 7],[45, 52, 60, 68, 75, 82, 90],color='blue',marker='o',label="Aman")


# Manoj:
#   color = pink
#   marker = square
plt.scatter([1, 2, 3, 4, 5, 6, 7],[40, 48, 55, 65, 72, 80, 88],color='pink',marker='s',label='manoj')

# Give both scatter plots appropriate labels.

# plt.show()
# ============================================================
# TASK 2
# ============================================================
# Add:
#
# Title:
# "Study Hours vs Marks Obtained"
plt.title("Study Hours vs Marks Obtained")
#
# X-axis:
# "Hours Studied"
plt.xlabel("Hours Studied")
#
# Y-axis:
# "Marks Obtained"
plt.ylabel("Marks Obtained")


# ============================================================
# TASK 3
# ============================================================
# Add a legend.

plt.legend(loc='upper left',fontsize=10)
# Position:
# upper left
#
# Font size:
# 10


# ============================================================
# TASK 4
# ============================================================
# Add grid lines.

plt.grid(linewidth=0.8,linestyle=":",axis="y")
# Requirements:
# - dotted
# - linewidth = 0.8
# - grid should appear ONLY on the Y-axis



# ============================================================
# TASK 5 — AXIS CONTROL
# ============================================================
# Set:
#
# X-axis range:
# 0 to 8

plt.xlim(0,8)
plt.ylim(30,100)
#
# Y-axis range:
# 30 to 100


# ============================================================
# TASK 6 — CUSTOM TICKS
# ============================================================
# X-axis should display:


# 1, 2, 3, 4, 5, 6, 7
#
# Y-axis should display:
#
# 40, 50, 60, 70, 80, 90, 100


# ============================================================
# TASK 7 — MARKER CONTROL
# ============================================================
# Make the markers clearly visible.
plt.scatter([1, 2, 3, 4, 5, 6, 7],[45, 52, 60, 68, 75, 82, 90],color='blue',marker='o',label="Aman",s=80)
# Marker size should be 80.
#
# Use the appropriate parameter of scatter().

"""The parameter of the marker size is s"""



# ============================================================
# TASK 8 — TRANSPARENCY
# ============================================================
# Set the transparency of both scatter plots to:
#
# alpha = 0.7


# ============================================================
# TASK 9 — ANALYSIS
# ============================================================
# Look at your scatter plot and answer:
#
# 1. Does the graph show a positive or negative relationship
#    between study hours and marks?
"""The graph shows positive relationship between study hours and marks"""

# 2. Which student generally obtained higher marks?
"""Aman generally obtained higher marks"""
# 3. At how many study hours are the students' marks
#    approximately equal?
"""At 7 and 8 study hours the students marks are almost equal"""

# 4. Does increasing study hours generally increase marks?
"""From the graph, we xan said that the increasing study hours generally increase the marks"""


# 5. Which student shows the stronger overall improvement?
"Aman generally shows the stronger overall improvements"


# ============================================================
# TASK 10 — MASTER LEVEL
# ============================================================
# Create the FINAL scatter plot satisfying ALL requirements:
#
# 1. Both students must be visible.
#
# 2. Different colors.
#
# 3. Different markers.
#
# 4. Marker size = 80.
#
# 5. Alpha = 0.7.
#
# 6. Title:
#    "Student Performance Analysis"
#
# 7. X-axis:
#    "Hours of Study"
#
# 8. Y-axis:
#    "Marks Obtained"
#
# 9. X-axis range:
#    0 to 8
#
# 10. Y-axis range:
#     30 to 100
#
# 11. Grid ONLY on Y-axis.
#
# 12. Grid must be dotted.
#
# 13. Legend at upper left.
#
# 14. Legend font size = 10.
#
# 15. Use ONLY Matplotlib.
#
# 16. Do NOT use Pandas.
#
# 17. Do NOT use Seaborn.
#
# 18. Do NOT use Plotly.
#
# 19. Do NOT change the original data.
#
# 20. Display the graph using show().

plt.show()
# import matplotlib.pyplot as plt
# x=["Dhaulagiri","Macchapucharey","Lhotse","Makalu","Kachanjunga","Kt2","Mount Everst"]
# height=[8000,8200,8500,8200,8800,8100,8050]
# plt.plot(x,height,color="purple",linestyle="-",linewidth=2,label="Mountain Range",marker="o")
# plt.title("Mountain Range of the TOp 7 highest peak in the world")
# plt.xlabel("Mountains")
# plt.ylabel("Heights")
# # plt.ticks()
# plt.xticks(["Dhaulagiri","Macchapucharey","Lhotse","Makalu","Kachanjunga","Kt2","Mount Everst"],["A","B","C","D","E","F","G"])

# print(plt.show())


# import matplotlib.pyplot as plt
# x=["Mount Everst","Mount K2","Makalu","Kanchanjunga"]
# height=[8000,5000,10000,2000]
# plt.bar(x,height,color="pink",width=0.5,label="Mountain Height")
# print(plt.legend(loc="lower right",fontsize=0.1))
# print(plt.show())






# import matplotlib.pyplot as plt
# y=["Kathmanu","Birgunj","Biratnagar","Pokhara"]
# x=[200000,1000000,500000,600000]
# # plt.pie(x,labels=y,autopct='%1.1f%%',colors=["pink","blue","green","purple"])
# # print(plt.show())



# plt.scatter(x,y,color="red",marker="o")
# plt.scatter(["Sunday","Monday","Tuesday","Wednesday"],[400000,90000,10000,400000],color="pink",marker="d")

# print(plt.show())






# import matplotlib.pyplot as plt

# plt.subplot(1,4,1)
# x=["Kathmandu","Biratnagar","Birgunj","Pokhara","Lalitpur"]
# y=[500,300,350,190,250]
# plt.plot(x,y,color="purple",linewidth=2,linestyle=":",marker="d")
# print(plt.show())




## Plotting with Figure
import matplotlib.pyplot as plt
fig,ax=plt.subplots(1,4,figsize=(10,5))
x=["Sudarshan Chaudhary",'Rahul Gupta','Susant Singh Rajput']
y=[10000,50000,60000]

# Line chart
ax[0].plot(x,y)
ax[0].set_title('Line plot')


#Bar chart
ax[1].bar(x,y,color="purple",label="Sales")
ax[1].set_title('Bar chart')


# #Line chart
ax[2].plot(x,y)
ax[2].set_title('Bar chart')


# Pie chart
ax[3].pie(y,labels=x,colors=["purple","pink","red"],autopct='%1.1f%%')
ax[3].set_title('Pie chart')

plt.savefig("line_plot.png",dpi=300,bbox_inches="tight")


print(plt.show())



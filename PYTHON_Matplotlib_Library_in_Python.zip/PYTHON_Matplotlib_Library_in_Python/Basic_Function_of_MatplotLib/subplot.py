import matplotlib.pyplot as plt
# x=["Sudarshan CHaudhary","Rahul Gupta","Saroj Singh Rajput"]
# y=[1000,5000,7000]
# plt.subplot(1,4,1)
# plt.plot(x,y)
# plt.title('Line Chart')

# plt.subplot(1,4,2)
# plt.bar(x,y)
# plt.title('Bar chart')


# plt.subplot(1,4,3)
# s=["Kathmandu","Birgunj","Janakpur"]
# columns=[30000,60000,20000]
# plt.pie(columns,labels=s,colors=["pink","red","blue"],autopct='%1.1f%%')
# plt.title("Pie chart")


# plt.subplot(1,4,4)
# plt.plot(s,columns)
# plt.title("Line chart 2")
# # plt.tight_layout()

# print(plt.show())



# ============================================================
# HARD LEVEL — MULTIPLE SUBPLOTS CHALLENGE
# ============================================================

import matplotlib.pyplot as plt

students = ["Sudarshan", "Rahul", "Saroj", "Prabesh", "Reecha"]
marks = [85, 72, 91, 64, 78]

cities = ["Kathmandu", "Birgunj", "Janakpur", "Pokhara", "Bharatpur"]
population = [30000, 60000, 20000, 45000, 35000]

# TASK:
#
# Create ONE figure containing 4 different charts arranged
# in a 2 × 2 layout.
#
# ------------------------------------------------------------
# SUBPLOT 1 — LINE CHART
# ------------------------------------------------------------
plt.subplot(1,4,1)
# 1. Display the students on the X-axis.
# 2. Display their marks on the Y-axis.
# 3. Create a line chart.
# 4. Add markers to every point.
# 5. Add a suitable title.
plt.plot(students,marks,marker='o')
plt.title("Line plot")
#
#
# ------------------------------------------------------------
# SUBPLOT 2 — BAR CHART
# ------------------------------------------------------------
#
# 6. Use the same students and marks data.
# 7. Create a vertical bar chart.
# 8. Give every bar a visible black border.
# 9. Display the exact marks above every bar using:
#
#       for i, value in enumerate(marks):
#
# 10. Highlight the student with the HIGHEST marks using
#     a different bar color.
# 11. Add a suitable title.
plt.subplot(1,4,2)
plt.bar(students,marks,edgecolor='black')
plt.show()
#
#
# ------------------------------------------------------------
# SUBPLOT 3 — PIE CHART
# ------------------------------------------------------------
#
plt.subplot(1,4,3)
Highest=max(marks)
explode=[0]*len(marks)
explode[marks.index(Highest)]=0.1
plt.pie(marks,labels=students,autopct="%1.1F%%",explode=explode)
plt.title("Pie Chart")
plt.show()
# 12. Use the cities and population data.
# 13. Create a pie chart.
# 14. Display city names as labels.
# 15. Display percentages using autopct.
# 16. Explode the city with the HIGHEST population.
# 17. Add a suitable title.
#
#
# ------------------------------------------------------------
# SUBPLOT 4 — LINE CHART
# ------------------------------------------------------------
#
# 18. Use cities and population data.
# 19. Create another line chart.
# 20. Add markers to every point.
# 21. Add a suitable title.
#
#
# ------------------------------------------------------------
# FINAL REQUIREMENTS
# ------------------------------------------------------------
#
# 22. Arrange all 4 charts using:
#
#       plt.subplot()
#
# 23. The layout must be:
#
#       [ Line Chart ] [ Bar Chart ]
#       [ Pie Chart  ] [ Line Chart ]
#
# 24. Use plt.tight_layout() so that the charts do not overlap.
#
# 25. Display the complete figure using plt.show().
#
# IMPORTANT:
# ------------------------------------------------------------
# You MUST use:
#
#   plt.subplot()
#   plt.plot()
#   plt.bar()
#   plt.pie()
#   enumerate()
#   max()
#   index()
#   explode
#   plt.tight_layout()
#   plt.show()
#
# Do NOT create separate figures for each chart.
# All 4 charts must appear in ONE figure.
# ============================================================
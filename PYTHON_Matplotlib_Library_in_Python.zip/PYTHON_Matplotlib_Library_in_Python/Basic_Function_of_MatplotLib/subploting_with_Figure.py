import matplotlib.pyplot as plt

# fig,ax=plt.subplots(1,3,figsize=(10,5))
# x=["Sudarshan CHaudhary","Rahul Gupta","Saroj Singh Rajput"]
# y=[1000,5000,7000]


# #Line chart 
# ax[0].plot(x,y)
# ax[0].set_title("Line Plot")



# # bar chart
# ax[1].bar(x,y)
# ax[1].set_title("Bar Diagram")

# print(plt.show())


fig,ax=plt.subplots(1,4,figsize=(10,5))
x=["Sudarshan Chaudhary",'Rahul Gupta','Susant Singh Rajput']
y=[10000,50000,60000]

# Line chart
ax[0].plot(x,y)
ax[0].set_title('Line plot')


#Bar chart
ax[1].bar(x,y,color="purple",label="Sales")
ax[1].set_title('Bar chart')


#Line chart
ax[2].plot(x,y)
ax[2].set_title('Bar chart')


# Pie chart
ax[3].pie(y,labels=x,colors=["purple","pink","red"],autopct='%1.1f%%')
ax[3].set_title('Pie chart')



print(plt.show())


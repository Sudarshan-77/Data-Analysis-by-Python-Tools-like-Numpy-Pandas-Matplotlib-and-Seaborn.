"""Matplotlib is one of the main function in python library for plotting graphs, visuals, charts and Daigram . It is easy for us to understand and present it properly"""

## Plotting a simple line chart as shown below 
# import matplotlib.pyplot as plt
# x=[1,2,3,4,5]
# y=[50,25,60,45,90]



"""Why we use different functions in matplotlib"""
# To connvert different numerical data in to graphs


## Basis Introduction of plot Function
"""plot()"""

# It is generally used to print line graoh 
# plt.plot(x,y,color="red",linestyle="-",marker='s',label="sales")
# print(plt.show())



import matplotlib.pyplot as pt 
x=["Sunday","Monday","Tuesday","Wednesday","Thrusday","Friday"]
y=[90,20,40,50,10,70]
pt.plot(x,y,color="pink",label="Sales",linewidth=3,linestyle="-",marker="o")
pt.title("Total Sales this weekend")
pt.xlabel("Days in a weeks")
pt.ylabel("Sales per each Day in a week")


"""print(pt.legend())"""
# Uses of plt.legend()

# 1. Identify different lines
# 2. Identify different datasets
# 3. Display labels of plotted data
# 4. Distinguish between multiple lines
# 5. Show what each color represents
# 6. Show what each marker represents
# 7. Position the legend
# 8. Change legend font size
# 9. Display multiple labels
# 10. Make graphs easier to understand


"""print(pt.legend(loc="upper right") and pt.legend(loc="upper left"))"""
#upper left function helps to print the label on the upper left side of the graph
# upper right function helps to print the label on the upper right side of the graph
"""pt.legend(loc="upper left")"""

#----------------------------------------------------------------------------------

"""print(pt.legend(loc"=loweer left")) and pt.legend(loc="lower right")"""
#lower left functions help to prin the lable on the lower left side of the graph
#lower right functions help to print tghe label on the lower right side of the graph
# pt.legend(loc="lower right")




""" fontsize"""
# pt.legend(fontsize=100)
## It helps to show th fontsize of the label 



# Uses of plt.grid()

# 1. Add grid lines to the graph
# 2. Make values easier to read
# 3. Help compare data points
# 4. Help identify exact values
# 5. Improve graph readability
# 6. Control grid lines on X-axis
# 7. Control grid lines on Y-axis
# 8. Customize grid line style
# 9. Customize grid line color
# 10. Customize grid line transparency


# pt.grid()
# pt.grid(color="red",linewidth="2",linestyle=":")



# pt.xlim()
"""Used to limit the range of the x-axis"""
# pt.xlim("Sunday","Wednesday")



#pt.ylim()
"""Used to limit the range of the y-axis"""
# pt.ylim(10,70)



#pt.xticks()
"""Helps to change the labele of the x-axis as shown below"""
pt.xticks(["Sunday","Monday","Tuesday","Wednesday","Thrusday","Friday"],["Sun","Mon","Tue","Wed","Thr","Fri"])



#pt.yticks()
"""Helps to change the label of the y-axis as shown below"""
pt.yticks([90,20,40,50,10,70],[1000,4000,9000,10000,5000,0])

print(pt.show())


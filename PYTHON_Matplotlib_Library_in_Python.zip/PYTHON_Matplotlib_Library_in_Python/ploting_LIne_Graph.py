import matplotlib.pyplot as plt
x=["Sunday","Monday","Tuesday","Wednesday","Thrusday","Friday","Saturday"]
y=[10,30,50,5,60,25,90]


plt.plot(x,y,color="pink",linewidth=4,linestyle=":",label="Sales_Data",marker="o")

# plt.legend(loc="lower right",fontsize=10)

# plt.xlim("Sunday","Tuesday")
# plt.ylim(5,50)

# plt.xticks(["Sunday","Monday","Tuesday","Wednesday","Thrusday","Friday","Saturday"],["Sun","Mon","Tue","Wed","Thu","Fri","Sat"])



plt.grid(color="blue",linewidth=1,linestyle="-")

plt.title("Sales Report of Kathmandu Valley")
plt.xlabel("Days of the Week")
plt.ylabel("Total Sells per Days in a Week")
print(plt.show())



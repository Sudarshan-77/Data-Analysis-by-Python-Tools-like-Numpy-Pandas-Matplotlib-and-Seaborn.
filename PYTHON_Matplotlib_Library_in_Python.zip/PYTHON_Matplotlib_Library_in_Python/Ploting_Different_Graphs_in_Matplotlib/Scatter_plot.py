# import matplotlib.pyplot as plt
# plt.scatter([1,4,3,2],[50,90,80,60],color="pink",label="Sudarshn Chaudhary")
# plt.scatter([2,6,4,1],[40,80,90,50],color="blue",label="Arbind Kumar Chaudhary")
# plt.grid(color="black",linestyle=":",linewidth=2)
# print(plt.show())


import matplotlib.pyplot as plt
plt.scatter([1,2,3,4,5],[50,60,70,80,90],color="blue", label="Aman Kumar Singh")
plt.scatter([3,4,5,6,7],[60,70,75,80,90],color="pink", label="Manoj Karki")
plt.grid(linestyle="-",linewidth=0.5)
plt.legend()
plt.title("Mark Obtained according to Hours of Study")
plt.xlabel("Hours of Studied")
plt.ylabel("Marks Obtained")
print(plt.show())
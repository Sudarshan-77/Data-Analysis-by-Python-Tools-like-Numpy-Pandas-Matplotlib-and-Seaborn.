


import matplotlib.pyplot as plt

"""matplotlib.pyplot function helps to extract all the necessary function of matplotlib library life line graphg,color, labels,axis, title etc"""

x=["Sunday","Monday","Tuesday","Wednesday","Thrusday","Friday"]
y=[20,30,10,70,40,50]
plt.plot(x,y)

##Plot the graph on the basis of x and y axis

plt.title('Sales this weekend in big mart')
# The title of the graph


plt.xlabel("Weeks in a day")
# The title label od the x-axis of the graph


plt.ylabel("Total Sales per day in a week")
# The title label of the y-axi of the graph

print(plt.show())
#Helps to print/show the line graph in the specific windows format
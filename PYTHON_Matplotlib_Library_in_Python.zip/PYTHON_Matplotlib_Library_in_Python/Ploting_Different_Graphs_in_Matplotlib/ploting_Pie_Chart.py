# import matplotlib.pyplot as plt
# Region=["North","South","East","West"]
# Data=[4000,5000,6000,7000]
# plt.pie(Data,labels=Region,autopct='%1.1f%%',colors=["pink","red","blue","green"])
# plt.title("Sales Data in Different Regions of India")
# plt.show()




import matplotlib.pyplot as plt
values=[10000,60000,40000,50000,60000,15000,6000]
cities=["Pokhara","Kathmandu","Birgunj","Bharatpur","Janakpur","lalitpur","Biratnagar"]
plt.pie(values,labels=cities,autopct='%1.1f%%',colors=["pink","red","green","blue","yellow","purple","black"])
plt.title("Population of Different cities of Nepal")
plt.xlabel("Fig:-Cities")
plt.show()


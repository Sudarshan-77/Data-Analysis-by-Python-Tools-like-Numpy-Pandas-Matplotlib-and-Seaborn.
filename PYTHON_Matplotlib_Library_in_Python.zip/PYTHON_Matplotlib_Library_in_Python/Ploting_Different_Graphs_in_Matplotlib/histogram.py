import matplotlib.pyplot as plt
# Scores=[50,60,80,35,45,67,86,34,67,53]
# # Data=[5,3,4,3,2,1,4,0,0,9]
# plt.hist(Scores,bins=7,color="Purple",edgecolor="black")
# plt.title("Marks Distribution of the students")
# plt.xlabel("No of Students")
# plt.ylabel("Total Marks scores by student")
# print(plt.show())








# ============================================================
# HISTOGRAM PRACTICE QUESTIONS
# ============================================================


# QUESTION 1 — BASIC HISTOGRAM
# ------------------------------------------------------------
# Create a histogram using the following Marks data.
#
# Requirements:
# - Use bins=5
# - Set edgecolor="black"
# - Add a suitable title
# - Add labels to both axes
# - Display the histogram

# Marks = [45, 56, 67, 78, 89, 90, 55, 62, 73, 81,
#          49, 68, 77, 85, 92]
# plt.hist(Marks,bins=10,color="purple",edgecolor="black")
# plt.xlabel("No of Students")
# plt.ylabel("Marks")
# print(plt.show())


# QUESTION 2 — CHANGE THE BINS
# ------------------------------------------------------------
# Create a histogram using the following Scores.
#
# Requirements:
# - Use bins=7
# - Set edgecolor="black"
# - Add a suitable title
# - Add X-axis label as "Scores"
# - Add Y-axis label as "Number of Students"
#
# Observe how the histogram changes when you change
# the number of bins.

Scores = [50, 60, 80, 35, 45, 67, 86, 34, 67, 53,
          72, 91, 44, 58, 76, 82, 69, 73, 88, 95]




# QUESTION 3 — STUDENT MARKS
# ------------------------------------------------------------
# Create a histogram showing the distribution of student marks.
#
# Requirements:
# - Use bins=6
# - Use edgecolor="black"
# - Add a suitable title
# - X-axis = "Marks"
# - Y-axis = "Number of Students"

Student_Marks = [35, 42, 55, 67, 71, 89, 92, 45, 51, 63,
                 74, 81, 38, 49, 58, 69, 77, 84, 95, 61]
plt.hist(Student_Marks,color="pink",bins=6,edgecolor="red")
print(plt.show())


# QUESTION 4 — SALES DISTRIBUTION
# ------------------------------------------------------------
# A company recorded the following daily sales.
#
# Create a histogram to show the distribution of sales.
#
# Requirements:
# - Use bins=5
# - Add a suitable title
# - X-axis = "Sales Amount"
# - Y-axis = "Number of Days"
# - Set edgecolor="black"

Sales = [120, 150, 180, 200, 175, 220, 250, 190, 160, 140,
         210, 230, 270, 300, 280, 195, 165, 155, 240, 260]


# QUESTION 5 — AGE DISTRIBUTION
# ------------------------------------------------------------
# Create a histogram showing the age distribution of students.
#
# Requirements:
# - Use bins=6
# - Set edgecolor="black"
# - Add a suitable title
# - X-axis = "Age"
# - Y-axis = "Number of Students"

Ages = [18, 19, 20, 21, 22, 23, 24, 25, 21, 22,
        20, 19, 26, 27, 28, 24, 23, 22, 21, 20,
        29, 30, 25, 26, 24, 23, 22, 21, 27, 28]


# QUESTION 6 — EMPLOYEE SALARY
# ------------------------------------------------------------
# Create a histogram showing the distribution of employee salaries.
#
# Requirements:
# - Use bins=5
# - Set edgecolor="black"
# - Add a suitable title
# - X-axis = "Salary"
# - Y-axis = "Number of Employees"

Salary = [25000, 30000, 35000, 40000, 45000, 50000,
          55000, 60000, 65000, 70000, 35000, 42000,
          48000, 52000, 58000, 62000, 68000, 72000]


# QUESTION 7 — TEMPERATURE DISTRIBUTION
# ------------------------------------------------------------
# Create a histogram showing the distribution of daily temperatures.
#
# Requirements:
# - Use bins=6
# - Set edgecolor="black"
# - Add a suitable title
# - X-axis = "Temperature"
# - Y-axis = "Number of Days"

Temperature = [18, 20, 22, 25, 27, 29, 30, 28, 26, 24,
               21, 19, 23, 25, 27, 31, 32, 29, 26, 24]


# QUESTION 8 — EXAM SCORES
# ------------------------------------------------------------
# Create a histogram showing the distribution of exam scores.
#
# Requirements:
# - Use bins=10
# - Set edgecolor="black"
# - Add a suitable title
# - X-axis = "Exam Score"
# - Y-axis = "Number of Students"

Exam_Scores = [35, 42, 48, 51, 55, 58, 60, 63, 65, 68,
               70, 72, 74, 76, 78, 80, 82, 85, 88, 91,
               93, 95, 97, 45, 52, 67, 73, 81, 89, 94]


# QUESTION 9 — HISTOGRAM WITH ALPHA
# ------------------------------------------------------------
# Create a histogram using the following data.
#
# Requirements:
# - Use bins=7
# - Set edgecolor="black"
# - Set alpha=0.7
# - Add a suitable title
# - Add labels to both axes
#
# Try changing the alpha value and observe what happens.

Data = [12, 15, 18, 20, 22, 25, 27, 30, 32, 35,
        37, 40, 42, 45, 47, 50, 52, 55, 58, 60]


# QUESTION 10 — CHALLENGE
# ------------------------------------------------------------
# Create a histogram showing the distribution of heights.
#
# Requirements:
# - Use bins=8
# - Set edgecolor="black"
# - Add a suitable title
# - Add X-axis label = "Height (cm)"
# - Add Y-axis label = "Number of People"
# - Add a legend with label="Height Distribution"
# - Display the histogram

Heights = [150, 155, 158, 160, 162, 165, 168, 170, 172, 175,
           178, 180, 182, 185, 188, 190, 165, 170, 175, 180,
           160, 164, 169, 174, 179, 184, 187, 192, 195, 198]
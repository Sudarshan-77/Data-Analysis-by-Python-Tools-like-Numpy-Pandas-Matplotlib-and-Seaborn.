import numpy as np
array_1=np.array([[1,2,3,4],
                  [5,6,7,8],
                  [9,10,10,11]])
array_2=np.array([
    [2,2,2,2]
])

result= array_1*array_2
print(f"The multiplication of two array is{result}")
""""🔴 Level 3 — Challenge

Q7. Create:

* Array A with shape (2, 3)
* Array B with shape (3,)

Perform multiplication using broadcasting.

Then print:

1. Array A
2. Array B
3. Result
4. Result shape"""



import numpy as np
array_a=np.array([
    [1,2,3],
    [4,5,6]

])
array_b=np.array([
    [2,2,2]
])
result= array_a*array_b
print(f"the result of the {result}")
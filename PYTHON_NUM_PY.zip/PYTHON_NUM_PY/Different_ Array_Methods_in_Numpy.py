# import numpy as np
# zeroth=np.zeros(3)
# print(zeroth)


# import numpy as np
# ones=np.ones(6)
# print(ones)



# import numpy as np
# indentity_matrix=np.identity(3)
# print(indentity_matrix)


# import numpy as np
# ones=np.ones([6,2])
# print(ones)



# """ Putting Specific Value by Yourself"""
# import numpy as np
# Specific=np.full([3,3],9)
# print(Specific)


# import numpy as np
# array=np.eye(3,9)
# print(array)



import numpy as np
# array=np.array([
#     [
#         [1,2,3],
#         [4,5,6],
#         [7,8,9]
#     ]
# ])
# print(array.ndim)


# arr=np.array([1,True, "3e+j"])
# print(arr.dtype)



# import numpy as np
# array= np.array([1,2,3,4],dtype="bool")
# print(array.dtype)
# print(array)
# float=array.astype(float)
# print(float)
# print(float.dtype)




# object_array=np.array([{"name":"Vidhant Chaudhary"},["Apple","Banana","Avocado"],"jonny sins",1,2.3, 3+4j,True],dtype="object")
# print(object_array.dtype)


# Simulating a dataset (5 samples, 3 features)
data = np.array([[10, 20, 30],
[15, 25, 35],
[20, 30, 40],
[25, 35, 45],
[30, 40, 50]])
# Calculating mean and standard deviation for each feature (column)
mean = data.sum(axis=0)
print(mean)
# std = data.std(axis=0)
# Normalizing the data using broadcasting
# normalized_data = (data - mean) / std
# print(normalized_data)
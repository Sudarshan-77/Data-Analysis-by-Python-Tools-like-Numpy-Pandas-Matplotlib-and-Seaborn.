"""Q2. Create a 2D array:
[[1, 2, 3],
 [4, 5, 6],
 [7, 8, 9]]
 Create another array [10, 20, 30].

Use broadcasting to add the second array to every row."""



import numpy as np
array_1=np.array([
    [1,2,3],
    [4,5,6],
    [7,8,9]
])
array_2=np.array([10,20,30])
print(array_1+array_2)
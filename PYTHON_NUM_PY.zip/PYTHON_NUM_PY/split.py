# import numpy as  np
# arry1= np.array([1,2,3,4,5,6])
# splt=np.split(arry1,6)
# print(splt)


# import numpy as np
# arry2 = np.array([1,2,3,4,5,4,6,7])
# vertical_split=np.vsplit(arry2,2)
# print(vertical_split)



""" Vertical and Horizontal Split are mainly appiled on 2 d arry"""
# import numpy as np
# arry1= np.array([
#     [1,2,3],
#     [4,5,6]
# ])
# vertical_split=np.vsplit(arry1,2)
# print(vertical_split)



# import numpy as np
# arry1= np.array([
#     [1,2,3,4,5,6]
# # ])
# horizontal_split=np.vsplit(arry1,2)
# print(horizontal_split)





import numpy as np

arr = np.array([
    [10, 20, 30, 40, 50, 60],
    [70, 80, 90, 100, 110, 120],
    [130, 140, 150, 160, 170, 180],
    [190, 200, 210, 220, 230, 240],
    [250, 260, 270, 280, 290, 300],
    [310, 320, 330, 340, 350, 360]
])

"""Using NumPy, perform the following operations:

1. Use np.vsplit() to divide the array into 3 equal horizontal sections. (3 marks)
2. Use np.hsplit() to divide the original array into 3 equal vertical sections. (3 marks)
3. Use np.split() to divide the original array into 2 equal parts along the rows. (2 marks)
4. Print the results of all three operations with appropriate labels. (2 marks)

Restriction: Do not use loops or manually create the smaller arrays."""

# print(np.vsplit(arr,3))
# print(np.hsplit(arr,3))
print(np.split(arr,2))
# lis=[i for i in range(1,100000)]
# import sys
# print(sys.getsizeof(lis))

# import numpy as np
# arry=np.arange(1,100000,dtype="int32")
# print(sys.getsizeof(arry))

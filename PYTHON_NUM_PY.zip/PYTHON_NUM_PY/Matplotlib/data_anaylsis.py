import pandas as pd
import matplotlib.pyplot as plt



# Load the Data Set
df=pd.read_csv("Data.csv")
# print()



# Clean the Data Set
df=df.dropna()
print(df)

# remove Duplicates Data
df=df.drop_duplicates()



# Importing and plotting the DataSets
# type_counts=df['type'].value_counts()
# plt.figure(figsize=(10,5))
# plt.scatter(type_counts.index,type_counts.values,color="purple",label="scatter plot1")

# plt.bar(type_counts.index , type_counts.values,width=0.2, color=["purple","pink"],label="Movies vs Tv Shows")
# plt.grid()
# plt.legend()

# print(plt.show())



# Pie chart showing
# country=df["country"].value_counts()
# plt.figure(figsize=(10,5))
# plt.pie(country.values,labels=country.index,autopct="%1.1f%%")
# print(plt.show())



# how many number of release changed over year
type_counts=df['type'].value_counts()
plt.figure(figsize=(10,5))
plt.scatter(type_counts.index,type_counts.values,color="purple",label="Category of Movies")
no=df["release_year"].value_counts()
plt.figure(figsize=(10,5))
plt.scatter(no.index,no.values,color="blue",label="Release Year")

plt.grid()
print(plt.show())

# import numpy as np
# import  matplotlib.pyplot as pt
# x=np.linspace(-10,10,30)
# y=x
# pt.plot(x,y)
# print(pt.show())




# import numpy as np
# import matplotlib.pyplot as pt
# x=np.linspace(-10,10,30)
# y=2*x+3
# pt.plot(x,y)
# print(pt.show())


# import numpy as np
# import matplotlib.pyplot as pt
# x= np.linspace(-10,10,100)
# y=  x*x
# pt.plot(x,y)
# print(pt.show())




""" Sigmoid Grpah using numpy and matplotlib"""
import numpy as np
import matplotlib.pyplot as pt
x= np.linspace(-10,10,100)
y=(1/(1+np.exp(x)))
pt.plot(x,y)
print(pt.show())
# x= np.linspace(-10,10,100)
# y=np.log(x)*x
# pt.plot(x,y)
# print(pt.show())



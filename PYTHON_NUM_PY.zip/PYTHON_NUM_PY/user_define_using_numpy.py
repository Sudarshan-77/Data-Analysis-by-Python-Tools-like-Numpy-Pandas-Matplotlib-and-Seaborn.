# sigmoid Function
import numpy as np
def sigmoid(a):
    return 1/(1+np.exp(-(a)))
a=np.arange(100)
print(sigmoid(a))
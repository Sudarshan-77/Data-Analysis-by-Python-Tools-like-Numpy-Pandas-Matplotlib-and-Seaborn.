import numpy as np
# arry1=np.array([1,2,4])
# arry2=np.array([3,4,5])
# vertical_stack=np.vstack((arry1,arry2))
# horizontal_stack= np.hstack((arry1,arry2))
# print(vertical_stack)
# print(horizontal_stack)



arry1= np.array([
    [1,2],
    [3,4],
    [5,6]
])
arry2 = np.array([[7,8],
                   [9,10],
                   [11,12]])
Vertical_stack= np.hstack((arry1,arry2))
print(Vertical_stack)


Horizonatl_stack= np.hstack((arry1,arry2))
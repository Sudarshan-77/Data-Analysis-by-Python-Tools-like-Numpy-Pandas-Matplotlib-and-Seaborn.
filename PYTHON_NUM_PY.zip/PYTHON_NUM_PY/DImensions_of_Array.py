"1 Dimensional Array"
import numpy as np
array_1=np.array([1,2,3,4,5])
print(array_1)


print()
"2 Dimensional Array"
array_2=np.array([
    [1,2,3,4],
    [5,6,7,8]
])
print(array_2)



print()
"Multi DImensional Array"
array_3=np.array(
    [
        [
            [1,2,3,4],
            [5,6,7,8],
            [9,10,11,12]
        ]
    ]
)
print(array_3)
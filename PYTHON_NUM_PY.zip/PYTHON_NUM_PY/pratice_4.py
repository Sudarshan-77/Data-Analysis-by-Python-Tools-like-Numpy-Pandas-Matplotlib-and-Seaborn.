"""Q6. Create an array of shape (3, 1) and another array of shape (1, 4).

Use broadcasting to add them.

Before running the code, predict the shape of the result."""

import numpy as np
array_1=np.array([
    [2],
    [3],
    [4]
])

array_2= np.array(
    [
        [2,3,4,5]
        ])
result=array_1+array_2
print(f"The addition of two arrays is {result}")




# is nan
"""It is used to check whether missing value is presented in array or not"""

# import numpy as np
# arry1=np.array([1,np.nan,3,np.nan,5])
# print(np.isnan(arry1))

import numpy as np
array_1=np.array([1,np.nan,3,np.nan,5])
print(np.isnan(array_1))

print(np.nan_to_num(array_1,nan=00))


#np.nan_to_num() in NumPy is used to replace missing/invalid numerical values
"""0 as Default and if we pass aany value then the value should remain on that"""

# import numpy as np
# arry1=np.array([1,np.nan,3,np.nan,5])
# print(np.nan_to_num(arry1,nan=4))

# import numpy as np
# array1=np.array([1,np.nan,3,np.nan,5])
# print(np.nan_to_num(array1,nan=2))

# import numpy as np
# array1=np.array([1,np.nan,3,4,5,np.nan])
# result=array1[~np.isnan(array1)]
# print(result)







#np.isinf()
"""Helps to detect infinity or any big number that canot be eaily calculated or not"""

# import numpy as np
# arry=np.array([1,np.inf,3,-np.inf,5])
# print(np.isinf(arry))
# print(np.nan_to_num(arry, posinf=1000, neginf=-1999))

# import numpy as np
# arry=np.array([1,np.inf,3,-np.inf,5])
# print(np.isinf(arry))
# print(np.nan_to_num(arry, posinf=1000, neginf=-1999))


# import numpy as np
# arry=np.array([1,np.inf,2,-np.inf,5])
# print(np.isinf(arry))
# print(np.nan_to_num(arry, posinf=1000, neginf=-1999))


import numpy as np
arry=np.array([1,2,np.inf,-np.inf])
print(np.nan_to_num(arry,posinf=1000,neginf=-1000))
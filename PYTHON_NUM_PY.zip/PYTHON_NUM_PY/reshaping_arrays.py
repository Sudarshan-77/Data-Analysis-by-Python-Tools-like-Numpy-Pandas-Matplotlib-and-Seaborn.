# import numpy as 
# np

# reshaping = np.array([1,2,3,4,5,6,7,8,9])
# result = reshaping.reshape(3,3)
# print(result.ndim)

# print(result)


# print((result.flatten()).ndim)
# print(result.ndim)
# print(result)



# print(result.ravel())
# print(result.ndim)



# araay_2d= np.array([
#     [1,2],
#     [4,5]
# ])

# # new_array=np.append(araay_2d,[2,3,4,5])
# new_array=np.insert(araay_2d,1,[9,10],axis=1)
# print(new_array)


# import numpy as np
# array_1=np.array([
#     [1,2],
#     [3,4]])
# array_2=np.array([[2,3],[4,5]])
# final=np.concatenate((array_1,array_2))
# print(final)





"""Deleteing an array element using delete method here we go through"""
import numpy as np
array=np.array([
    [1,2,3],
    [4,5,6],
    [7,8,9]
])
mew_array=np.delete(array,0,axis=1)
print(mew_array)












import numpy as np
array_1=np.arange(1,100,24)
array_2=np.arange(100,200,24)

def mean_squared_error(exact,approximate):
    return np.mean((exact-approximate)**2)
print(mean_squared_error(array_1,array_2))
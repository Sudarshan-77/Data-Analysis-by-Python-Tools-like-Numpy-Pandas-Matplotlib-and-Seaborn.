# import numpy as np
# prices=np.array([100,200,300,400])
# discount= 20 # applying 20n percentage discount
# final_pric=prices*(1-discount/100)
# print(final_pric)


import numpy as np
arry=np.arange(12).reshape(4,3)
import numpy as np
arry=np.array([
    [1,2,3,4],
    [4,5,6,7],
    [8,9,10,11]   
] 
)
# print(arry[arry[:,1,2,3]])
# print(np.arry[arry[1]])
print(arry[1:2,[1]])




"""How to randomly generate an array in numpy"""

import numpy as np
arry=np.random.randint(1,100,24).reshape(6,4)
# print(arry)
print(arry[~(arry>50) & (arry%2==0)])
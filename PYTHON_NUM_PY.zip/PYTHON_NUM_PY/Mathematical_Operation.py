import numpy as np
operation=np.array([10,15,20,25,30,35])
# print(operation+5)
# print(operation*5)
# print(operation%5)
# print(operation/5)
# print(operation-5)
# print(operation**2)


# print(np.mean(operation))
# print(np.average(operation))
# print(np.std(operation))
# print(np.min(operation))
# print(np.max(operation))



# print(np.sum(operation))
# # print(np.subtraction(operation))
# print(np.var(operation))


# print(operation[-1])
# print(operation[0])
# print(operation[1])
# print(operation[0:2])


print(operation[::-1])
print(operation[::2])

# Fancing Indexing helps to access multiple element at ones using indexing

# print(operation[[1,2,4,0]])

print(operation[operation>30])
print(operation[operation<30])
# print(operation[operation%5])
"""Q7. Create:

* Array A with shape (2, 3)
* Array B with shape (3,)

Perform multiplication using broadcasting.

Then print:

1. Array A
2. Array B
3. Result
4. Result shape"""

# import numpy as np
# array_A=np.array([
#     [2,3,4],
#     [5,6,7]])
# array_B=np.array([2,2,2])
# multiply=array_A*array_B
# print(f"The multiple of two array_A and array_B is {multiply}")



"""Q8. Create:

* Array A with shape (3, 1)
* Array B with shape (1, 4)

Perform addition using broadcasting.

Predict the result shape before coding."""

# import numpy as np
# array_A=np.array([
#     [2],
#     [3],
#     [4]
# ])
# array_B=np.array([1,2,3,4])
# print(f"The sum of two number is {array_A+array_B}")


"""A → shape (2, 3, 4)
B → shape (4,)

Use broadcasting to add A and B.

Print the resulting array and its shape.
"""

# import numpy as np
# array_1=np.ones([2,3,4])
# array_2=np.ones([4,])
# print(f"The addition of two number is {array_1+array_2}")
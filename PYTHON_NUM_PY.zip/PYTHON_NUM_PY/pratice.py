import numpy as np
# a = np.ones((3, 3))
# b = np.array([1, 2, 3])
# print(a + b)
# a = np.ones((3, 4))
# b = np.array([1, 2, 3, 4])
# print(a + b)


# a = np.ones((3, 4))
# b = np.array([1, 2, 3, 4])
# print(a + b)


# a = np.ones((2, 3, 4))
# b = np.ones((4))
# print(b)
# print(a+b)


"""Q1. Create two NumPy arrays:

* Array A: [10, 20, 30]
* Array B: 5

Use broadcasting to add 5 to every element of Array A."""

Array_A=np.array([10,20,30])
Array_B=np.array([5])
print(Array_A+Array_B)
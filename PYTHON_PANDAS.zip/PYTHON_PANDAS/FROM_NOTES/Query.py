import pandas as pd
data = {
    "Name":["Sudarshan Chaudhary",None,"Ram Dev Shah","Arun Sing","Arun Mahato","Sudarshan Chaudhary","Arun Mahato"],
    "Age":[10,20,None,30,40,10,10],
    "Subject":["Chemistry","Physics","Maths","Computer",None,"Computer","Computer"],
    "Email":["dc148672@gmail.com","Chaudharyvidhant@gmail.com","vidhantchaudhary@gmail.com","wm95220@gmail.com","dipikachaudhary@gmail.com","wm95220@gmail.com","Chaudharyvidhant@gmail.com"]
}
df=pd.DataFrame(data)
# print(df.query("Age>25 | Subject=='Chemistry'"))


# Columns Names has spaces, use backtricks Sign (')
# print(df.query("`First Name`=='Sudarshan Chaudhary'"))


# print(df.query("Age>=30"))

# print(df.query("Subject=='Chemistry'"))

# print(df.query("10<Age<40"))

# print(df.query("`Subject`=='Physics'"))


# print(df.isnull())
# print(df.isnull().sum())

# print(df.dropna(axis=0))
# print(df.fillna(0))


# df["First Name"]=df["First Name"].fillna("Darshan Chaudhary")
# print(df)

# df["Age"]=df["Age"].fillna(60)
# print(df)

# print(df.fillna(0))

# print(df.drop_duplicates())


print(df["Name"].str.startswith('S'))

print(df["Name"].str.endswith('o'))

print(df["Name"].str.split(' '))



import pandas as pd
data={
    "Name":["Alice","Bob","Charlie","Manoj","Manmohan","Rawan"],
    "Age":[20,35,30,40,50,60],
    "City":["Delhi","Banglore","Kathmandu","Birgunj","Hetauda","Simara"]
}

df=pd.DataFrame(data)
# print(df[["Name","Age","City"]])

# print(df.loc[4,["Name","Age"]])

# print(df.iloc[4,0:3])
# print(df.iloc[5,0:2])

# print(df[df["Age"]>30])

# print((df["Age"]>10) & (df["City"]=="Delhi"))

# print((df["Name"]=="Bob")| (df["Age"]<30))
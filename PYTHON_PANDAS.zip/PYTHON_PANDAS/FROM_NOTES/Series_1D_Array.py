# import pandas as pd
# s=pd.Series([10,20,30,"Sudarshan"])
# print(s)



import pandas as pd
# s=pd.Series([10,20,30,"Sudarshan Chaudhary",True,10.09],index=["a","b","c","d","e","f"])
# print(s)


data=[
    ["Alice","Bob","Charlie"],
    [20,35,30],
    ["Delhi","Mumbai","Banglore"]
]

df=pd.DataFrame(data,columns=["Name","Age","City"])
# print(df)


#You can change index and columns by ourselves . Let's go through
# df.index=[0,2,3]
# df.columns=["ich bin Sudarshan","Umaar","Sahar"]
# print(df)

# print(df.head(2))
# print(df.tail(2))
print(df.info())

print(df.describe())

print(df.columns)

print(df.shape)
import pandas as pd
data={
    
    "Name":["Sudarshan Chaudhary","Radhe Shyam Rashiya","Susant Singh Rajput","Rahul Gupta","Rajan Yadav"],
    "Age":[20,30,10,40,50],
    "Subject":["Maths","Physics","Chemistry","Computer","English"]
}
df=pd.DataFrame(data)
df.rename(columns={"Name":"Naame"},inplace=True)
print(df)
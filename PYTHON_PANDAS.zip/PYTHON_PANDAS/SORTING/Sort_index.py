import pandas as pd
data= {
    "Name":["Sudarshan Chaudhary","Radhe Shyam Rashiya","Susant Singh Rajput","Rahul Gupta","Rajan Yadav"],
    "Age":[20,30,10,40,50],
    "Subject":["Maths","Physics","Chemistry","Computer","English"]
}
df=pd.DataFrame(data)
print(df.sort_index(axis=1, ascending=True))
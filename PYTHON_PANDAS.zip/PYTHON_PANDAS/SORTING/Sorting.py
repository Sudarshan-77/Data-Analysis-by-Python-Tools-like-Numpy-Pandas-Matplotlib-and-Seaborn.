import pandas as pd
data= {
    "Name":["Sudarshan Chaudhary","Radhe Shyam Rashiya","Susant Singh Rajput","Rahul Gupta","Rajan Yadav"],
    "Age":[20,30,10,40,50],
    "Subject":["Maths","Physics","Chemistry","Computer","English"]
}
df=pd.DataFrame(data)


# Sort values in ascending order
# a=df.sort_values("Age")
# print(a)


# Sort values in descending order
# b=df.sort_values("Age",ascending=False)
# print(b)



# Sort Multiple values 
print(df.sort_values(["Name","Age"]))


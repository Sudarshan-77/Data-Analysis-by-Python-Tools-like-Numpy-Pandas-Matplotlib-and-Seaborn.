# Reset Index in Pandas 
"""Reset Index"""

import pandas as pd
data={
    
    "Name":["Sudarshan Chaudhary","Radhe Shyam Rashiya","Susant Singh Rajput","Rahul Gupta","Rajan Yadav"],
    "Age":[20,30,10,40,50],
    "Subject":["Maths","Physics","Chemistry","Computer","English"]
}
df=pd.DataFrame(data)

print(df.drop(["Name"],axis=0))

# print(df.reset_index(drop=True))
import pandas as pd

data = {
    "Employee_ID": [
        "Emp001", "Emp002", "Emp003",
        "Emp004", "Emp005", "Emp001"
    ],
    "Name": [
        "Sudarshan Chaudhary",
        "Radhe Shyam Rashiya",
        "Susant Singh Rajput",
        "Rahul Gupta",
        "Rajan Yadav",
        "Sudarshan Chaudhary"
    ],
    "Age": [20, 30, 10, 60, 50, 20],
    "Subject": [
        "Maths", "Physics", "Chemistry",
        "Computer", "English", "Maths"
    ]
}

df = pd.DataFrame(data)

# print(df)


# Q1. [1 Mark]
# Identify which rows are duplicated in the DataFrame.
# print(df.duplicated())

# Q2. [1 Mark]
# Display only the rows that are duplicated.
# print(df[df.duplicated()])


# Q3. [1 Mark]
# Display all rows involved in duplication,
# including the first occurrence.


# Q4. [1 Mark]
# Remove all completely duplicated rows from the DataFrame.
# a=df.drop_duplicates()
# print(a)


# Q5. [1 Mark]
# Remove duplicate records based only on the "Employee_ID" column.
# a=df.drop_duplicates("Employee_ID")
# print(a)




# Q6. [1 Mark]
# Remove duplicate records based only on the "Age" column.
# b=df.drop_duplicates("Age")
# print(b)


# Q7. [1 Mark]
# Remove duplicate Employee_ID records but keep the LAST occurrence.
a=df.drop_duplicates(subset="Employee_ID",keep="last")
print(a)

# Q8. [1 Mark]
# Remove duplicates based on BOTH "Employee_ID" and "Name".

# print(df.duplicated(subset=["Employee_ID","Name"]))


# Q9. [1 Mark]
# Find the total number of duplicated rows.
# print(df.duplicated().sum())


# Q10. [1 Mark]
# Create a new DataFrame containing only unique Employee_ID records.
import pandas as pd

data = {
    "name": [
        "Sudarshan Chaudhary",
        "Ram Dev Shah",
        "Rahul Jaiswal",
        "Jagdish Mahato",
        "Roshan Kumar",
        "Amit Sharma"
    ],

    "Age": [19, 20, 21, 24, 30, 27],

    "Salary": [100000, 20000, 30000, 60000, 75000, 50000],

    "Department": [
        "IT",
        "HR",
        "IT",
        "Finance",
        "IT",
        "HR"
    ]
}

df = pd.DataFrame(data)


# Q1. Display only the name and Department columns.
print(df[["name","Department"]])


# Q2. Display the first 3 rows.

print(df.head(3))


# Q3. Display the last 2 rows.
print(df.tail(2))

# Q4. Add a Bonus column equal to 10% of Salary.
df["Bonus"]=df["Salary"]*0.1
print(df)


# Q5. Add a Tax column equal to 5% of Salary.


df["Tax"]=df["Salary"]*0.05
print(df)


# Q6. Add a Net_Salary column using:
#     Net_Salary = Salary + Bonus - Tax

df["Net_Salary"]=df["Salary"]+df["Bonus"]-df["Tax"]
print(df)

# Q7. Display employees whose Salary is greater than 50,000.
print(df[df["Salary"]>50000])



# Q8. Display employees whose Age is greater than 20.
print(df[df["Age"]>20])

# Q9. Display employees who work in the IT department.
print(df[df["Department"]=="IT"])

# Q10. Display employees whose Salary is greater than 50,000
#      AND whose Age is less than 30.

print(df[(df["Salary"] > 50000) & (df["Age"] < 30)])




# Q11. Display employees who work in IT
#      OR have a Salary greater than 70,000.

print(df[(df["Department"]=="IT") & (df["Salary"]>70000)])

# Q12. Find the average Salary.


import numpy as np
print(np.average(df["Salary"]))





# Q13. Find the maximum Salary.

# print(np.max(df["Salary"]))

# Q14. Find the minimum Salary.

print(np.min(df["Salary"]))

# Q15. Find the total Salary of all employees.


print(np.sum(df["Salary"]))

# Q16. Find the employee who has the highest Salary.

print(df[np.max(df["Salary"])])
"""

Q17. Find the employee who has the lowest Salary.

Q18. Sort the DataFrame by Salary from highest to lowest.

Q19. Sort the DataFrame by Age from lowest to highest.

Q20. Find employees whose Salary is greater than
     the average Salary.

Q21. Find the average Salary of employees
     who work in the IT department.

Q22. Find the average Salary of employees
     whose Age is greater than 25.

Q23. Find the employee with the highest Salary
     among employees in the IT department.

Q24. Find the second-highest Salary.

Q25. Count how many employees are in each Department.

Q26. Find the total Salary paid to each Department.

Q27. Find the average Salary for each Department.

Q28. Display only employees whose Net_Salary
     is greater than 50,000.

Q29. Sort employees by Net_Salary from highest to lowest.

Q30. Display the name, Department, Salary,
     Bonus, Tax, and Net_Salary of employees
     whose Salary is above the average Salary.
"""
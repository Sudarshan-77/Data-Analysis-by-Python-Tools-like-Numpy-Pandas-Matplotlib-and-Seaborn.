

# #Using pivot() to reshape it into wide format
# import pandas as pd
# data={
#     "Name":["Alice","Alice","Alice","Bob","Bob","Bob","Charlie","Charlie",'Charlie'],
#     "Subjects":["Math","Science","English","Math","Science","english","Math","Science","English"],
#     "Scores":[85,90,88,78,82,85,92,89,94]
   
    

# }
# df=pd.DataFrame(data)
# # UYsing pivot to convert the data in to wide fiormat

# pivoted=df.pivot(index="Name",columns="Subjects",values="Scores")
# print(pivoted)





import pandas as pd

data = {
    "Name": [
        "Alice", "Alice", "Alice",
        "Bob", "Bob", "Bob",
        "Charlie", "Charlie", "Charlie"
    ],

    "Month": [
        "Jan", "Feb", "Mar",
        "Jan", "Feb", "Mar",
        "Jan", "Feb", "Mar"
    ],

    "Sales": [
        50000, 55000, 60000,
        45000, 50000, 52000,
        70000, 75000, 80000
    ]
}

df = pd.DataFrame(data)

# print(df)


# ============================================================
# QUESTION 1 — BASIC PIVOT
# ============================================================

# Using pivot(), create a wide-format DataFrame.
#
# index   = Name
# columns = Month
# values  = Sales
#
# Print the result.

# wide_format=df.pivot(index="Name",columns="Month",values="Sales")
# print(wide_format)


# ============================================================
# QUESTION 2 — CHANGE THE INDEX
# ============================================================

# Create another pivot.
#
# index   = Month
# columns = Name
# values  = Sales
#
# another_pivot=df.pivot(index="Month",columns="Name",values="Sales")
# print(another_pivot)
# Print the result.


# ============================================================
# QUESTION 3 — RESET INDEX
# ============================================================

# Create a pivot using:
#
# index   = Name
# columns = Month
# values  = Sales
#
# Then use reset_index().
# another_pivot_1=another_pivot.reset_index()
# print(another_pivot_1)
# Print the result.


# ============================================================
# QUESTION 4 — MAXIMUM SALES
# ============================================================

# Using the pivoted DataFrame:
#
# Find the highest Sales value.

# highest_sales_value=df.pivot(index="Name",columns="Month",values="Sales")

# print(highest_sales_value.max().max())
# Print the result.


# ============================================================
# QUESTION 5 — MINIMUM SALES
# ============================================================

# Using the pivoted DataFrame:
#
# Find the lowest Sales value.
# print(highest_sales_value.min().min())
#
# Print the result.


# ============================================================
# QUESTION 6 — TOTAL SALES
# ============================================================

# Using the pivoted DataFrame:
#
# Find the total Sales of all employees
# highest_sales_value=df.pivot(index="Name",columns="Month",values="Sales")
# print(highest_sales_value.mean())

# across all months.
#
# Print the result.


# ============================================================
# QUESTION 7 — EMPLOYEE TOTAL
# ============================================================

# Create a pivot using:
#
# index   = Name
# columns = Month
# values  = Sales
#
# Add a new column:
new_column = df.pivot(
    index="Name",
    columns="Month",
    values="Sales"
)

total_add = new_column.sum(axis=1)

new_column["Total_Sales"] = total_add

print(new_column)
# Total_Sales
#
# Calculate the total Sales for each employee.


# ============================================================
# QUESTION 8 — SORTING
# ============================================================

# Using the DataFrame from Question 7:
#
# Sort employees by Total_Sales
# from highest to lowest.
#

# pro=new_column.sort_values(["Total_Sales"])
# print(f'The sorting result of the provided is {pro}')
# Print the result.


# ============================================================
# QUESTION 9 — HIGHEST-SELLING EMPLOYEE
# ============================================================

# Using the sorted DataFrame:
#
# Display the employee with the highest Total_Sales.

# noob=new_column.sort_values(["Total_Sales"],ascending=False)
# print(f"The sorting result of the provided in descending ordet is {noob}")



# ============================================================
# QUESTION 10 — FILTERING
# ============================================================

# Display employees whose:
#
# Total_Sales > 150000
#
# Print the result.

# result=new_column[new_column[("Total_Sales>150000")]]
# print(result)

# ============================================================
# QUESTION 11 — MONTHLY TOTAL
# ============================================================

# Using the pivoted DataFrame:
#
# Calculate the total Sales for each month.
#
# Display:
#
# January total
# February total
# March total


pivoted_DataFrame=df.pivot(index="Name",columns="Month",values="Sales")
print(pivoted_DataFrame.sum())


# ============================================================
# QUESTION 12 — HIGHEST MONTH
# ============================================================

# Using the monthly totals:
#
# Find which month has the highest total Sales.
print(pivoted_DataFrame.idxmax("index"))


# ============================================================
# QUESTION 13 — FINAL REPORT
# ============================================================

# Create a final report with:
#
# Name | Jan | Feb | Mar | Total_Sales
#
# Requirements:
#
# 1. Use pivot()
# 2. Use reset_index()
# 3. Add Total_Sales
# 4. Sort by Total_Sales descending
# 5. Print the result.





# ============================================================
# QUESTION 14 — FINAL FILTER
# ============================================================

# Using the final report:
#
# Display only employees whose
# Total_Sales is greater than 150000.


# ============================================================
# QUESTION 15 — FINAL CHALLENGE
# ============================================================

final_challeneg=df.pivot(
    index="Name",
    columns="Month",
    values='Sales'
)

Total=final_challeneg.sum(axis=1)
final_challeneg["Total_Sales"]=Total
print(final_challeneg)




# Create a pivot using:
#
# index   = Name
# columns = Month
# values  = Sales
#
# Then:
#
# 1. Add Total_Sales.
# 2. Sort by Total_Sales descending.
# 3. Display only Name and Total_Sales.
# 4. Display the employee with the highest Total_Sales.
# 5. Find the month with the highest total Sales.
# Q1. HARD PANDAS MELT() CHALLENGE — [10 MARKS]
#
# A company stores employee performance data in WIDE FORMAT.
# Your task is to convert it into LONG FORMAT using melt().
#
# IMPORTANT:
# - You MUST use pandas melt().
# - Do NOT manually create a new DataFrame.
# - Do NOT use loops.
#
# ------------------------------------------------------------

import pandas as pd

data = {
    "Employee_ID": ["E001", "E002", "E003", "E004"],
    "Name": ["Ram", "Shyam", "Hari", "Sita"],
    "Department": ["IT", "HR", "Finance", "IT"],
    "Jan_Sales": [50000, 45000, 60000, 55000],
    "Feb_Sales": [52000, 48000, 58000, 62000],
    "Mar_Sales": [55000, 51000, 63000, 60000],
    "Jan_Bonus": [5000, 4500, 6000, 5500],
    "Feb_Bonus": [5200, 4800, 5800, 6200],
    "Mar_Bonus": [5500, 5100, 6300, 6000]
}

df = pd.DataFrame(data)

# TASKS:
#
# 1. Display the original DataFrame.                         [1 mark]

print(f'The origanl DataFrame is {df}')
#
# 2. Use melt() to convert ONLY the Sales columns
#    (Jan_Sales, Feb_Sales, Mar_Sales) into long format.     [3 marks]
#
# 3. Keep Employee_ID, Name, and Department unchanged.       [2 marks]
#
# 4. Rename the generated variable column to "Month"
#    and the generated value column to "Sales".              [1 mark]

convert=df.melt(id_vars=["Employee_ID",'Name','Department'],value_vars=["Jan_Sales", "Feb_Sales", "Mar_Sales"],var_name="Months",value_name="Sales")
print(convert)
#
# 5. Create another melted DataFrame for ONLY the Bonus
#    columns (Jan_Bonus, Feb_Bonus, Mar_Bonus).              [2 marks]
#
# 6. Print both final DataFrames.                            [1 mark]
#
# ------------------------------------------------------------
#
# Expected Sales DataFrame structure:
#
#   Employee_ID    Name    Department    Month    Sales
#   E001           Ram     IT            Jan      50000
#   E002           Shyam   HR            Jan      45000
#   ...
#
# Expected Bonus DataFrame structure:
#
#   Employee_ID    Name    Department    Month    Bonus
#   E001           Ram     IT            Jan      5000
#   E002           Shyam   HR            Jan      4500
#   ...
convert_1=df.melt(id_vars=["Employee_ID",'Name','Department'],value_vars=["Jan_Bonus", "Feb_Bonus", "Mar_Bonus"],var_name="Months",value_name="Bonus")
print(convert_1)
#
# ------------------------------------------------------------
#
# BONUS CHALLENGE:
# Without using loops, create ONE final DataFrame containing:
#
# Employee_ID | Name | Department | Month | Sales | Bonus
#
new_data_Frame=df[(df[convert],df[convert_1])]
# Example:
#
# E001 | Ram | IT | Jan | 50000 | 5000
# E001 | Ram | IT | Feb | 52000 | 5200
# E001 | Ram | IT | Mar | 55000 | 5500
#
# BONUS: [5 marks]

# Combine Sales and Bonus

new_data_Frame = pd.merge(

    "Sales",

    "Bonus",

    on=["Employee_ID", "Name", "Department", "Month"]

)

print(new_data_Frame)
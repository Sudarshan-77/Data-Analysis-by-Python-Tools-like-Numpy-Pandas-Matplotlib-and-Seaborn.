import pandas as pd
# """The melt() method in pandas is used to unpivot a DataFrame from wide format to long format to long fomrat in other word, It takes columns that represents different variable  and combines them in to key value pairs(i.e long-form Data)"""


data={
    "Name":["Sudarshan","Sidhant","Mohan"],
    "Math":[90,80,70],
    "Science":[89,78,67],
    "English":[67,78,98]
}
df=pd.DataFrame(data)
# print(df)

melted=df.melt(id_vars=["Name"],value_vars=["Math","Science","English"],var_name="Subjects",value_name="Scores")
print(melted)




# Q1. [10 Marks]
# Consider the following DataFrame:

# import pandas as pd

# data = {
#     "Name": ["Ram", "Shyam", "Hari", "Sita"],
#     "Math": [85, 78, 92, 88],
#     "Science": [90, 82, 89, 94],
#     "English": [75, 80, 85, 91]
# }

# df = pd.DataFrame(data)

# # Task:
# # 1. Convert the DataFrame from wide format to long format using melt().

# convert=df.melt(id_vars=["Name"],value_vars=["Math","Science","English"],var_name="Subject",value_name="Scores")
# print(convert)

# 2. Keep the "Name" column unchanged.

# 3. Convert "Math", "Science", and "English" into a single "Subject" column.
# 4. Store the marks in a column named "Score".
# 5. Print the final melted DataFrame.
#
# Expected columns:
# Name | Subject | Score
#
# Marks Distribution:
# - Correct use of melt()              [4 marks]
# - Correct id_vars                    [2 marks]
# - Correct var_name and value_name    [2 marks]
# - Correct output                     [2 marks]













# Dropping Nan Function in Pandas

# import pandas as pd
# data={
#     "name":[None,"Sudarshan Chaudhary","Roshan Yadav",None,"Mohan Singh","Tanav Singh"],
#     "Age":[19,None,40,50,60,70]
# }
# df=pd.DataFrame(data)
# df.dropna(inplace=True)
# print(df)

import pandas as pd

data = {
    "Name": [
        None,
        "Sudarshan Chaudhary",
        "Roshan Yadav",
        None,
        "Mohan Singh",
        "Tanav Singh",
        "Arbind Shah",
        None
    ],
    "Age": [19, None, 40, 50, 60, 70, None, 80],
    "Salary": [40000, 50000, None, 70000, None, 90000, 60000, None],
    "City": [
        "Kathmandu",
        "Birgunj",
        None,
        "Pokhara",
        "Lalitpur",
        "Kathmandu",
        None,
        "Bhaktapur"
    ]
}

df = pd.DataFrame(data)

# ============================================================
# 🟢 BASIC
# ============================================================

# Q1. Remove all rows containing at least one NaN value.
# print(df.dropna(inplace=True))


# Q2. Remove rows only when the "Name" column contains NaN.
# df.dropna(subset=["Name"], inplace=True)
# print(df)




# Q3. Remove rows only when the "Age" column contains NaN.
# ============================================================
# 🟡 MEDIUM
# ============================================================
# df.dropna(subset="Age",inplace=True)
# print(df)

# Q4. Remove rows containing NaN values specifically in
#     the "Salary" column.
# df.dropna(subset="Salary",inplace=True)
# print(df)

# Q5. Remove rows containing NaN in either "Name" or "City".
# df.dropna(subset=["Name","City"],inplace=True)
# print(df)

# Q6. Remove rows containing NaN in "Age" or "Salary".
# df.dropna(subset=["Age","Salary"],inplace=True)


# Q7. Remove all rows containing NaN and permanently
#     apply the change to df.

# df.dropna(inplace=True)


# ============================================================
# 🔴 HARD
# ============================================================

# Q8. Remove rows containing NaN only when BOTH
#     "Name" AND "Age" are NaN.

# df.dropna(
#     subset=["Name", "Age"],
#     how="all",
#     inplace=True
# )
# print(df)



# Q9. Remove rows containing NaN in "Name", "Age",
#     and "Salary".

# df.dropna(
#     subset=["Name","Age",'Salary'],inplace=True
# )


# Q10. Remove rows containing NaN in any of these columns:
#
#      Name
#      Salary
#      City
#
#      Keep the rows where these three columns have
#      complete data.

# df.dropna(
#     subset=["Name","City",'Salary'],inplace=True
# )


# ============================================================
# 💀 FINAL CHALLENGE — 10 MARKS
# ============================================================

# Q11. Starting with the original DataFrame:
#
#      1. Remove rows where Name is NaN.

df.dropna(subset=["Name"],inplace=True)
print(df)
#      2. From the remaining DataFrame, remove rows where
#         Salary is NaN.
#      3. Permanently apply both operations.
#      4. Print the final DataFrame.
#
#      Do NOT manually enter or delete any row indexes.
#
# ============================================================
#
# RESTRICTION:
#
# Use only:
#
#     dropna()
#     subset
#     inplace
#
# Do NOT use:
#
#     drop()
#     loc
#     iloc
#     fillna()
#     loops
#     if/else
#
# ============================================================
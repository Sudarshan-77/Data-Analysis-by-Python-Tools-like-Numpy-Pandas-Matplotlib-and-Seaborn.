import pandas as pd
data = {
    "Name": [
        "Sudarshan Chaudhary",
        "Arbind Kumar Shah",
        "Roshan Chaudhary",
        "Nikhil Chaudhary"
    ],
    "Age": [10, 20, 30, 40],
    "Salary": [40000, 50000, 60000, 70000]
}
df = pd.DataFrame(data)
# ================================
# 🔥 HARD LEVEL CHALLENGE
# ================================
# Q1. Add an "Employee_ID" column at position 0 with:
#     Emp1, Emp2, Emp3, Emp4
df.insert(0,"Employee_ID",[" Emp1", "Emp2", "Emp3", "Emp4"])
print(df)

# Q2. Add a "Bonus" column at position 4.
#     Bonus = 10% of Salary

df.insert(4,"Bonus",df["Salary"]*0.1)
print(df)


# Q3. Add a "Tax" column at position 5.
#     Tax = 5% of Salary
df.insert(5,"Tax",df["Salary"]*0.05)
print(df)


# Q4. Add a "Net_Salary" column at position 6.
#     Net_Salary = Salary + Bonus - Tax
df.insert(6,"Net_Salary",df['Salary'] + df["Bonus"] - df["Tax"])
print(df)



# Q5. Display ONLY these columns in exactly this order:
#     Employee_ID, Name, Age, Salary, Bonus, Tax, Net_Salary
print(df.head())



# Q6. Display ONLY the first 2 rows of the result from Q5.
print(df.head(2))



# Q7. Display ONLY the last 2 rows of the result from Q5.


# 🔥 Q8. HARDest:
# Perform all the operations above and finally display
# ONLY the last 2 rows with ONLY these columns:
#
# Employee_ID, Name, Salary, Bonus, Tax, Net_Salary
#
# Expected column order:
# Employee_ID | Name | Salary | Bonus | Tax | Net_Salary
#
# Do NOT create another DataFrame manually.
# Use the same df throughout the question.
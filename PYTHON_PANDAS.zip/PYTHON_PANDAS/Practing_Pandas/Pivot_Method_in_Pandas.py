

# #Using pivot() to reshape it into wide format
import pandas as pd
data={
    "Name":["Alice","Alice","Alice","Bob","Bob","Bob","Charlie","Charlie",'Charlie'],
    "Subjects":["Math","Science","English","Math","Science","English","Math","Science","English"],
    "Scores":[85,90,88,78,82,85,92,89,94]
   
    

}
df=pd.DataFrame(data)
# # UYsing pivot to convert the data in to wide fiormat

print(df.pivot(index="Name",columns="Subjects",values="Scores"))
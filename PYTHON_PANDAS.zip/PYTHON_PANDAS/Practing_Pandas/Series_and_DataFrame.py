"""Series"""
# Series is one Dimensional Array that can stotre the objects with multiple Data Types such as String, Float, Integer, Boolean, Complex Number etc.

import pandas as pd
Data=pd.Series(["Arbind Chaudhary",True,"3i+j",54,78.9])
print(Data)


"""Data Frame"""

#Data Frame is the arragement of the given data in dictionary i.e Key value  Pairs 
""" It is an arrangement of the Data in Table Format which makes us easy visual for viewing, reading and understanding od the data """

Dictionary=pd.DataFrame({
    "Name":["Sudarshan CHaudhary","Ram Dev Shah Lahera","Rahul Gupta","Rupesh Shah","Sahil Shah"],
    "Age":[20,19,22,18,23],
    "Caste":["Tharu","Indian",'Kalwar',"Teli","Teli"]
},index=["a","b","c","d","e"])

print(Dictionary)

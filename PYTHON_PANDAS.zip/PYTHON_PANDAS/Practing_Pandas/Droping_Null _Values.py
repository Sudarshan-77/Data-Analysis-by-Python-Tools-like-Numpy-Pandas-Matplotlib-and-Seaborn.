import pandas as pd
Dictionary=pd.DataFrame(
    {
    "Name":["Sudarshan Chaudhary",None,"Ram Dev Shah Lahera","Rahul Gupta","Rupesh Shah","Sahil Shah","Sudarshan Chaudhary"],
    "Age":[20,None,19,22,18,23,23],
    "Caste":["Tharu","Indian",'Kalwar',"Teli","Teli",'Tharu',None],
    "Sales":[30000,40000,50000,60000,70000,80000,90000]
})

# print(Dictionary.dropna(subset=["Age",'Caste']))


# print(Dictionary)

Dictionary["Total Sales"]=Dictionary["Sales"]+10000
print(Dictionary)



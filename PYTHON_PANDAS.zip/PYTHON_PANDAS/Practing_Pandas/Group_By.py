
import pandas as pd

df = pd.DataFrame({
    "Name": [
        "Ram", "Ram", "Ram",
        "Rahul", "Rahul", "Rahul",
        "Rupesh", "Rupesh", "Rupesh",
        "Salendra", "Salendra", "Salendra"
    ],

    "Subject": [
        "Math", "Science", "English",
        "Math", "Science", "English",
        "Math", "Science", "English",
        "Math", "Science", "English"
    ],

    "Scores": [
        90, 85, 88,
        100, 92, 95,
        34, 75, 65,
        56, 60, 70
    ]
})

# Grouped=df.groupby("Name")["Scores"].agg(["min","max","mean"])
# print(Grouped)
print()

New=df.groupby("Name")["Scores"].transform("mean")
print(New)
# print()
# print(df)
# for x,y in Grouped:
#     print(x,"\n",y)
#     print()
#     print()

# TO get a specific person Search by get grouop by 
# print(Grouped)


# Get_Grouped=Grouped.get_group("Sudarshan Chaudhary")
# print(f"{Get_Grouped}")





# Using Transform Function 
# Transformed=df.groupby("Subject")["Scores"].transform("mean")
# print(Transformed)
# print(df)



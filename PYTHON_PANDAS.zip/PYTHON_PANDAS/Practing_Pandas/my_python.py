import pandas as pd
name= {
    "Name":["Sudarshan Chaudhary","Ram Dev Shah Lahera","Aashutosh Chaudhary"]
}
import pandas as pd
Dictionary=pd.DataFrame(
    {
    "Name":["Sudarshan Chaudhary",None,"Ram Dev Shah Lahera","Rahul Gupta","Rupesh Shah","Sahil Shah","Sudarshan Chaudhary"],
    "Age":[20,None,19,22,18,23,23],
    "Caste":["Tharu","Indian",'Kalwar',"Teli","Teli",'Tharu',None],
    "Sales":[30000,40000,50000,60000,70000,80000,90000]
})


# Creating Json file using pandas framewoprk in python
# Dictionary.to_json("Arbind_Chaudhary.json",index=0)


# creating excel file using pandas framework in python
Dictionary.to_excel("Arbind_Chaudahry12.xlsx")


# Creating csv file using pandas framwork in python
# Dictionary.to_csv("Chaudhary.csv",index=0)
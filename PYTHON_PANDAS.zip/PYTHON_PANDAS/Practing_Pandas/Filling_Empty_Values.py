import pandas as pd
Dictionary=pd.DataFrame(
    {
    "Name":["Sudarshan Chaudhary",None,"Ram Dev Shah Lahera","Rahul Gupta","Rupesh Shah","Sahil Shah","Sudarshan Chaudhary"],
    "Age":[20,None,19,22,18,23,23],
    "Caste":["Tharu","Indian",'Kalwar',"Teli","Teli",'Tharu',None],
    "Sales":[30000,40000,50000,60000,70000,80000,90000]
})

"""Filling all the empty values onces using the  fill na function """
new=Dictionary.fillna("RAM DEVWA")
# print(new)


# very_new=Dictionary.fillna("Age"=18)


# Proper Method of using fill na function in pandas 


Dictionary["Age"]=Dictionary["Age"].fillna(19)
# print(Dictionary)

Dictionary["Name"]=Dictionary["Name"].fillna("Salendra Chaudhary")
# print(Dictionary)

Dictionary["Caste"]=Dictionary["Caste"].fillna("Xettri")
print(Dictionary)
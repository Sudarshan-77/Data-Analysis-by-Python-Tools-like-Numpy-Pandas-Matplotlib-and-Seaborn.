
import pandas as pd
Dictionary=pd.DataFrame(
    {
    "Name":["Sudarshan Chaudhary","Ram Dev Shah Lahera","Rahul Gupta","Rupesh Shah","Sahil Shah"],
    "Age":[20,19,22,18,23],
    "Caste":["Tharu","Indian",'Kalwar',"Teli","Teli"]
})

# Insert Method used to insert data into our data frame


Dictionary.insert(1,"Subject",["Maths","Science","English","Nepali","Computer"])
print(Dictionary)




""" Usling Loc method for manipulating data in pandas"""

'''Changing Single Value using loc Method. Here we go through'''
Dictionary.loc[5,["Name","Age","Subject","Caste"]]=["Arbind Kumar Chaudhary",19,"MBBBS","Ahir"]
print(Dictionary)



# """Can we access using iloc Method let's See here we go through it"""
# Dictionary.iloc[5,0:3]=["Manoj Tiwari",20,"English","Thary"]
# print(Dictionary)

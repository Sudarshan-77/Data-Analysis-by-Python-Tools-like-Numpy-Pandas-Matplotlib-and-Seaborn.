# We can access the element of the data frames using different methods 
"""i) using Direct Method
   ii) using query method
   iii) using loc method
   iii) using iloc method"""



import pandas as pd
Dictionary=pd.DataFrame(
    {
    "Name":["Sudarshan Chaudhary","Ram Dev Shah Lahera","Rahul Gupta","Rupesh Shah","Sahil Shah"],
    "Age":[20,19,22,18,23],
    "Caste":["Tharu","Indian",'Kalwar',"Teli","Teli"]
},index=["a","b","c","d","e"])


# """Accessing single element using Direct Method"""
# print(Dictionary["Name"])
# print()

# """Accessing Multiple elements using Direct Method"""
# print(Dictionary[["Name","Age"]])
print()


""" Using Different condition using DIrect Method"""

# print(Dictionary[(Dictionary["Age"]>19) | (Dictionary["Name"]=="Rupesh Shah")])




# """Using Query Method f0r acdessing single element"""
# print(Dictionary.query("Name=='Sudarshan CHaudhary'"))



# """Using Query Method for accessing multiple elements"""
# print(Dictionary.query("Name=='Sudarshan CHaudhary' and Age>18"))


"""Loc method is used for accesing the element using Specific location"""

# print(Dictionary.loc["c","Age"])

""" using Loc to access multple data in the element using specific location"""

# print(Dictionary.loc[["a","b","c","d","e"],["Name"]])




"""iloc method is used for accessing the element using index based """
# print(Dictionary.iloc[1,2])


"""iloc method is used for accessing the element using  index based accessing multiple element
Note:-The index for iloc must be in numeric form whether the index of the dataframe in the string form such as "a","b","c"
"""
# Accessing Multiple Elements

print(Dictionary.iloc[0:2,0:3])
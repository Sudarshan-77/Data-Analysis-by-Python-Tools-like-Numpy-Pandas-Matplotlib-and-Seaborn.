import pandas as pd

Dictionary=pd.DataFrame(
    {
    "Name":["Sudarshan Chaudhary","Ram Dev Shah Lahera","Rahul Gupta","Rupesh Shah","Sahil Shah","Sudarshan Chaudhary"],
    "Age":[20,19,22,18,23,23],
    "Caste":["Tharu","Indian",'Kalwar',"Teli","Teli",'Tharu']
})

# print(Dictionary[Dictionary.duplicated()])

print(Dictionary.drop_duplicates("Name"))




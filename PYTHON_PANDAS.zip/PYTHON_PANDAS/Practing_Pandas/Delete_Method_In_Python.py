# import pandas as pd
# Dictionary=pd.DataFrame(
#     {
#     "Name":["Sudarshan Chaudhary","Ram Dev Shah Lahera","Rahul Gupta","Rupesh Shah","Sahil Shah"],
#     "Age":[20,19,22,18,23],
#     "Caste":["Tharu","Indian",'Kalwar',"Teli","Teli"]
# })
# a=Dictionary.drop([2,3,4],axis=0)
# print(a)




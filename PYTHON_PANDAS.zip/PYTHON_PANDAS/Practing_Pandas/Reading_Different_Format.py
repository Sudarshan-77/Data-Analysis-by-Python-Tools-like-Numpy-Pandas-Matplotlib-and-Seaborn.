import pandas as pd
a=pd.read_csv("Chaudhary.csv",encoding="latin")
print(a)


b=pd.read_json("Arbind_Chaudhary.json")
print(b)




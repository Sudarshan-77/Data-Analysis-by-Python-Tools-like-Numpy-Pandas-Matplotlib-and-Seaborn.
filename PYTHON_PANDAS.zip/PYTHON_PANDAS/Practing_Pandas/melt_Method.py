import pandas as pd
# """The melt() method in pandas is used to unpivot a DataFrame from wide format to long format to long fomrat in other word, It takes columns that represents different variable  and combines them in to key value pairs(i.e long-form Data)"""


data={
    "Name":["Sudarshan","Sidhant","Mohan"],
    "Math":[90,80,70],
    "Science":[89,78,67],
    "English":[67,78,98]
}
df=pd.DataFrame(data)
# print(df)

print(df.melt(id_vars=["Name"],value_vars=["Math","Science","English"],var_name="Subjects",value_name="Scores"))
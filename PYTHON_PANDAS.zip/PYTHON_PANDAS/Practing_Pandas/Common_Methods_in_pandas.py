
"""Descirbe Function in Python"""
# Describe is one of the most important function in python. It allows us to find the count, Mean, Std, min, max, Quartile, Median etc automatically

import pandas as pd
Dictionary=pd.DataFrame({
    "Name":["Sudarshan CHaudhary","Ram Dev Shah Lahera","Rahul Gupta","Rupesh Shah","Sahil Shah"],
    "Age":[20,19,22,18,23],
    "Caste":["Tharu","Indian",'Kalwar',"Teli","Teli"]
},index=["a","b","c","d","e"])

print(Dictionary.describe())



"""info()"""
#info() is one of the most important function in python it allows us to find datatype of each of the obejct inside the dataframe


print(Dictionary.info())
print()





"""Head Method"""
# Head Method helps us to find the top of the elements in data frame 

print(Dictionary.head(3))
print()

"""Tail Method"""
#Tail Method helps us to fnd the Bottom of the elements in data frame

print(Dictionary.tail(3))
print()
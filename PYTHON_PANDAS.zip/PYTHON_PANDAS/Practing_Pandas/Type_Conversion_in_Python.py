import pandas as pd

Dictionary=pd.DataFrame({
    "Name":["Sudarshan CHaudhary","Ram Dev Shah Lahera","Rahul Gupta","Rupesh Shah","Sahil Shah"],
    "Age":[20,19,22,18,23],
    "Caste":["Tharu","Indian",'Kalwar',"Teli","Teli"],
    'Date':["2080/07/08","2014/12/01","2065/01/08","2075/09/09","2060/10/09"]

},index=["a","b","c","d","e"])


#as type helps us to convert the respective data into another Data Type as seen below
Dictionary["Age"]=Dictionary["Age"].astype("Float32")
print(Dictionary['Age'].dtype)


#to_datetime helps us to convert the respective data into Date format. Thing to note here is The format of the provided data must be in integer it should not be in string or boolean or complex data type
Dictionary["Date"]=pd.to_datetime(Dictionary["Date"])
print(Dictionary["Date"])

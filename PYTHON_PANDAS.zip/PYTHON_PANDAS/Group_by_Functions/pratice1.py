# ============================================================
# PANDAS GROUPBY() — 15 MARK QUESTION
# ============================================================

import pandas as pd

df = pd.DataFrame({
    "Name": [
        "Ram", "Ram", "Ram",
        "Rahul", "Rahul", "Rahul",
        "Rupesh", "Rupesh", "Rupesh",
        "Salendra", "Salendra", "Salendra"
    ],

    "Subject": [
        "Math", "Science", "English",
        "Math", "Science", "English",
        "Math", "Science", "English",
        "Math", "Science", "English"
    ],

    "Scores": [
        90, 85, 88,
        100, 92, 95,
        34, 75, 65,
        56, 60, 70
    ]
})

print(df)


# ============================================================
# QUESTION 1 — CREATE GROUPS
# ============================================================

# Group the DataFrame according to the "Subject" column.
Grouped_Object=df.groupby("Subject")
# print(Grouped_Object.mean())
print(Grouped_Object.max())
print(Grouped_Object.count())
# new_group=Grouped_Object.get_group("Salendra")
# print(new_group)

# Display the grouped object.
# for x,y in Grouped_Object:
#     print(x,"\n",y,"\n")
#     print()


# ============================================================
# QUESTION 2 — DISPLAY EACH GROUP
# ============================================================

# Using a for loop, display:
#
# 1. The group name
# 2. The DataFrame belonging to that group
#
# Expected groups:
# Math
# Science
# English


# ============================================================
# QUESTION 3 — FIND A SPECIFIC GROUP
# ============================================================

# Use get_group() to display only the records
# belonging to the "Math" group.

# Specific_Group=Grouped_Object.get_group("Math")
# print(Specific_Group)


# ============================================================
# QUESTION 4 — MINIMUM SCORE
# ============================================================

# Using groupby(), find the minimum score
# for each subject.
# print(Grouped_Object.max())


# ============================================================
# QUESTION 5 — MAXIMUM SCORE
# ============================================================

# Using groupby(), find the maximum score

# for each subject.


# ============================================================
# QUESTION 6 — AVERAGE SCORE
# ============================================================

# Using groupby(), calculate the average score
# for each subject.


# ============================================================
# QUESTION 7 — TOTAL SCORE
# ============================================================

# Using groupby(), calculate the total score
# for each subject.


# ============================================================
# QUESTION 8 — COUNT STUDENTS
# ============================================================

# Using groupby(), count how many students
# are present in each subject.


# ============================================================
# QUESTION 9 — MULTIPLE AGGREGATIONS
# ============================================================

# Using groupby(), calculate the following
# for each subject:
#
# Minimum score
# Maximum score
# Average score
# Total score
#
# Display all results together.


# ============================================================
# QUESTION 10 — HIGHEST AVERAGE
# ============================================================

# Find which subject has the highest
# average score.


# ============================================================
# QUESTION 11 — LOWEST SCORE
# ============================================================

# Find the lowest score among all subjects
# using groupby().


# ============================================================
# QUESTION 12 — GROUP BY NAME
# ============================================================

# Group the DataFrame using the "Name" column.
#
# Find the average score of each student.


# ============================================================
# QUESTION 13 — STUDENT WITH HIGHEST SCORE
# ============================================================

# Group the DataFrame by "Name".
#
# Find the maximum score obtained by each student.


# ============================================================
# QUESTION 14 — GET GROUP CHALLENGE
# ============================================================

# Group the DataFrame by "Name".
#
# Use get_group() to display only:
#
# "Ram"


# ============================================================
# QUESTION 15 — FINAL 15 MARK CHALLENGE
# ============================================================

# Using groupby(), create a complete subject report
# containing:
#
# Subject
# Minimum_Score
# Maximum_Score
# Average_Score
# Total_Score
# Number_of_Students
#
# Requirements:
#
# 1. Group by Subject.
# 2. Calculate minimum score.
# 3. Calculate maximum score.
# 4. Calculate average score.
# 5. Calculate total score.
# 6. Count the number of students.
# 7. Display the final report.
# 8. Find the subject with the highest average score.
# 9. Find the subject with the highest total score.
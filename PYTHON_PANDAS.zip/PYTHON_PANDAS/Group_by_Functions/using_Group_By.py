import pandas as pd

# ============================================================
# DATASET
# ============================================================

df = pd.DataFrame({
    "Name": [
        "Ram", "Ram", "Ram",
        "Rahul", "Rahul", "Rahul",
        "Rupesh", "Rupesh", "Rupesh",
        "Salendra", "Salendra", "Salendra"
    ],

    "Subject": [
        "Math", "Science", "English",
        "Math", "Science", "English",
        "Math", "Science", "English",
        "Math", "Science", "English"
    ],

    "Scores": [
        90, 85, 88,
        100, 92, 95,
        34, 75, 65,
        56, 60, 70
    ]
})

# print(df)


# ============================================================
# QUESTION 1 — GROUPBY NAME
# ============================================================
# Group the DataFrame by "Name".
# Display the groups.

# GROUP_BY_NAME=df.groupby("Name")
# for x,y in GROUP_BY_NAME:
#     print(x,"\n",y)
#     print()
#     print()



# ============================================================
# QUESTION 2 — GROUPBY SUBJECT
# ============================================================
# Group the DataFrame by "Subject".
# Display the groups.
# GROUP_BY_SUBJECT=df.groupby("Name")
# for x,y in GROUP_BY_SUBJECT:
#     print(x,"\n",y)
#     print()
#     print()


# ============================================================
# QUESTION 3 — MAXIMUM SCORE
# ============================================================
# Group the DataFrame by "Name".
# Find the maximum score of each student.

# GROUP_BY_SUBJECT=df.groupby("Name")['Scores'].max()
# print(GROUP_BY_SUBJECT)






# ============================================================
# QUESTION 4 — MINIMUM SCORE
# ============================================================
# Group the DataFrame by "Name".
# Find the minimum score of each student.
# DATAFRAME_BY_NAME=df.groupby("Name")["Scores"].min()
# # print(DATAFRAME_BY_NAME)

# index = df["Scores"].idxmax()

# print(df.loc[index])


# ============================================================
# QUESTION 5 — AVERAGE SCORE
# ============================================================
# Group the DataFrame by "Name".
# Find the average score of each student.

# AVERAGE_SCORE=df.groupby("Name")["Scores"].agg(["mean"])
# print(AVERAGE_SCORE)










# ============================================================
# QUESTION 6 — SELECT COLUMN AFTER GROUPBY
# ============================================================
# Group by "Name".
# Select only the "Scores" column.
# Find the maximum score.

# GROUP_BY_NAME=df.groupby("Name")["Scores"].agg(["max"])
# print(GROUP_BY_NAME)



# ============================================================
# QUESTION 7 — MINIMUM SCORE BY SUBJECT
# ============================================================
# Group by "Subject".
# Select only "Scores".
# Find the minimum score for each subject.
# GROUP_BY_SUBJECT=df.groupby("Subject")["Scores"].agg(["min"])
# print(GROUP_BY_SUBJECT)



# ============================================================
# QUESTION 8 — MIN AND MAX
# ============================================================
# Group by "Name".
# Find both minimum and maximum scores.
# GROUP_BY_NAME=df.groupby("Name")["Scores"].agg(["min","max"])
# print(GROUP_BY_NAME)

# ============================================================
# QUESTION 9 — USING AGG()
# ============================================================
# Group by "Name".
# Using .agg(), calculate:


# GROUP_BY_NAME=df.groupby("Name")["Scores"].agg(["min","max","mean"])
# print(GROUP_BY_NAME)
# #
# 1. Minimum score
# 2. Maximum score
# 3. Average score


# ============================================================
# QUESTION 10 — GET_GROUP()
# ===========================================================
# Group the DataFrame by "Name".
# Use get_group() to display only Ram's records.
# group_by_name=df.groupby("Name")
# Ram_Records=group_by_name.get_group("Ram")
# print(Ram_Records)
# print()
# print()


# ============================================================
# QUESTION 11 — GET_GROUP()
# ============================================================
# Group the DataFrame by "Name".
# Use get_group() to display only Rahul's records.
# Rahul_Records=group_by_name.get_group("Rahul")
# print(Rahul_Records)
# print()
# print()

# ============================================================
# QUESTION 12 — GET_GROUP() BY SUBJECT
# ============================================================
# Group the DataFrame by "Subject".
# Use get_group() to display only the Science records.
# subject=df.groupby("Subject")
# Science_Records=subject.get_group("Science")
# print(Science_Records)


# ============================================================
# QUESTION 13 — MULTIPLE GROUPBY
# ============================================================
# Group the DataFrame by:
#
# Subject
# Name
#
# Display the grouped result.

# Multiple_Category=df.groupby(["Subject","Name"])["Scores"].max()
# print(Multiple_Category)


# ============================================================
# QUESTION 14 — MAXIMUM WITH MULTIPLE GROUPBY
# ============================================================
# Group by ["Subject", "Name"].
# Find the maximum score.


Multiple_Category=df.groupby(["Subject","Name"])["Scores"].agg(["max"])
Maximum_Score=Multiple_Category["Scores"].max()
print(Multiple_Category.loc["Maximum_Score"])



# ============================================================
# QUESTION 15 — MINIMUM WITH MULTIPLE GROUPBY
# ============================================================
# Group by ["Subject", "Name"].
# Find the minimum score.


# ============================================================
# QUESTION 16 — AVERAGE WITH MULTIPLE GROUPBY
# ============================================================
# Group by ["Subject", "Name"].
# Find the average score.


# ============================================================
# QUESTION 17 — AGG() WITH MULTIPLE GROUPBY
# ============================================================
# Group by ["Subject", "Name"].
# Using .agg(), calculate:
#
# minimum score
# maximum score
# average score


# ============================================================
# QUESTION 18 — ADVANCED
# ============================================================
# Find the highest score obtained by each student
# in each subject.
#
# Expected structure:
#
# Subject    Name       max
# English    Ram        ...
# English    Rahul      ...
# Math       Ram        ...
# ...


# ============================================================
# QUESTION 19 — MIN + MAX
# ============================================================
# Group by ["Subject", "Name"].
# Using .agg(), calculate:
#
# Minimum Score
# Maximum Score


# ============================================================
# QUESTION 20 — MULTIPLE AGGREGATIONS
# ============================================================
# Group by "Name".
#
# Calculate:
# Minimum Score
# Maximum Score
# Average Score
# Number of Scores
#
# Use ONE .agg().


# ============================================================
# QUESTION 21 — SUBJECT AGGREGATION
# ============================================================
# Group by "Subject".
#
# Calculate:
# Total Score
# Minimum Score
# Maximum Score
# Average Score


# ============================================================
# QUESTION 22 — HARD
# ============================================================
# Group by ["Subject", "Name"].
#
# Using .agg(), calculate:
#
# Min_Score
# Max_Score
# Avg_Score
# Count
#
# Your final DataFrame should look like:
#
# Subject | Name | Min_Score | Max_Score | Avg_Score | Count


# ============================================================
# QUESTION 23 — CHALLENGE
# ============================================================
# Find the student who has the highest average score
# across all subjects.
#
# Do NOT use a loop.


# ============================================================
# QUESTION 24 — CHALLENGE
# ============================================================
# Find the subject that has the highest average score.
#
# Do NOT use a loop.


# ============================================================
# QUESTION 25 — FINAL CHALLENGE 🔥
# ============================================================
# Using groupby(["Subject", "Name"]) and .agg(),
# create a final DataFrame containing:
#
# Subject
# Name
# Min_Score
# Max_Score
# Avg_Score
# Count
#
# Do NOT use loops.
#
# Rename the aggregation columns properly.
# ============================================================
import pandas as pd

df = pd.DataFrame({
    "Name": [
        "Ram", "Ram", "Ram",
        "Rahul", "Rahul", "Rahul",
        "Rupesh", "Rupesh", "Rupesh",
        "Salendra", "Salendra", "Salendra"
    ],

    "Subject": [
        "Math", "Science", "English",
        "Math", "Science", "English",
        "Math", "Science", "English",
        "Math", "Science", "English"
    ],

    "Scores": [
        90, 85, 88,
        100, 92, 95,
        34, 75, 65,
        56, 60, 70
    ]
})

aggr_1=df.groupby(["Subject","Name"])["Scores"].agg(["max"])
print(df)



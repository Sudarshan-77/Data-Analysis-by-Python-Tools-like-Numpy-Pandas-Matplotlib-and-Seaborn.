import pandas as pd
data={
    "Name":["Sudarshan Chaudhary","Akash Yadav","Arbind Chuaudhary","Rupesh","Salendra"],
    "Salary":[12000,20000,30000,40000,50000],
    "Income":[40000,50000,50000,60000,700000]
}

df=pd.DataFrame(data)
# print(df.describe)
# print(df.columns)
# print(df.shape)





import pandas as pd
df=pd.read_csv("Output.csv",encoding="latin1")
print(df)
import pandas as pd

data= {
    "Employee_Id":["Emp001","Emp002",'Emp003',"Emp004","Emp005"],
    "Name":["Sudarshan Chaudhary","Darshan Chaudhary","Arbind","Dhanveer","Aashutosh"],
    'Age':[19,20,30,40,15],
    "Subject":["Maths","Physics","Chemistry",'English','Nepali'],
    "Date":["2078-01-02","2082-07-09","2019-09-27","2080-9-30","2012-12-09"]
  
}
df=pd.DataFrame(data)
print((df["Age"]).dtype)
df['Age']=df['Age'].astype("float16")

print((df["Age"]).dtype)

print((df["Date"]).dtype)

df['Date']=pd.to_datetime(df["Date"])
print((df["Date"]).dtype)
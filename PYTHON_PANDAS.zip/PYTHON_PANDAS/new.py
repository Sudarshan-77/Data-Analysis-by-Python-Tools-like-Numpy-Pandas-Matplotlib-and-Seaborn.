# import pandas as pd
# data={
#     "name":["Sudarshan Chaudhary","Ram Dev shah","Jagdish Mahato","Roshan Kumar Chaudhary"],
#     "Salary":[100000,50000,60000,70000],
#     "Age":[18,19,20,40]
# }
# df=pd.DataFrame(data)
# df["Bonus"]=df["Salary"]*0.1
# print(df)



"""Q1. Add a Bonus column equal to 10% of Salary.

Q2. Add a Tax column equal to 5% of Salary.

Q3. Display only the name and Salary columns.

Q4. Display the first 2 rows.

Q5. Display the last 2 rows."""


"""import pandas as pd
# import numpy as np
data= {
    "name":["Sudarshan Chaudhary","Ram Dev Shah","Rahul Jaiswal"],
    "Age":[19,20,21],
    "Salary":[100000,20000,30000]
}

df=pd.DataFrame(data)
print(df[["name","Salary"]])
# df["Bonus"]=df["Salary"]*0.1
# print(df[])

# df["Bonus"]=df["Salary"]*0.05
# print(df)




# print(df.columns)
print(df.head(2))
print(df.tail(2))
"""






import pandas as pd
data = {
    "name": [
        "Sudarshan Chaudhary",
        "Ram Dev Shah",
        "Rahul Jaiswal",
        "Amit Kumar",
        "Rohan Thapa",
        "Sahil Ansari",
        "Bibek Sharma",
        "Nischal Gupta"
    ],
    "Age": [19, 20, 21, 25, 28, 22, 30, 24],
    "Salary": [100000, 20000, 30000, 75000, 90000, 45000, 120000, 65000]
}
df = pd.DataFrame(data)



# Questions

# Q1. Add a Bonus column equal to 12% of Salary.

df["Bonus"]=df["Salary"]*0.12
print(df)

# Q2. Add a Tax column equal to 7% of Salary.

df["Tax"]=df["Salary"]*0.7
print(df)


# Q3. Add a NetSalary column using:
"""NetSalary = Salary + Bonus - Tax"""

df["NetSalary"]=df["Salary"]+df["Bonus"]-df["Tax"]
print(df)

# Q4. Display only the name, Salary, and NetSalary columns.


print(df[["name","Salary","NetSalary"]])

# Q5. Display the first 5 rows of the DataFrame.

print(df.head(5))

# Q6. Display the last 3 rows of the DataFrame.
print(df.tail(3))

# Q7. Add a Bonus column equal to 10% of Salary, then add a Tax column equal to 5% of Salary, and finally display only:
# name, Bonus, Tax

df["Bonus"]=df["Salary"]*0.1
df["Tax"]=df["Salary"]*0.05
print(df)

# Q8. Create a Total column using:
# Total = Salary + Bonus
df["Total"]=df["Salary"]+df["Bonus"]


#Then display the first 4 rows containing only:
# name, Salary, Bonus, Total
print(df[["name","Salary","Bonus","Total"]])

# 🔥 Hardest Question
# Q9. Perform all of the following operations in the correct order:

# 1. Add Bonus = 15% of Salary
# 2. Add Tax = 8% of Salary
# 3. Add NetSalary = Salary + Bonus - Tax
# 4. Display only name, Age, Salary, and NetSalary
# 5. Display only the first 5 rows of that result.

# Expected final columns:





# Q10. Starting with the original DataFrame, create these three columns:
"""Bonus    = 10% of Salary
Tax      = 5% of Salary
FinalPay = Salary + Bonus - Tax"""

# Then display only the last 4 rows and only these column
# name | Salary | Bonus | Tax | FinalPay

d=df.tail(4)
print(d[["name","Salary","Bonus","Tax"]])




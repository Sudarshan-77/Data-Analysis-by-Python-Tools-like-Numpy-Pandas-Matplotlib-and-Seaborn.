# import pandas as pd

# data={
#     "name":["Sudarshan Chaudhary","Arbind Kumar Mahato","Sahil Ansari"],
#     "Age":[18,19,20],
#     "City":["Kathmandu","Birgunj","Pokhara"]
# }
# df=pd.DataFrame(data)
# print(df)

# df.to_csv("Output.csv",index=False)



# import pandas as pd
# data={
#     "Name":["Sudarshan Chaudhary","Rahul Jaiswal","Ajay Singh Chaudhary","Rajesh Singh","Arbind Kumar Chaudhary"],
#     "Age":[19,18,20,21,22],
#     "Caste":["Tharu","Ahir","Kanu","Koiri","Bumihar"]
# }
# df=pd.DataFrame(data)
# df.to_json("Raja.json",index=0)

# print(df.describe())

import pandas as pd 
Data= {
    'Name':['ramdev Shah Lahera'],
    'Age':[98]
}
df=pd.DataFrame(Data)
df.to_excel('parbindra_.xlsx')
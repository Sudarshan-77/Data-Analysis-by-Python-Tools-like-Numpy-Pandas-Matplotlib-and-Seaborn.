import pandas as pd
name=pd.read_excel("Sales_Data_100_Rows.xlsx")
print(name)




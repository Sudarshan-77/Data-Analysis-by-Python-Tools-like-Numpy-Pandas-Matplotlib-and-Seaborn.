
# Using Loc Method TO filter Data
import pandas as pd
data={
    "name":["Sudarshan Chaudhary","Pradip Gupta","Shrwam Singh"," Manish Malhotara"],
    "age":[19,20,21,45],
    "salary":[20000,30000,40000,10000]
}
df=pd.DataFrame(data)
# print(df.loc[2,"NAME"])



print(df[(df["salary"]>=20000) | (df["age"]>21)])



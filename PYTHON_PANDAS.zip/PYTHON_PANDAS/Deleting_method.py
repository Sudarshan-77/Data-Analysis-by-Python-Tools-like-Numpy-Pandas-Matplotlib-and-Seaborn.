# import pandas as pd
# data={
#     "Name":["Sudarshan Chaudhary",None,"Arbind Kumar Shah","Roshan Chaudhary","Nikhil Chaudhary"],
#     "Age":[10,None,30,40,None],
#     "Salary":[None,40000,60000,None,70000]
# }

# df=pd.DataFrame(data)
# print(df.isnull().sum())

# df.drop(columns=["Name","Age"],inplace=True)
# print(df.mean())

import pandas as pd

data = {
    "Employee_ID": ["EMP101", "EMP102", "EMP103", "EMP104", "EMP105",
                    "EMP106", "EMP107", "EMP108"],
    "Name": [
        "Sudarshan Chaudhary",
        "Arbind Kumar Shah",
        "Roshan Chaudhary",
        "Nikhil Chaudhary",
        "Rahul Jaiswal",
        "Sahil Ansari",
        "Bibek Sharma",
        "Aman Gupta"
    ],
    "Age": [19, 22, 25, 28, 21, 24, 30, 26],
    "Salary": [45000, 52000, 68000, 75000, 48000, 62000, 90000, 57000],
    "Department": [
        "IT", "HR", "Finance", "IT",
        "Marketing", "Finance", "HR", "IT"
    ]
}

df = pd.DataFrame(data)

# ============================================================
# 🔥 DELETE METHOD — HARD QUESTIONS
# ============================================================

# Q1. Delete the "Age" column using drop().
#     Do not use del or pop().

# print(df.drop(["Age"],axis=1))



# Q2. Delete both "Age" and "Department" columns
#     using a single drop() statement.
# print(df.drop(["Age","Department"],axis=1))


# Q3. Delete the row with index 4 using drop().
# print(df.drop(4,axis=0))


# Q4. Delete rows with indexes 1, 3, and 6
#     using a single drop() statement.

# print(df.drop([1,3,6],axis=0))


# Q5. Delete the "Employee_ID" column and permanently
#     apply the change to df.
# df.drop("Employee_ID",axis=1,inplace=True)
# print(df)

# Q6. Delete the "Salary" and "Department" columns
#     permanently using inplace=True.
# df.drop(["Salary",'Department'],axis=1,inplace=True)


# ============================================================
# 🔥🔥 HARDER
# ============================================================

# Q7. Delete rows with indexes 0, 2, 5, and 7
#     and permanently apply the change to df.

# df.drop([0,2,5,7],axis=0,inplace=True)
# print(df)


# Q8. Delete the following columns:
#
#     Employee_ID
#     Department
#
#     Then delete rows:
#
#     1, 4, 6
#
#     All deletions must be performed on df itself.
# df.drop(["Employee_ID","Department"],axis=1,inplace=True)
# df.drop([1,4,6],axis=0,inplace=True)
# print(df)



# Q9. Delete all of the following in the correct order:
#
#     1. Department column
#     2. Employee_ID column
#     3. Row index 2
#     4. Row index 5
#
#     Finally print df.
# a=df.drop(["Employee_ID","Department"],axis=1)
# b=a.drop([3,5],axis=0)
# print(b)


# ============================================================
# 💀 FINAL BOSS — 10 MARKS
# ============================================================

# Q10. Starting with the ORIGINAL DataFrame:
#
#     a) Delete the columns:
#        Employee_ID
#        Department
print(df.drop(["Employee_ID","Department"],axis=1))
print(df.drop([1,3,6]))


#     b) Delete the rows:
#        1, 3, 6
#
#     c) Permanently apply every deletion.
#
#     d) Finally print the DataFrame.
#
#     Your final DataFrame must contain ONLY:
#
#        Name
#        Age
#        Salary
#
#     And the remaining indexes should be:
#
#        0, 2, 4, 5, 7
#
# ============================================================
#
# RESTRICTION:
#
# You may use ONLY:
#
#     drop()
#     axis=0
#     axis=1
#     inplace=True
#
# Do NOT use:
#
#     del
#     pop()
#     loc
#     iloc
#     loops
#     if/else
#
# ============================================================





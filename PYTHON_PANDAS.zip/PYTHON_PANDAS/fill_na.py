import pandas as pd

data = {
    "Name": ["Darshan", None, "Ram", "Shyam", None, "Hari", "Ram"],
    "Age": [None, 18, None, 25, None, 20, 18],
    "Salary": [80000, None, 90000, None, 70000, None, 90000],
    "Department": ["IT", None, "HR", "IT", None, "HR", "HR"]
}

df = pd.DataFrame(data)

# ============================================================
# Q1. Display the total number of missing values in each column
# ============================================================

# print(df.isna().sum())

# ============================================================
# Q2. Replace all missing values in the Name column with
#     "Unknown"
# ============================================================
# df["Name"]=df["Name"].fillna("Unkown",inplace=True)
# print(df)

# ============================================================
# Q3. Fill missing Age values individually:
#     First missing Age  -> 22
#     Second missing Age -> 30
#     Third missing Age  -> 28
#     Do NOT change existing Age values.
#     MUST use .loc[]
# ============================================================
# df.loc[[0,2,4],"Age"]=[22,30,28]
# print(df)

# ============================================================
# Q4. Fill missing Salary values using:
#     Row 1 -> 85000
#     Row 3 -> 75000
#     Row 5 -> 65000
#     MUST use .loc[]
# ============================================================


# ============================================================
# Q5. Replace missing Department values with "Unknown"
# ============================================================


# ============================================================
# Q6. Display employees whose:
#     Age >= 25
#     AND
#     Salary >= 75000
# ============================================================
print(df[(df["Age"]<25) |(df["Salary"]<75000)])

# ============================================================
# Q7. Display the complete cleaned DataFrame with columns
#     in this order:
#     Name, Department, Age, Salary
# ============================================================
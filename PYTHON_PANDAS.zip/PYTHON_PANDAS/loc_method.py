# import pandas as pd
# import pandas as pd
# data={
#     "Name":["Sudarshan Chaudhary","Arbind Kumar Shah","Roshan Chaudhary","Nikhil Chaudhary"],
#     "Age":[10,20,30,40],
#     "Salary":[40000,50000,60000,70000]
# }
# df=pd.DataFrame(data)
# # df.insert(0,"Employee_ID",["Emp1","Emp2","Emp3","Emp4"])
# # print(df)

# print(df.loc[4,"Age"])
# print(df)




import pandas as pd

data = {
    "Employee_ID": ["EMP101", "EMP102", "EMP103", "EMP104", "EMP105",
                    "EMP106", "EMP107", "EMP108"],
    "Name": [
        "Sudarshan Chaudhary",
        "Arbind Kumar Shah",
        "Roshan Chaudhary",
        "Nikhil Chaudhary",
        "Rahul Jaiswal",
        "Sahil Ansari",
        "Bibek Sharma",
        "Aman Gupta"
    ],
    "Age": [19, 22, 25, 28, 21, 24, 30, 26],
    "Salary": [45000, 52000, 68000, 75000, 48000, 62000, 90000, 57000],
    "Department": [
        "IT", "HR", "Finance", "IT",
        "Marketing", "Finance", "HR", "IT"
    ]
}

df = pd.DataFrame(data)

# ============================================================
# 🔥🔥 HARD LOC CHALLENGE
# ============================================================

# Q1. Using loc, display ONLY the Name of the employee
#     whose index label is 4.

print(df.loc[4,"Name"])


# Q2. Using loc, display ONLY the Salary of the employee
#     whose index label is 6.

# print(df.loc[6, ["Name", "Salary"]])


# Q3. Using loc, display the Name, Age, and Salary
#     of the employee whose index label is 3.
print(df.loc[3,["Name","Age","Salary"]])

# Q4. Using loc, display the COMPLETE row
#     whose index label is 5.
print(df.loc[3])

# Q5. Using loc, display ONLY Name and Department
#     for employees at index 1 and index 6.
print(df.loc[1,["Name","Department"]])
print(df.loc[6,["Name","Department"]])


# Q6. Using loc, display ONLY Name, Age, and Salary
#     for indexes 2, 4, and 7.

print(df.loc[2,["Name","Age",'Salary']])

print(df.loc[4,["Name","Age",'Salary']])

print(df.loc[7,["Name","Age",'Salary']])


# Q7. Using loc, display all columns for indexes 3 through 6.
print(df.loc[[3,6]])



# Q8. Using loc, display only:
#
#     Name
#     Salary
#     Department
#
#     for indexes 1 through 5.
print(df.loc[[1,5],["Name",'Salary',"Department"]])

# ============================================================
# 🔥 MODIFYING DATA USING LOC
# ============================================================

# Q9. Using loc, change the Salary of the employee
#     at index 2 to 75000.
(df.loc[2,"Salary"])=75000
print(df)


# Q10. Using loc, change the Department of the employee
#      at index 5 to "IT".
df.loc[5,"Department"]='IT'

# Q11. Using loc, change BOTH Age and Salary of the
#      employee at index 7:
#
#      Age = 29
#      Salary = 65000
df.loc[7,["Age","Salary"]]=[29,65000]
print(df)


# Q12. Using loc, change the Salary of employees
#      at indexes 0, 2, and 5 to:
#      50000, 80000, 70000
#      respectively.
df.loc[[0,2,5],["Salary"]]=[50000,80000,70000]


# ============================================================
# 💀 FINAL BOSS — 15 MARKS
# ============================================================

# Q13. Using ONLY loc:
#
#      1. Display Name, Age, Salary, and Department
#         for indexes 1, 3, 5, and 7.
print(df.loc[[1,3,5,7]])

#
#      2. Change the Salary of indexes 1, 3, 5, and 7
#         to:
#
#         60000, 85000, 72000, 70000
#
#         respectively.

df.loc[[1,3,5,7],["Salary"]]=[60000,85000,72000,70000]
print(df)

#
#      3. Change the Department of indexes 1 and 7
#         to "Finance".
df.loc[[1,7],"Department"]="Finance"
print(df)

#
#      4. Finally, display the complete DataFrame.
#
# ============================================================
#
# RESTRICTION:
#
# Use ONLY:
#
#     loc
#     column selection
#
# Do NOT use:
#
#     insert()
#     iloc
#     head()
#     tail()
#     query()
#     groupby()
#     sort_values()
#     loops
#     if/else
#
# ============================================================